sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"lsp/ex/ZEXFAP0010/utils/CommConfig",
	"lsp/ex/ZEXFAP0010/utils/CommUtils"
], function (Controller, JSONModel, Filter, CommConfig, CommUtils) {
	"use strict";

	return Controller.extend("lsp.ex.ZEXFAP0010.controller.Mainview", {
		_iMinusHeight : 500,
		
		/**
		 * init
		 */
		onInit: function () {
			
			var oTotalData = $.extend(true, {}, CommConfig._oViewData);
			var oTotalModel = new JSONModel(oTotalData);
			this.getView().byId("totalCountLayout").setModel(oTotalModel);
			
			this.changeTableHeight(); //화면에 맞춰 테이블 높이 변경

			this.setInitData(); //Total 데이터 가져옴
			
		},

		/**
		 * Timer (5분이 지나면 reload)
		 */
		setTimer: function(that){
			var oTotalModel = that.getView().byId("totalCountLayout").getModel();
			var iTimeCount = oTotalModel.getProperty("/_config/timeCount");
			
			if (iTimeCount < 5) {
				iTimeCount = iTimeCount + 1;
				oTotalModel.setProperty("/_config/timeCount", iTimeCount);
			} else {
				iTimeCount = 1;
				oTotalModel.setProperty("/_config/timeCount", iTimeCount);
				
				var oSmartTable = that._getSmartTable();
				oSmartTable.rebindTable(); //데이터 리바인딩
				that.setInitData(); //Total 데이터 가져옴
			}
		},

		/**
		 * Total 데이터 가져옴 (링크 클릭시나 5분마다 실행함)
		 * @param Property명
		 * @param 필터1
		 * @param 필터2
		 */
		setInitData: function(){
			var oTotalModel = this.getView().byId("totalCountLayout").getModel();
			
			// 현황합계 데이터 합계를 가져옴
			this.getPressTotalStatus("/_total/count0501", "", "", "Y"); // B/L 미수신 현황 전체
			this.getPressTotalStatus("/_total/count0502", "blinforec", "shipconf", "Y"); // B/L 미수신 현황
			this.getPressTotalStatus("/_total/count0101", "ncc", "", "Y"); // 미통관
			this.getPressTotalStatus("/_total/count0201", "ndeliv", "", "Y"); // 미출하
			// this.getPressTotalStatus("/_total/count0301", "etdcobd", "", "Y"); // ETD대비 On Board data 현황
			// this.getPressTotalStatus("/_total/count0401", "shipdelay", "", "Y"); // 선적지연 현황
			// this.getPressTotalStatus("/_total/count0601", "fdestcnt", "", "Y"); // F.Dest 불일치 건수
			// this.getPressTotalStatus("/_total/count0701", "sdmima", "", "Y"); // F.Dest 불일치 건수
			
			//그래프
			// this.getPressTotalStatus("/_chart/data01", "delay", "", "Y"); // 1일이상
			// this.getPressTotalStatus("/_chart/data02", "delay", "", "B"); // 5일이상
			// this.getPressTotalStatus("/_chart/data03", "delay", "", "R"); // 10일이상
			
			//날짜 설정
			oTotalModel.setProperty("/_config/stdDate", CommUtils.dateFormatCm(CommUtils.addMonthDate(-3, 1)));
			oTotalModel.setProperty("/_config/endDate", CommUtils.dateFormatCm(CommUtils.nowDate()));
			
			//timer
			if (this._Interval) {
				clearInterval(this._Interval);
			}
			this._Interval = setInterval(this.setTimer, 60000, this); // 1분 간격으로 갱신

		},

		/**
		 * 현황합계 데이터를 가져옴
		 * @param Property명
		 * @param 필터1
		 * @param 필터2
		 * @param value
		 */
		getPressTotalStatus: function(sProperty, sType, sSubType, sValue){
			
			var oTotalModel = this.getView().byId("totalCountLayout").getModel();
			
			var oFilters = [];
			if (sType && sType !== "") {
				oFilters.push(new Filter(sType, "EQ", sValue));
			}
			if (sSubType && sSubType !== "") {
				oFilters.push(new Filter(sSubType, "EQ", sValue));
			}

			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			oDataModel.read("/zexcva0110_ddl/$count", {
				filters: [new Filter(oFilters, false)],
			 	success: function(oData, response){
			 		if (oData && oData !== "") {
				 		oTotalModel.setProperty(sProperty, Number($.trim(oData)));
			 		}
			 	},
			 	error: function(oError){
			 		CommUtils.displayErrorMessage(oError, "toast");
			 	}
			});
		},

		/**
		 * 현황합계 클릭 Event
		 * @param 필터1
		 * @param 필터2
		 */
		onChangeListData: function(oEvent, sType, sSubType){ 
			// console.log(sType + "," + sSubType);
			
			this.setInitData(); //Total 데이터 가져옴

			var oSmartTable = this._getSmartTable();

			this.oTableSearchState = [];
			//var sQuery = oEvent.getSource().getProperty("selectedKey");
			
			var oType, oSubType;
			this.oPubFilters = [];
			if (sType && sType !== "" && sSubType && sSubType !== "") {
				oType = new Filter(sType, "EQ", "Y");
				oSubType = new Filter(sSubType, "EQ", "Y");
				this.oPubFilters = new sap.ui.model.Filter({filters:[oType, oSubType], and:false});
			} else {
				if (sType && sType !== "") {
					oType = new Filter(sType, "EQ", "Y");
					this.oPubFilters = new sap.ui.model.Filter({filters:[oType], and:false});
				} else if (sSubType && sSubType !== "") {
					oSubType = new Filter(sSubType, "EQ", "Y");
					this.oPubFilters = new sap.ui.model.Filter({filters:[oSubType], and:false});
				}
			}
			
			if (sType === "etdcobd" || sType === "shipdelay" || sType === "fdestcnt" || sType === "sdmima") {
				sap.m.MessageToast.show("I'm working on");
				// oSmartTable.rebindTable();
			} else {
				oSmartTable.rebindTable();
			}
		},

		/**
		 * 데이터 리바인딩
		 */
		onBeforeRebindTable: function (oEvent) {

		    if (this.oPubFilters && this.oPubFilters.aFilters && this.oPubFilters.aFilters.length > 0) {
			    var oBinding = oEvent.getParameter("bindingParams");
		    	var oFilter = this.oPubFilters;
			    oBinding.filters.push(oFilter);
		    }
		},
		
		/**
		 * 데이터를 바인딩 후에 처리
		 */
		onDataReceived: function (oEvent) {
			// var oTotalModel2 = this.getView().getModel();
			// oTotalModel2.setProperty("/aa/bb", "11");
			
			//데이터 확인
		},

		/**
		 * 버튼 정렬 팝업 호출
		 */
		onSort: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Sort");
			}
		},

		/**
		 * 버튼 필터 팝업 호출
		 */
		onFilter: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Filter");
			}
		},

		/**
		 * 컬럼 셋팅 팝업 호출
		 */
		onColumns: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Columns");
			}
		},

		/**
		 * 테이블 정보를 가져온다.
		 * @return SmartTable
		 */
		_getSmartTable: function () {
			if (!this._oSmartTable) {
				this._oSmartTable = this.getView().byId("mainviewSmartTable");
			}
			return this._oSmartTable;
		},

		/**
		 * 엑셀 다운로드
		 */
		onBeforeExport: function (oEvent) {
			var mExcelSettings = oEvent.getParameter("exportSettings");
			
			// GW export
			if (mExcelSettings.url) {
				return;
			}
			// UI5 Client Export
			if (mExcelSettings.fileName !== "") {
				mExcelSettings.fileName = mExcelSettings.fileName; // example to modify fileName
			} else {
				mExcelSettings.fileName = "FB List";
			}

			// customization
			if (mExcelSettings.workbook && mExcelSettings.workbook.columns && mExcelSettings.workbook.columns.length > 0) {
				var oExcelData = mExcelSettings.workbook.columns;
				for(var i=0; i<oExcelData.length; i++) {
					oExcelData[i].width = oExcelData[i].width * 2;
				}
			}

			mExcelSettings.worker = false;
		},

		/**
		 * 화면에 맞춰 테이블 높이 변경
		 */
		changeTableHeight: function () {
			var that = this;
			
			//테이블 높이 지정
			var oTable = this.getView().byId("gridTableData");
			var iHet = window.innerHeight - this._iMinusHeight;
			var nHet = Math.floor( iHet / 33);
			if (oTable) {
				oTable.setVisibleRowCount(nHet);
			}
			
			sap.ui.Device.resize.attachHandler(function(oEvent) {
				var iHet1 = oEvent.height - that._iMinusHeight;
				var nHet1 = Math.floor( iHet1 / 33);
				if (oTable) {
					oTable.setVisibleRowCount(nHet1);
				}
			}, this.getView());
		}	

	});

});