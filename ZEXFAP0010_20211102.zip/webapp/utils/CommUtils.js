sap.ui.define([], function (Controller) {
	"use strict";

	var CommUtils = {

		/**
		 * 현재 날짜를 가져온다. 
		 * @return yyyyMMdd
		 */
		nowDate: function () {
			var dDate = new Date();
			var sResult = dDate.getFullYear() + this.getLenDay(dDate.getMonth() + 1) + this.getLenDay(dDate.getDate());
			return sResult;
		},

		/**
		 * 월일을 2자리로 바꾼다
		 * @param M or D
		 * @return MM or dd
		 */
		getLenDay: function (sDt) {
			return sDt < 10 ? '0' + sDt : "" + sDt;
		},

		/**
		 * 특정월,일을 더한다
		 * @param 월
		 * @param 일
		 * @return yyyyMMdd
		 */
		addMonthDate: function (vMonth, vDay) {
			var d = new Date();
			d.setMonth(d.getMonth() + vMonth);
			d.setDate(d.getDate() + vDay);
			var result = d.getFullYear() + this.getLenDay(d.getMonth() + 1) + this.getLenDay(d.getDate());
			return result;
		},

		/**
		 * 특정 날짜에서 특정월,일을 더한다
		 * @param 특정날짜
		 * @param 월
		 * @param 일
		 * @return yyyyMMdd
		 */
		addMonthDateOth: function (vDate, vMonth, vDay) {
			var d = CommUtils.strToDate(vDate);
			d.setMonth(d.getMonth() + vMonth);
			d.setDate(d.getDate() + vDay);
			var result = d.getFullYear() + this.getLenDay(d.getMonth() + 1) + this.getLenDay(d.getDate());
			return result;
		},

		/**
		 * String을 Date 형으로 변경한다.
		 * @param yyyyMMdd
		 * @return Date
		 */
		strToDate: function (vDate) {
			if (vDate && vDate !== "" && vDate.length === 8) {
				var yyyy = vDate.substr(0, 4);
				var mm = vDate.substr(4, 2);
				var dd = vDate.substr(6, 2);
				return new Date(yyyy, mm - 1, dd);
			} else {
				return null;
			}
		},

		/**
		 * 날짜 사이에 구분자를 넣는다(-)
		 * @param 날짜(8자리)
		 * @return YYYY-MM-DD
		 */
		dateFormat: function (sVal) {
			if (sVal && sVal !== "" && sVal.length === 8) {
				return sVal.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
			} else if (sVal && sVal !== "" && sVal.length === 6) {
				return sVal.replace(/(\d{4})(\d{2})/g, '$1-$2');
			} else {
				return sVal;
			}
		},

		/**
		 * 날짜 사이에 구분자를 넣는다(.)
		 * @param 날짜(8자리)
		 * @return YYYY-MM-DD
		 */
		dateFormatCm: function (sVal) {
			if (sVal && sVal !== "" && sVal.length === 8) {
				return sVal.replace(/(\d{4})(\d{2})(\d{2})/g, '$1.$2.$3');
			} else if (sVal && sVal !== "" && sVal.length === 6) {
				return sVal.replace(/(\d{4})(\d{2})/g, '$1.$2');
			} else {
				return sVal;
			}
		},

		/**
		 * 소숫점 뒤 0 제거
		 * @param number
		 * @return value
		 */
		toRightZeroClr: function (nVal) {
			var result = "";
			if (nVal) {
				var tmp = nVal + "";
				if (tmp !== "") {
					var num = parseFloat(tmp);
					if (String(num).indexOf(".") !== -1) {
						result = String(parseFloat(num.toFixed(4)));
						// result = result.replace(/(0+$)/, "");
					} else {
						result = String(num) + ".00";
					}
				}
			}
			return result;
		},

		/**
		 * Delay 아이콘 색상을 변경한다
		 * @param 구분값
		 * @return 아이콘컬러
		 */
		changeDelayIconColor: function (sVal) {
			var sResult = "#008000";	//녹색
			if (sVal && sVal !== "") {
				if (sVal === "Y") {
					sResult = "#de890d"; //노랑
				} else if (sVal === "B") {
					sResult = "#00008B"; //블루
				} else if (sVal === "R") {
					sResult = "#b22222"; //붉은색
				}
			}
			return sResult;
		},

		/**
		 * 아이콘 visible true/false 여부를 판단한다. (01)
		 * @param 구분값
		 * @return true/false
		 */
		changeIconVisible01: function (sVal) {
			var sResult = false;
			if (sVal && sVal !== "") {
				if (sVal === "Y") {
					sResult = true;
				}
			}
			return sResult;
		},

		/**
		 * 아이콘 visible true/false 여부를 판단한다. (02)
		 * @param 구분값
		 * @return true/false
		 */
		changeIconVisible02: function (sVal) {
			var sResult = false;
			if (sVal && sVal !== "") {
				if (sVal === "N") {
					sResult = true;
				}
			}
			return sResult;
		},

		/**
		 * 날짜를 문자로 변경한다.
		 * @param 구분값
		 * @return true/false
		 */
		changeFormatDate: function (dVal) {
			// var sZetd = "", sZshDate = ""; 
			var sResult = dVal;
			if (dVal) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyyMMdd"});
				sResult = oDateFormat.format(new Date(dVal));
			}
			return sResult;
		},

		/**
		 * InfoLable colorScheme 를 변경한다
		 * @param 구분값
		 * @return colorScheme Number
		 */
		changeLabelcolor: function (sVal) {
			var sResult = 7;
			if (sVal && sVal !== "") {
				if (sVal === "KGD2170121") {
					sResult = 4;
				}
			}
			return sResult;
		},

		/**
		 * 아이콘 visible true/false 여부를 판단한다. (02)
		 * @param 구분값
		 * @return true/false
		 */
		getIndexSeq: function (vdata, oEvent) {
			// console.log(this);
		},

		/**
		 * Busy Dialog를 Open한다.
		 * @param this
		 * @param 메시지
		 */
		openBusyDialog: function (that, msg) {
			if (!that._BusyDialog) {
				that._BusyDialog = new sap.m.BusyDialog({ text:msg });
				that.getView().addDependent(that._BusyDialog);
			}
			// jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._BusyDialog);
			that._BusyDialog.open();
		},

		/**
		 * Busy Dialog를 Open한다.
		 * @param this
		 */
		closeBusyDialog: function (that) {
			if (that._BusyDialog) {
				that._BusyDialog.close();
				that._BusyDialog = null;
			}
		},

		/**
		 * CustomData에서 특정 key의 value를 가져온다.
		 * @param CustomData
		 * @param key
		 * @return value
		 */
		_getCustomData: function (oCustomData, sKey) {
			var sValue = "";
			if (oCustomData && oCustomData.length) {
				for(var i =0; i<oCustomData.length; i++) {
					if (sKey === oCustomData[i].getKey()) {
						sValue = oCustomData[i].getValue();
						break;
					}
				}
			}
			return sValue;
		},

 
		/**
		 * OData 호출 오류 발생 시 오류 메시지를 추출하여 출력한다.
		 * @param Error
		 */
		displayErrorMessage: function (oError, vType) {
			var vErrorMsg = "시스템 오류입니다. 관리자에게 문의하시기 바랍니다.";
			var vDetailMsg = "";
			if (oError && oError.responseText) {
				if (oError.responseText.indexOf("<?xml") >= 0) {
					var xmlparser = new DOMParser();
					var xmldata = xmlparser.parseFromString(oError.responseText, "text/xml");
					var vErrors = xmldata.getElementsByTagName("error");        
					if (vErrors && vErrors.length) {
						var vMessageTag = vErrors[0].getElementsByTagName("message");
						if (vMessageTag && vMessageTag.length) {
							vDetailMsg = vMessageTag[0].childNodes[0].nodeValue;
						}
					}
				} else {
					var oErrorInfo = JSON.parse(oError.responseText);
					if (oErrorInfo.error && oErrorInfo.error.message) {
						oErrorInfo = oErrorInfo.error.message.value;
					}
				}
			}
			
			if (vType && vType === "toast") {
				sap.m.MessageToast.show(vErrorMsg + "\r\n\r\n" + vDetailMsg, {width: "30rem"});
			} else {
				sap.m.MessageBox.alert(vErrorMsg, {
					title: "안내",
					details: vDetailMsg
				});
			}
		}
		

	};

	return CommUtils;
}, true);