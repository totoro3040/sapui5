package com.sap.acl.member.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sap.acl.member.vo.UserData;
import com.sap.acl.member.service.BillService;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
@RequestMapping("/sample")
public class LoginController {
	private Logger logger = LoggerFactory.getLogger(getClass());

	//@Autowired
	//private BillService billService;	

	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/login")
	public String getNullData(UserData userData, ModelMap model) throws Exception {

		logger.info("===== data =====");
		
		return "sample/login/login";
	}

}
