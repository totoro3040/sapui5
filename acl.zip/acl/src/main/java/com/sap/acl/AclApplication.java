package com.sap.acl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AclApplication {

	public static void main(String[] args) {
		SpringApplication.run(AclApplication.class, args);
	}

}
