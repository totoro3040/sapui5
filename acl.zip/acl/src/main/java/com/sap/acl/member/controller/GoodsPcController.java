package com.sap.acl.member.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sap.acl.member.vo.UserData;
import com.sap.acl.member.vo.TdOdCalAgeStd;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
@RequestMapping("/calc")
public class GoodsPcController {
	private Logger logger = LoggerFactory.getLogger(GoodsPcController.class);

	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/data")
	public String getNullData(UserData userData, ModelMap model) throws Exception {

		logger.info("===== data =====");
		
		model.put("view_type", "test");
		
		return "sample/data";
	}

	/**
	 * 보험료 계산 화면
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/{parentId}", method = {RequestMethod.GET, RequestMethod.POST})
	public String getParentIdData(@PathVariable String parentId, UserData userData, ModelMap model) throws Exception {

		logger.debug("===== parentId {} ===== " + parentId);
		
		model.put("view_type", "test");
		
		return "calc/calc" + parentId;
	}

	/**
	 * 보험료 계산 화면2
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/aa2", method = {RequestMethod.GET, RequestMethod.POST})
	public String getTest2(HttpServletRequest request, UserData vo, ModelMap model) throws Exception {
		
		logger.info("userId : " + StringUtils.isNotEmpty(vo.getUserId()));
		logger.info("userNm : " + StringUtils.isNotEmpty(vo.getUserNm()));

		String parentId = "01";
		String desgnNo = "";
		
		
		model.put("desgnNo", desgnNo);
		model.addAttribute("paramAll", vo);
		
		
		return "calc/calc" + parentId;
	}

	/**
	 * 보험료 계산 화면2
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = {"/aa", "/aa/{parentId}", "/aa/{parentId}/{desgnNo}"}, method = {RequestMethod.GET, RequestMethod.POST})
	public String getParentIdData2(HttpServletRequest request, @PathVariable Map<String, String> pathVariablesMap, UserData userData, ModelMap model) throws Exception {

		String parentId = "01";
		String desgnNo = "";
		
		if (pathVariablesMap.containsKey("parentId")) {
			logger.info("===== parentId {} ===== " + pathVariablesMap.get("parentId"));
			parentId = pathVariablesMap.get("parentId");
	    }
		if (pathVariablesMap.containsKey("desgnNo")) {
			logger.info("===== desgnNo {} ===== " + pathVariablesMap.get("desgnNo"));
	    }
		
		
		model.put("desgnNo", desgnNo);
		
		
		return "calc/calc" + parentId;
	}

	/**
	 * 메일 발송
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/popup/calcSendMail", method = {RequestMethod.GET, RequestMethod.POST})
	public String calcSendMail(HttpServletRequest request) throws Exception {

		String templateFilePath = request.getSession().getServletContext().getRealPath("/")
				+ File.separator + "WEB-INF"
				+ File.separator + "views"
				+ File.separator + "pc"
				+ File.separator + "calc"
				+ File.separator + "template";
				
				//WEB-INF/views/pc/calc/template/maillayout.jsp
		
		String templateFile = templateFilePath + File.separator + "maillayout.html"; //layout path
		String detailFile = templateFilePath + File.separator + "mail01.html"; //상품설명 path
		String imgPath = "http://localhost/maf/images/pc/mail"; //이미지 경로
		String onlineHomeLink = "http://localhost/cs"; //home link
		String onlineCalcLink = "http://localhost/cs"; //가입설계 link
				
		logger.info("===== calcSendMail ===== " + templateFilePath);
		
		
		logger.info("===== calcSendMail ===== ");
		
 
        try{
        	//String open = File.s
        	
            String urlPath = "http://localhost/es/calc/template/maillayout";
            String pageContents = "";
            StringBuilder contents = new StringBuilder();
            String urlPath2 = "http://localhost/es/calc/template/mail01";
            String pageContents2 = "";
            StringBuilder contents2 = new StringBuilder();
 
            URL url = new URL(urlPath);
            URLConnection con = (URLConnection)url.openConnection();
            InputStreamReader reader = new InputStreamReader (con.getInputStream(), "euc-kr");
 
            BufferedReader buff = new BufferedReader(reader);
 
            while((pageContents = buff.readLine())!=null){
                //System.out.println(pageContents);             
                contents.append(pageContents);
                contents.append("\r\n");
            }
            buff.close();

            URL url2 = new URL(urlPath2);
            URLConnection con2 = (URLConnection)url2.openConnection();
            InputStreamReader reader2 = new InputStreamReader (con2.getInputStream(), "euc-kr");
 
            BufferedReader buff2 = new BufferedReader(reader2);
 
            while((pageContents2 = buff2.readLine())!=null){
                //System.out.println(pageContents);             
                contents2.append(pageContents2);
                contents2.append("\r\n");
            }
            buff2.close();
            
            templateFile = contents.toString();
            detailFile = contents2.toString();
            
            templateFile = templateFile.replaceAll("$$$detailFile$$$", detailFile); //상품설명
            templateFile = templateFile.replaceAll("$$$imgPath$$$", imgPath); //이미지 경로
            templateFile = templateFile.replaceAll("$$$onlineHomeLink$$$", onlineHomeLink); //링크 경로
            templateFile = templateFile.replaceAll("$$$onlineCalcLink$$$", onlineHomeLink); //링크 경로
            
            //if 정기보험...
            templateFile = templateFile.replaceAll("$$$moneyDisplay1$$$", "display:none");
            //else
            templateFile = templateFile.replaceAll("$$$moneyDisplay2$$$", "display:none");
            templateFile = templateFile.replaceAll("$$$moneyDisplay3$$$", "display:none");
            
            
            
 
            System.out.println(templateFile);
 
        }catch(Exception e){
            e.printStackTrace();
        }
        
		return "pc/calc/popup/calcSendMail";
	}

	
	/**
	 * Modal 호출 화면
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/popup/getModal/{pageName}", method = {RequestMethod.GET, RequestMethod.POST})
	public String clacMail(@PathVariable String pageName) throws Exception {

		logger.info("===== pageName {} ===== " + pageName);
		
		//model.put("view_type", "test");
		
		return "pc/calc/popup/" + pageName;
	}

	/**
	 * Mail  호출 화면
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/template/{pageName}", method = {RequestMethod.GET, RequestMethod.POST})
	public String clacTemplate(@PathVariable String pageName) throws Exception {

		logger.info("===== pageName {} ===== " + pageName);
		
		//model.put("view_type", "test");
		
		return "pc/calc/template/" + pageName;
	}

	
	/**
	 * tab 영역
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/inc/tab01", method = {RequestMethod.GET, RequestMethod.POST})
	public String getTabData(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /inc/tab01 =====");
		
		return "pc/calc/inc/tab01";
	}

	/**
	 * tab 영역
	 * 
	 * @param parentId
	 * @return jsp
	 * @throws Exception
	 */
	@RequestMapping(value = "/inc/tab/{tabId}/{parentId}", method = {RequestMethod.GET, RequestMethod.POST})
	public String getTabData2(@PathVariable String tabId, @PathVariable String parentId, ModelMap model) throws Exception {

		logger.info("===== /inc/tab01 =====");
		
		return "pc/calc/inc/tab01";
	}

	/**
	 * 보험료 산출
	 * 
	 * @param UserData
	 * @return Map<String,Object>
	 * @throws Exception
	 */
	@RequestMapping(value = "/getProdPremList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String,Object> getProdPremList(UserData userData) throws Exception {

		logger.info("===== /ajax =====");

		UserData info;
		ArrayList list = new ArrayList();
		info = new UserData();
		info.setUserNm("유저1");
		list.add(info);
		info = new UserData();
		info.setUserNm("유저2");
		list.add(info);

		
		TdOdCalAgeStd tdOdCalAgeStd = new TdOdCalAgeStd();
		tdOdCalAgeStd.setIsprd("Y20");
		tdOdCalAgeStd.setRvpd("Y999");
		tdOdCalAgeStd.setNtryAmt(180000000l);
		
		
		Map<String,Object> resultMap = new HashMap<String,Object>();
		
		resultMap.put("list", list);
		resultMap.put("lis2", list);
		resultMap.put("cmprDbData", tdOdCalAgeStd);
		
		return resultMap;
	}

	/**
	 * 보험료 산출
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajax6")
	@ResponseBody
	public ArrayList<UserData> getAjax6(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");

		UserData info;
		ArrayList list = new ArrayList();
		info = new UserData();
		info.setUserNm("유저1");
		list.add(info);
		info = new UserData();
		info.setUserNm("유저2");
		list.add(info);

		ModelAndView mav = new ModelAndView();

		Map resultMap = new HashMap();
		resultMap.put("list", list);
		mav.addAllObjects(resultMap);
		mav.setViewName("jsonView");

		return list;
	}

	/**
	 * 보험료 산출
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajax7")
	@ResponseBody
	public ModelMap getAjax7(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");

		UserData info;
		ArrayList list = new ArrayList();
		info = new UserData();
		info.setUserNm("유저1");
		list.add(info);
		info = new UserData();
		info.setUserNm("유저2");
		list.add(info);
		
		model.addAttribute("paramAll", userData);
		//model.addAllAttributes(userData)

		ModelAndView mav = new ModelAndView();

		Map resultMap = new HashMap();
		resultMap.put("list", list);
		
		
		model.put("list", "list");
		
		//mav.addAllObjects(resultMap);
		//mav.setViewName("jsonView");

		return model;
	}
	
	/**
	 * 보험료 산출
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajax5")
	@ResponseBody
	public Map<String,Object> getAjax5(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");
		
		UserData info;
		ArrayList list = new ArrayList();
		info = new UserData();
		info.setUserNm("유저1");
		list.add(info);
		info = new UserData();
		info.setUserNm("유저2");
		list.add(info);

		//ModelAndView mav = new ModelAndView();

		Map<String,Object> resultMap = new HashMap<String,Object>();
		
		resultMap.put("list", list);
		resultMap.put("lis2", list);
		//mav.addAllObjects(resultMap);
		//mav.setViewName("jsonView");

		return resultMap;
	}

	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/aa/ajax")
	@ResponseBody
	public ModelAndView getAjax(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");

		UserData info;
		ArrayList list = new ArrayList();
		info = new UserData();
		info.setUserNm("유저1");
		list.add(info);
		info = new UserData();
		info.setUserNm("유저2");
		list.add(info);

		ModelAndView mav = new ModelAndView();

		Map resultMap = new HashMap();
		resultMap.put("list", list);
		mav.addAllObjects(resultMap);
		mav.setViewName("jsonView");

		return mav;
	}



	
	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajax2")
	@ResponseBody
	public UserData getAjax4(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");

		UserData info;
		ArrayList list = new ArrayList();
		info = new UserData();
		info.setUserNm("유저1");
		list.add(info);
		info = new UserData();
		info.setUserNm("유저2");
		list.add(info);

		ModelAndView mav = new ModelAndView();

		Map resultMap = new HashMap();
		resultMap.put("list", list);
		mav.addAllObjects(resultMap);
		mav.setViewName("jsonView");
		
		

		return info;
	}
	
	
	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/aa/ajax2")
	@ResponseBody
	public ModelMap getAjax2(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");

		model.put("aaa", "aa");

		return model;
	}
}
