package com.sap.acl.member.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

//import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * Member 데이터처리 매퍼 클래스
 *
 * @author  totoro
 * @since 2019.09.15
 * @version 1.0
 * @see <pre>
 *  == 개정이력(Modification Information) ==
 *
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   019.09.15        totoro          최초 생성
 *
 * </pre>
 */
@Mapper
public interface MemberDao {

	int selectMemberCount(Map<String,Object> params) throws Exception;
	List<Map<String, Object>> selectMemberList(Map<String,Object> params) throws Exception;
	Map<String, Object> selectMemberDetail(Map<String, Object> params) throws Exception;
	void insertMember(Map<String,Object> params);
	void updateMember(Map<String,Object> params);
	void deleteMember(Map<String,Object> params);
	
}
