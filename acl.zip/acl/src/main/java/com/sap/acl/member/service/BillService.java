package com.sap.acl.member.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sap.acl.common.PageMaker;
import com.sap.acl.member.dao.BillDao;
import com.sap.acl.member.vo.SeriesVO;

/**
 * @Class Name : ConferServiceImpl.java
 * @Description : 회의록 Business Implement Class
 * @Modification Information 
 * 수정일 
 * 수정자 
 * 수정내용 
 * 2019.09.15 최초생성
 *
 * @author totoro
 * @since 2019.09.15
 * @version 1.0
 * @see
 *
 * 	Copyright (C) by ithink All right reserved.
 */

//@Service("billService")
@Service
public class BillService {

	private static final Logger logger = LoggerFactory.getLogger(BillService.class);

	@Autowired
	private BillDao billDao;

	/**
	 * 목록 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(readOnly = true)
	public int selectMemberCount(Map<String,Object> params) throws Exception {
		return billDao.selectMemberCount(params); //목록 갯수를 가져온다.;		
	}
	
	/**
	 * 목록 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(readOnly = true)
	public List<Map<String, Object>> selectMemberList(Map<String,Object> params) throws Exception {
		params.put("pageStart", (MapUtils.getInteger(params, "pageIndex", 1) - 1) * MapUtils.getInteger(params, "perPageNum", 10));
		params.put("perPageNum", MapUtils.getInteger(params, "perPageNum", 10));
		
		return billDao.selectMemberList(params); //목록을 가져온다.
	}

	
	/**
	 * 목록 가져오기
	 * 
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(readOnly = true)
	public List<SeriesVO> selectBillSerieslist() throws Exception {
		
		return billDao.selectBillSerieslist();
	}
	
	/**
	 * 목록 테스트2
	 * 
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(readOnly = true)
	public List<Map<String, Object>> selectBillSerieslist2() throws Exception {
		
		logger.debug("11");
		return null;
		//return billDao.selectBillSerieslist2();
	}

	/**
	 * 트랜젝션 테스트1
	 * 
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(rollbackFor =Exception.class)
	public void saveTran1(Map<String, Object> param) throws Exception {
		billDao.insertMember1(param);
	}
	
	/**
	 * 트랜젝션 테스트2
	 * 
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(rollbackFor =Exception.class)
	public void saveTran2(Map<String, Object> param) throws Exception {
		billDao.insertMember2(param);
	}
	
	/**
	 * 트랜젝션 테스트3(복합)
	 * 
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional
	public void saveTran3() throws Exception {
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("mb_id", "dd");
		param.put("mb_pw", "ddd");
		param.put("address", "충청도");
		
		Map<String, Object> param2 = new HashMap<String, Object>();
		param2.put("mb_id", "dd");
		param2.put("mb_pw", "ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd");
		param2.put("address", "충청도");
		
		billDao.insertMember1(param);
		billDao.insertMember2(param2);
	}
}
