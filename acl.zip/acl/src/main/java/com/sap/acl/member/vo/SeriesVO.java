package com.sap.acl.member.vo;

/**
 * @Class Name : SeriesVO.java
 * @Description : SeriesVO class
 * @Modification 대별 회기정보
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2019. 09.15           최초생성
 *
 * @author 
 * @since 2019. 09.15
 * @version 1.0
 * @see
 *
 *  Copyright (C) by ithink All right reserved.
 */
public class SeriesVO {

	private static final long serialVersionUID = 1L;

	private int seq = 0; //대정보
	private String mbId; //시작일
	private String mbPw; //종료일
	private String address; //기간
	private String mbTell; //본회의일자
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getMbId() {
		return mbId;
	}
	public void setMbId(String mbId) {
		this.mbId = mbId;
	}
	public String getMbPw() {
		return mbPw;
	}
	public void setMbPw(String mbPw) {
		this.mbPw = mbPw;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMbTell() {
		return mbTell;
	}
	public void setMbTell(String mbTell) {
		this.mbTell = mbTell;
	}

	
}
