package com.sap.acl.member.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.acl.common.PageMaker;

@Controller
@RequestMapping("/sample/cross")
public class CrossController {
	private Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * index(페이징)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/index")
	public String paging(@RequestParam Map<String, Object> params, ModelMap model) throws Exception {

		model.addAttribute("params", params);

		// model.put("view_type", "test");

		return "sample/cross/index";
	}

	/**
	 * 
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajax01")
	public @ResponseBody Map<String, Object> ajax01(@RequestParam Map<String, Object> params) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));

		// paging
		PageMaker pageMaker = new PageMaker(MapUtils.getInteger(params, "pageIndex", 1), MapUtils.getInteger(params, "perPageNum", 10), 100);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("pageMaker", pageMaker);

		return map;
	}

	@RequestMapping(value = "/ajax02", produces = "application/xml;charset=utf-8")
	public @ResponseBody String ajax02(HttpServletRequest request) throws Exception {

		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("<item>");
		stringBuffer.append("  <category>");
		stringBuffer.append("    <![CDATA[ 카테고리 ]]>");
		stringBuffer.append("  </category>");
		stringBuffer.append("  <title>");
		stringBuffer.append("    <![CDATA[ 제목 ]]>");
		stringBuffer.append("  </title>");
		stringBuffer.append("  <link>");
		stringBuffer.append("    http://주소..");
		stringBuffer.append("  </link>");
		stringBuffer.append("  <description>");
		stringBuffer.append("    <![CDATA[ 내용 ]]>");
		stringBuffer.append("  </description>");
		stringBuffer.append("  <tag>");
		stringBuffer.append("    <![CDATA[ 태그 ]]>");
		stringBuffer.append("  </tag>");
		stringBuffer.append("</item>");

		return stringBuffer.toString();
	}
	
	@RequestMapping(value = "/content.xml", produces = "application/xml;charset=utf-8")
	public @ResponseBody String listSample(HttpServletRequest request) throws Exception {

		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("<item>");
		stringBuffer.append("  <category>");
		stringBuffer.append("    <![CDATA[ 카테고리 ]]>");
		stringBuffer.append("  </category>");
		stringBuffer.append("  <title>");
		stringBuffer.append("    <![CDATA[ 제목 ]]>");
		stringBuffer.append("  </title>");
		stringBuffer.append("  <link>");
		stringBuffer.append("    http://주소..");
		stringBuffer.append("  </link>");
		stringBuffer.append("  <description>");
		stringBuffer.append("    <![CDATA[ 내용 ]]>");
		stringBuffer.append("  </description>");
		stringBuffer.append("  <tag>");
		stringBuffer.append("    <![CDATA[ 태그 ]]>");
		stringBuffer.append("  </tag>");
		stringBuffer.append("</item>");

		return stringBuffer.toString();
	}

}
