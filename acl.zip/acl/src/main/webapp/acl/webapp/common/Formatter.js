sap.ui.define(function() {
	"use strict";

	var Formatter = {

		status :  function (sStatus) {
				if (sStatus === "Available") {
					return "Success";
				} else if (sStatus === "Out of Stock") {
					return "Warning";
				} else if (sStatus === "Discontinued"){
					return "Error";
				} else {
					return "None";
				}
		},
		
		updateStatus: function (sStateValue) {
			
			var sStateValueToLower = sStateValue ? sStateValue.toLowerCase() : "";

			switch (sStateValueToLower) {
				case "delete":
					return 2;
				case "update":
					return 1;
				default:
					return 0;
			}
		},
		
		// 문자를 숫자로 변환
	    plainNumber: function(iText) {
	 
	      var sReturn = 0;
	       
	      if (iText) { // iInteger is 0
	        sReturn = parseInt(iText,10);      
	      } 
	 
	      // return sReturn to the view
	      return sReturn;    
		},
		// 금액 (천단위 comma)
	    parseAmount: function(iText,fixed) {
			
	      var sReturn = 0;
	      var fix; 
	      if (!fixed) fix = 0;
	      else fix = fixed;
	      
	      if(iText === 0) sReturn = 0;
			
			iText = Number(iText).toFixed(fix);
		    var reg = /(^[+-]?\d+)(\d{3})/;
		    var n = (iText + "");
		 
		    while (reg.test(n)) n = n.replace(reg, '$1' + ',' + '$2');
			
		    sReturn = n;

	      // return sReturn to the view
	      return sReturn;    
		},
		// 앞에 0 붙여서 변환
	    leadingZeroPadding: function(s,size) {
		  while (s.length < (size || 2)) {s = "0" + s;}
		  return s;
		}
	};

	return Formatter;

}, /* bExport= */ true);
