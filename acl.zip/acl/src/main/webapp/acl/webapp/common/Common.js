/*eslint-disable no-console, no-alert, no-eval, no-location-reload */
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/odata/ODataModel",
	"jquery.sap.global",
	"sap/m/MessageToast",
	"sap/m/Button",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/export/Spreadsheet",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"com/doosan/acl/common/Formatter"
], function (JSONModel, MessageBox, ODataModel, jQuery, MessageToast, Button, Fragment, Controller, Spreadsheet, ChartFormatter, Format, Formatter) {
	"use strict";

	return {
		getLang: function(){
			return sap.ui.getCore().getConfiguration().getLanguage();
		},
		setLang: function(uiLang,xsLang){
			sap.ui.getCore().getConfiguration().setLanguage(uiLang);
		},
		getLangXs: function(){
			var lang = sap.ui.getCore().getConfiguration().getLanguage();
			var returnLang = "E";
			if (lang.indexOf("KO") >= 0 || lang.indexOf("ko") >= 0){
				returnLang = "3";
			}
			return returnLang;
		},
		idxOfObject: function (array,prop,value) {
		    for (var i = 0, len = array.length; i < len; i++) {
		        if (eval("array[i]."+prop) === value)
		            return i; // Return as soon as the object is found
		    }
		    return -1; // The object was not found
		},
		idxOfObjectMulti: function (array,prop,value,prop2,value2) {
		    for (var i = 0, len = array.length; i < len; i++) {
		        if (eval('array[i].'+prop) === value && eval('array[i].'+prop2) === value2)
		            return i; // Return as soon as the object is found
		    }
		    return -1; // The object was not found
		},
		uniqueArray : function (array){
			var uArray = [];
			
			for (var i = 0; i < array.length; i++){
				if (uArray.indexOf(array[i]) < 0){
					uArray.push(array[i]);
				}
			}
			
			return uArray;
		},
		deepCopy: function(object){
			return JSON.parse(JSON.stringify(object));
		},
		errorHandling: function (e, oController){ // Session 만료 Dialgog
			var oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
	        var sessionExpired = oBundle.getText("sessionExpired");
	        var sessionExpiredDesc = oBundle.getText("sessionExpiredDesc");
			var refresh = oBundle.getText("refresh");
			var bCompact = !!oController.getView().$().closest(".sapUiSizeCompact").length;
			sap.ui.core.BusyIndicator.hide();
			
				if (e.status === 503 || e.status === 404){
					MessageBox.show(
						sessionExpiredDesc,
						{
							icon: MessageBox.Icon.WARNING,
							title: sessionExpired,
							actions: [refresh, MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : refresh,
							initialFocus: refresh,
							onClose: function(sAction) {
								if (sAction === refresh){ // 새로고침 클릭 시
								  window.location.reload();
								}
							}
						}
					);		
				} else if (e.status === 999) { // 999는 Validation 실패
					MessageBox.error(oBundle.getText(e.messageId) + e.responseText);	
				}
				else if (e.status) {
					MessageBox.error("Error occured. Plese contact system manager. Error message : " + e.responseText);	
				} else {
					MessageBox.error("Error occured. Plese contact system manager. Error message : " + e.message);	
				}
		},
		commonAjaxCall: function(sUrl,sType,sData,oController,oCallback){
			
			if (!sType){
				sType = "GET";
			}
			
			var sParam = { jsonParam: JSON.stringify(sData) };
			var oCommon = this;
			try{
				$.ajax({
					url: sUrl,
					type: sType,
					data: sParam,
					success: function (result) {
						oCallback(result, oController);
					},
					error: function (e) {
						oCommon.errorHandling(e, oController);
					}
				});	
			}catch (ex) {
				oCommon.errorHandling(ex , oController);
			}
		},
		iMessageBox: function (type, messageId, oController){ // 다국어 메세지 표시
				var oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
				switch(type){
					case "information":
						MessageBox.information(oBundle.getText(messageId));
						break;
					case "alert":
						MessageBox.alert(oBundle.getText(messageId));
						break;	
					case "error":
						MessageBox.error(oBundle.getText(messageId));
						break;
					case "warning":
						MessageBox.warning(oBundle.getText(messageId));
						break;
					default:
						MessageBox.information(oBundle.getText(messageId));
						break;
				}
		},
		makeColumn: function (oTable, vColumnInfo) {
			if (!oTable) return;
			if (!vColumnInfo || !vColumnInfo.length) return;

			var oColumns = oTable.getColumns();
			if (oColumns && oColumns.length && oColumns.length > 0) {
				oTable.destroyColumns();
			} else {

			}

			for (var i = 0; i < vColumnInfo.length; i++) {
				
				var vVisible = true;
				if (vColumnInfo[i].DisplayFlag === ""){
					vVisible = false;
				}
				
				var oColumn = new sap.ui.table.Column({
					hAlign: "Center",
					flexible: false,
					autoResizable: true,
					resizable: true,
					showFilterMenuEntry: true,
					visible: vVisible
				});
				
				/* Multi Label 처리 */
				if (vColumnInfo[i].LabelList && vColumnInfo[i].LabelList.length > 0){
					for (var ll = 0; ll < vColumnInfo[i].LabelList.length; ll++) {
						oColumn.addMultiLabel(
							/*
							new sap.m.Text({
								text: vColumnInfo[i].LabelList[ll],
								textAlign: "Center",
								width: "100%"
							}));	
							*/
							new sap.m.FormattedText({
								htmlText: vColumnInfo[i].LabelList[ll],
								width: "100%"
							}));	
					} 
				}

				if (vColumnInfo[i].ColSpanList && vColumnInfo[i].ColSpanList.length > 0){
					var headerSpanArray = [];
					for (var cs = 0; cs < vColumnInfo[i].ColSpanList.length; cs++) {
						headerSpanArray.push(vColumnInfo[i].ColSpanList[cs]);
					} 
					headerSpanArray.push(vColumnInfo[i].span);
					oColumn.setHeaderSpan(headerSpanArray);
				}

				if (vColumnInfo[i].filter) {
					oColumn.setFilterProperty(vColumnInfo[i].id);
				}

				if (vColumnInfo[i].sort) {
					oColumn.setSortProperty(vColumnInfo[i].id);
				}
				
				if (vColumnInfo[i].width && vColumnInfo[i].width != "") {
					oColumn.setWidth(vColumnInfo[i].width);
				}

				if (vColumnInfo[i].align && vColumnInfo[i].align != "") {
					oColumn.setHAlign(vColumnInfo[i].align);
				}

				if (vColumnInfo[i].type === "string") {
					oColumn.setTemplate(new sap.m.Text({
						text: "{" + vColumnInfo[i].id + "}",
						textAlign: "Center",
						wrapping: false
					}));
				} else if (vColumnInfo[i].type === "cnumber") {
					oColumn.setTemplate(new sap.ui.commons.TextView({
						text: {
							path: vColumnInfo[i].id,
							formatter: function (fVal) {
								if (fVal) return parseInt(fVal, 10);
							}
						},
						textAlign: "Center"
					}));
				} else if (vColumnInfo[i].type === "time") {
					oColumn.setTemplate(new sap.ui.commons.TextView({
						text: {
							path: vColumnInfo[i].id,
							formatter: function (fVal) {
								if (fVal) {
									return fVal.substring(0, 2) + ":" + fVal.substring(2, 4);
								}
							}
						},
						textAlign: "Center"
					}));
				} else if (vColumnInfo[i].type === "integer"){
					oColumn.setTemplate(new sap.m.Text({
						text: {
							path: vColumnInfo[i].id,
							formatter: function (fVal) {
								if (fVal) return parseInt(fVal, 10);
								else return 0;
							}
						},
						textAlign: "End"
					}));
					
					oColumn.setHAlign("End");
					
					// Custom 정렬
					this.addColumnSorterAndFilter(oColumn, this.compareIntegers, oTable);		
				} else if (vColumnInfo[i].type === "decimal") {
					oColumn.setTemplate(new sap.m.Text({
						text: "{" + vColumnInfo[i].id + "}",
						textAlign: "End",
						wrapping: false
					}));
					
					oColumn.setHAlign("End");
				} else {

				}
				oTable.addColumn(oColumn);

			}
		},
		mergeTableCell: function (oTable, vColumnIndex){ // vColumnIndex : 몇 열까지 병합할지
			var aRows = oTable.getRows();
			var pRow = {};
             for (var i = 0; i < aRows.length; i++) {
                 if (i > 0) {
                 	 for (var col = 0; col < vColumnIndex; col++){
                 		var pCell = pRow.getCells()[col],
                        	cCell = aRows[i].getCells()[col]; // 첫 번째 열만
	                    	if (cCell.getText() === pCell.getText()) {
	                        $("#" + cCell.getId()).css("visibility", "hidden");
	                        $("#" + pRow.getId() + "-col0").css("border-bottom-style", "hidden");
	                     }	
                 	 }
                 }
                 pRow = aRows[i];
             }
		},
		makeChart: function(setting, data, oVizFrame, oVizPopover){
			/*
			* Chart 생성 Function
			* setting 설정
			*  - chartType : line / column / radar
			*  - measure[] : 
			*  - dimension[] : 
			* return 
			*  - oVizFrame
			*  - oVizPopover
			*/
			
			Format.numericFormatter(ChartFormatter.getInstance());
	        var formatPattern = ChartFormatter.DefaultPattern;

			/* Data Binding */
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			
			var vDimensions = setting.dimensions;
			var vDimensionNames = [];
			for (var dim = 0; dim < vDimensions.length; dim++){
				vDimensionNames.push(vDimensions[dim].name);
			}
			var vMeasures = setting.measures;
			
			// 1. Chart Type 설정 및 Dataset 설정
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions : vDimensions,
				measures : vMeasures,
				
				data : {
					path : "/"
				}
			});
			
			oVizFrame.destroyDataset();
			oVizFrame.setDataset(oDataset);
			
			oVizFrame.setModel(oModel);
			oVizFrame.setVizType(setting.chartType);
			
			// 2-1. Chart Property 설정 (기본)
			oVizFrame.setVizProperties({
	            plotArea: {
	                dataLabel: {
	                    formatString: formatPattern.SHORTFLOAT_MFD2,
	                    visible: false
	                },
	                polarAxis: {
	                    label: {
	                        formatString: formatPattern.SHORTFLOAT_MFD2
	                    },
	                    title: {
	                        visible: false
	                    }
	                },
	                valueAxis: {
	                    label: {
	                        formatString: formatPattern.SHORTFLOAT_MFD2
	                    },
	                    title: {
	                        visible: false
	                    }
	                },
	            },
	            title: {
	                visible: false,
	                text: ""
	            }
	        });
	        
	        // 2-2. Chart Property 설정 (추가)
	        if (setting.properties){
	        	oVizFrame.setVizProperties(setting.properties);
	        }
	        
	        // 3. Feed 설정
	        oVizFrame.destroyFeeds();
		
			var feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': vDimensionNames
				});
			oVizFrame.addFeed(feedCategoryAxis);
			
			for (var mea = 0; mea < vMeasures.length; mea++){
				var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': [vMeasures[mea].name]
				});
				oVizFrame.addFeed(feedValueAxis);
			}
			
			// 4. Popover
			oVizPopover.connect(oVizFrame.getVizUid());
			oVizPopover.setFormatString(formatPattern.SHORTFLOAT_MFD2);
						            
			
		},
		convertRowsToObjArray: function(header,data){
			try{
                  var result = [],
                      upobj = {};
                      
                  // 일반 배열을 key-value 조합으로 변경한다. 
                  for (var d = 0; d < data.length; d++){
                  	  upobj = {};
	                  for(var el = 0; el < data[d].length; el++) {
	                  		if (header[el]){
	                  			// data trim
	                  			var dataTrim = data[d][el].replace(/^\s+|\s+$/g,"");
	                  			//upobj[header[el]] = data[d][el];	
	                  			upobj[header[el]] = dataTrim;	
	                  		}
	                  }
	                  result.push (upobj); 
                  } 
                  
                } catch (e) {
    				this.errorHandling(e, null);
    			} 
    			return result;	
		},
		convertRowsToUploadForm: function(header,data){
			try{
                  var result = [],
                      upobj = {};
                      
                  // 일반 배열을 key-value 조합으로 변경한다. 
                  var pernr = "";
              	  var asmtYear = "";
              	  var aiType = "";
              	  var aiSeq = "";
              	  var prevPernr = "";
                  for (var d = 0; d < data.length; d++){
                  	  // 1. 가로 행별로 여러 행이 나온다!
                  	  pernr = "";
	                  asmtYear = "";
	                  aiType = "";
	                  
                  	  upobj = {};
	                  for(var el = 0; el < data[d].length; el++) {
	                  		
	                  		if (header[el]){
	                  			switch (header[el]){
	                  				case "PERNR":
	                  					pernr = data[d][el];
	                  					break;
	                  				case "ASMT_YEAR":
	                  					asmtYear = data[d][el];
	                  					break;
	                  				case "AI_TYPE":
	                  					aiType = data[d][el];
	                  					break;
	                  				default:
	                  					if (pernr !== ""){
		                  					upobj.pernr = pernr;
		                  					upobj.asmtYear = asmtYear;
		                  					upobj.aiId = header[el];
		                  					upobj.aiSeq = 0;
		                  					upobj.aiType = aiType;
		                  					upobj.aiResult = data[d][el];
		                  					var clone = JSON.parse(JSON.stringify(upobj));
		                  					result.push(clone); 			
		                  				}
		                  				break;
	                  			}
	                  		}
	                  }
                  } 
                  
                } catch (e) {
    				this.errorHandling(e, null);
    			} 
    			return result;	
		},
		convertObjArrayToUploadForm: function(data){
			try{
                  var result = [],
                      upobj = {};
                      
                  // 일반 배열을 key-value 조합으로 변경한다. 
                  var pernr = "";
              	  var asmtYear = "";
              	  var aiType = "";
              	  var aiSeq = 0;
                  for (var d = 0; d < data.length; d++){
                  	  // 1. 가로 행별로 여러 행이 나온다!
                  	  pernr = "";
	                  asmtYear = "";
	                  aiType = "";
	                  
                  	  upobj = {};
                  	  
                  	  upobj.pernr = data[d].PERNR;
	  				  upobj.asmtYear = data[d].ASMT_YEAR;
	  				  upobj.aiType = data[d].AI_TYPE;
	  				  
	  				  if (d === 0 || data[d].PERNR !== data[d-1].PERNR){
	  				  		aiSeq = 0;
	  				  		upobj.aiSeq = aiSeq;
	  				  } else {
	  				  		aiSeq = aiSeq + 1;
	  				  		upobj.aiSeq = aiSeq;
	  				  }
	  				  
	  				  for (var key in data[d]) {
								upobj.aiId = key;
								upobj.aiResult = data[d][key];
								var clone = JSON.parse(JSON.stringify(upobj));
			            		result.push(clone); 									
					  }
	  				  
                  } 
                  
                } catch (e) {
    				this.errorHandling(e, null);
    			} 
    			return result;	
		},
		downloadFile: function(data, fileName, type){
			
			if(data === null){
				MessageBox.show("출력할 데이터가 없습니다.");
			}else{
			    //IE11 support
			    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
			        var blob = new Blob([data], {type: type});
			        window.navigator.msSaveOrOpenBlob(blob, fileName);
			    } else {// other browsers
			        
			        var a = jQuery("<a style='display: none;'/>");
				    var url = window.URL.createObjectURL(new Blob([data], {type: type}));
				    a.attr("href", url);
				    a.attr("download", fileName);
				    jQuery("body").append(a);
				    a[0].click();
				    window.URL.revokeObjectURL(url);
				    a.remove();

			    }
			}
		},
		addColumnSorterAndFilter: function(oColumn, comparator, oTable) {
			 /**
			 * Formatting 해버린 숫자들은 정렬이 잘 안되기 때문에 Custom 정렬로 대체함
			 */
			   var oCustomMenu = new sap.ui.commons.Menu();
			   
			    oCustomMenu.addItem(new sap.ui.commons.MenuItem({
			                text:"{i18n>sortAsc}",
			                icon:"sap-icon://sort-ascending",
			                select:function(oControlEvent) {
			                 var oSorter = new sap.ui.model.Sorter(oColumn.getSortProperty(), false);
			                 oSorter.fnCompare=comparator;
			                 oTable.getBinding("rows").sort(oSorter);
			                
			                 for (var i=0;i<oTable.getColumns().length; i++) oTable.getColumns()[i].setSorted(false);                
			                 oColumn.setSorted(true);
			                 oColumn.setSortOrder(sap.ui.table.SortOrder.Ascending);
			                }
			    }));
			    oCustomMenu.addItem(new sap.ui.commons.MenuItem({
						     text:"{i18n>sortDesc}",
						     icon:"sap-icon://sort-descending",
						        select:function(oControlEvent) {
						             var oSorter = new sap.ui.model.Sorter(oColumn.getSortProperty(), true);
						             oSorter.fnCompare=comparator;
						             oTable.getBinding("rows").sort(oSorter);
						                
						             for (var i=0;i<oTable.getColumns().length; i++) oTable.getColumns()[i].setSorted(false);
						            
						             oColumn.setSorted(true);
						             oColumn.setSortOrder(sap.ui.table.SortOrder.Descending);
						        }
			    }));
			   
			    oColumn.setMenu(oCustomMenu);
			    return oColumn;
		},
		compareIntegers: function (value1, value2) {
			  if ((value1 === null || value1 === undefined || value1 === "") &&
			  (value2 === null || value2 === undefined || value2 === "")) return 0;
			  if ((value1 === null || value1 === undefined || value1 === "")) return -1;
			  if ((value2 === null || value2 === undefined || value2 === "")) return 1;
			  if(parseInt(value1) < parseInt(value2)) return -1;
			  if(parseInt(value1) === parseInt(value2)) return 0;
			  if(parseInt(value1) > parseInt(value2)) return 1;           
		},
		compareObjectKey: function (obj1, obj2, keyArray) { // Object 비교
			//Loop through properties in object 1
			for (var p in obj1) {
				//Check property exists on both objects
				if (keyArray.includes(p)){ // Key field만 비교
					if (obj1.hasOwnProperty(p) !== obj2.hasOwnProperty(p)) return false;
					if (obj1[p] != obj2[p]) return false;	
				}
			}
		 
			return true;
		}
	};
});