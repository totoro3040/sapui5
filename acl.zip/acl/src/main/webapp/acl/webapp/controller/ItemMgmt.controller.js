sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox", 
	"sap/ui/export/Spreadsheet",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master"
], function (Controller,MessageBox,Spreadsheet,Common,Master) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.ItemMgmt", {

		onInit: function () {
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this.oRouter.getRoute("ItemMgmt").attachPatternMatched(this.onObjectMatched, this);
		},
		onObjectMatched: function (oEvent) {
			
			// 기준 로드
			Master.getMasterList(this);
			
			// Tree 항목 로드
			Master.getItemTree(this);
			
			// 진단항목 전체 로드
			Master.getItemList(this);
			
		},
		
		onExport: function() {
			
			var oModel = this.getView().getModel("item");
			var vData = oModel.getData().data;                         
			
			 var aColumns = [];
			  aColumns.push({
			  	label: "ID",
			  	property: "AiId"
			  });
			  
			  aColumns.push({
			    label: "Level1",
			    property: "Lv1Id"
			  });
			  
			  aColumns.push({
			    label: "Level2",
			    property: "Lv2Id"
			  });
			  
			  aColumns.push({
			    label: "Level3",
			    property: "Lv3Id"
			  });
			  
			  aColumns.push({
			    label: "Level4",
			    property: "Lv4Id"
			  });
			  
			  aColumns.push({
			    label: "Level5",
			    property: "Lv5Id"
			  });
			  
			  aColumns.push({
			    label: "Sorting Order",
			    property: "AiSeq",
			    type: "number",
			    scale: 0
			  });
			
			  var mSettings = {
			    workbook: {
			      columns: aColumns,
			      context: {
			        application: 'Debug Test Application',
			        version: '1.71.2',
			        title: 'Some random title',
			        modifiedBy: 'John Doe',
			        metaSheetName: 'Custom metadata',
			        metainfo: [
			          {
			            name: 'Grouped Properties',
			            items: [
			              { key: 'administrator', value: 'Foo Bar' },
			              { key: 'user', value: 'John Doe' },
			              { key: 'server', value: 'server.domain.local' }
			            ]
			          },
			          {
			            name: 'Another Group',
			            items: [
			              { key: 'property', value: 'value' },
			              { key: 'some', value: 'text' },
			              { key: 'fu', value: 'bar' }
			            ]
			          }
			        ]
			      },
			      hierarchyLevel: 'level'
			    },
			    dataSource: vData,
			    fileName: "salary.xlsx"
			  };
			  var oSpreadsheet = new sap.ui.export.Spreadsheet(mSettings);
			  oSpreadsheet.build();

		},

		onExit: function() {
			this._oMockServer.stop();
		}
	});

});