sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/doosan/acl/common/Common"
], function (Controller,Common) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.AppMain", {
		onInit: function () {
			//this.loadModel();
		},
		
		loadModel: function () {
			
			var oController = this;
			
			/* 1. 로그인한 사용자 정보 조회 */
			var oModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oModel, "session");
			oModel.loadData("/services/userapi/currentUser");
			oModel.attachRequestCompleted(function onCompleted(oEvent) {
				if (oEvent.getParameter("success")) {  
					this.setData({"json" : this.getJSON(), "status": "Success"}, true);
				} else {
					var msg = oEvent.getParameter("errorObject").textStatus;
					if (msg) {
						this.setData("status", msg);
					} else {
						this.setData("status", "Unknown error retrieving user info");
					}
				}
				$.userInfo = oEvent.getSource().getData().name;
			});
			/* End 1 */
			
			
			/* 1-2. 로그인한 사용자 세션 조회 */
			var userSession = {};
			
			var sSessionUrl = "/doosan_hanaxs_odata/data-mart/src/xsjs/UserSessionInfo.xsjs";
			var oSessionModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oSessionModel, "userSession");
			jQuery.ajax({
				url: sSessionUrl,
				type: "GET",
				success: function (userInfo) {
					
					/*
					* $UserId : ID (PERSON_ID)
					* $Timeout : Timeout (초)
					* $LastLogin : 최종접속일시
					* $AuthList : 권한리스트
					* $AuthTemplate : 템플릿 수정 권한
					* $UserName : 성명
					* $CompanyId : 인사영역코드
					* $CompanyName : 인사영역명
					* $UserLang : 언어
					* $UserCurrency : 통화
					*/
					userSession = userInfo;
					
					var userLang, userLangXs;
					if (userSession.$UserLang && userSession.$UserLang.length > 0){
						if (userSession.$UserLang === "3") {
							userLang = "ko";
							userLangXs = "3";
						} else {
							userLang = "en";
							userLangXs = "E";
						}
					
						Common.setLang(userLang,userLangXs);
					}
					
					oSessionModel.setData(userSession);
				},
				error: function (e) {
					Common.errorHandling(e, oController);
				},
				complete: function(){
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}
	});
});