sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox", 
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master"
], function (Controller,MessageBox,Common,Master) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.BasisMgmt", {

		onInit: function () {
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this.oRouter.getRoute("BasisMgmt").attachPatternMatched(this.onObjectMatched, this);
				
		},
		onObjectMatched: function (oEvent) {
			
			// 기준 로드
			Master.getMasterList(this);
			
			// Tree 항목 로드
			Master.getItemTree(this);
			
		},
		onSaveYear: function (oEvent) {
			/*
			* 데이터 저장 
			*/
			var oYearTable = this.getView().byId("basisYearTable");
			var oYearRows = oYearTable.getRows();
			
			var vYears = [], year, status;
			for (var r=0; r < oYearRows.length; r++){
				year = oYearRows[r].getCells()[0].getText();
				status = oYearRows[r].getCells()[1].getSelectedKey();
				
				if (year && status){ // getRows는 비어있는 행도 가져온다
					vYears.push({"year":year, "status":status});
				}
			}
			
			var oController = this;
			var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			
			if (vYears && vYears.length >0){
				var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtMstService.xsjs";
				try{
					$.ajax({
						url: sItemServicelUrl,
						type: "POST",
						data: {
							jsonParam: JSON.stringify({
								"type":"updateYears",
								"years":vYears
							})
						},
						success: function (results) {
							if (results && results.result === "success"){
								MessageBox.success(oBundle.getText("saveSuccess"));
							} else {
								MessageBox.error(oBundle.getText("saveFail") + " : " + results.error);
							}
						},
						error: function (e) {
							Common.errorHandling(e, oController);
						}
					});	
				}catch (ex) {
					Common.errorHandling(ex , oController);
				}
			} 
			
		}

	});

});