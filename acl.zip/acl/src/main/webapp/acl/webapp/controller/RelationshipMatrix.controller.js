/*eslint-disable no-console, no-alert, sap-no-ui5base-prop, no-eval */ 
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../common/Formatter",
	"sap/m/MessageBox",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/m/Token",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master"
], function (Controller,Formatter,MessageBox,ColumnListItem,Label,Token,Common,Master) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.RelationshipMatrix", {
		
		formatter: Formatter,
		_oSelectedInput : null,
		_oSelectedRowIndex : null,
		_oSourceEmpData : null,
		
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("ResultList").attachPatternMatched(this.onObjectMatched, this);
			this.onObjectMatched();
		},
		onObjectMatched: function (oEvent) {
			
			// 기준 로드
			Master.getMasterList(this);
			
			// 항목 로드
			Master.getItemTree(this);

			// 회사 리스트 조회
			Master.getUserAuthList(this);

			// 기본 Level 설정 (1)
			var oCustomModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCustomModel,"custom");
			
			this.messageBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

		},

		onSearch: function (oEvent) {
			this.refreshResultTable("result");
		},
		
		onExportData: function (oEvent) {
			this.refreshResultTable("excel");
		},
		
		onValueHelpPersaRequested: function(oEvent) {
			if (!this._oValueHelpDialog){
				this._oValueHelpDialog = sap.ui.xmlfragment("com.doosan.acl.fragment.ValueHelpDialog", this);
				this.getView().addDependent(this._oValueHelpDialog);
			}
			
			// 현재 선택된 행에 대한 정보 조회
			var oInput = oEvent.getSource();
			var oCell = oInput.getParent();
			this._oSelectedRowIndex = oCell.getIndex();
			
			var oAuthModel = this.getView().getModel("auth");
			var vPersaList = oAuthModel.getData().persa;
			
			var vMasterList = [];
			// persa가 Object list라서 array로 변환해준다.
			Object.keys(vPersaList).map(function(key) {
			  vMasterList.push({"key":vPersaList[key].PERSA, "text":vPersaList[key].PERSA_TX});
			});
			
			var oResultTable = this.getView().byId("resultTable");
	        var oTableData = oResultTable.getModel().getData().data;
	    	

			var oPersaModel = new sap.ui.model.json.JSONModel(vMasterList);
			this._oValueHelpDialog.setModel(oPersaModel,"master");
			this._oValueHelpDialog.open();
			this._oSelectedInput = oEvent.getSource();
		},
		
		onValueHelpDialogApply: function (oEvent) { 
			try{
				/*
				* Value Help Dialog에서 선택된 조직을 MultiInput 값으로 넣어준다.
				*/
			    var oContext = oEvent.getParameter("rowBindingContext");
			    var oData = oContext.getObject();
		        
		        this._oSelectedInput.setSelectedKey(oData.key);
		        //this._oSelectedInput.setValue(oData.text);
		        
		        // 선택된 행에서 데이터를 받아와서 업데이트 해준다.
		        var oResultTable = this.getView().byId("resultTable");
		        var oTableData = oResultTable.getModel().getData().data;
		        var oRowData = oTableData[this._oSelectedRowIndex];
		        console.log(oTableData);
		    	console.log(oRowData);
				this._oValueHelpDialog.close();
			} catch (e){
				Common.errorHandling(e, this);
			}
		},
		
		onValueHelpDialogClose: function (oEvent) { 
			try{
				this._oValueHelpDialog.close();
			} catch (e){
				Common.errorHandling(e, this);
			}
		},
		
		updateRowState: function(){
			
		},
		
		refreshResultTable: function (mode,nodata,exptCalc,colspan) {
			var oController = this;
			var targetTableId = "resultTable";
			var oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
			
			var oResultTable = this.getView().byId(targetTableId);
			oResultTable.setBusy(true);
			var oEmpCnt = oController.getView().byId("resultEmpCnt");
			oEmpCnt.setText("");

			// 데이터 Binding 이후의 Event 처리
			oResultTable.addDelegate({ onAfterRendering : function(oEvent){
					
					if (oEvent.type !== "AfterRendering"){
				      this.onvscroll(oEvent);
				    }
				    var rows = this.getVisibleRowCount();   //number of rows on tab
				    //var rowStart = this.getFirstVisibleRow();
				    var ctx;
				    
				    var vHeaderList = this.getModel("header").getData();
				    
				    for (var i=0; i<rows; i++){
				       //ctx = this.getContextByIndex(rowStart + i); //content
				       //this.getRows()[i].$().toggleClass("male",ctx?ctx.getObject().sex === 'm':false);
				       //var cellID = this.getRows()[i].getId();
				       var cellID = this.getRows()[i].getId();
            		   var cells = this.getRows()[i].getCells();
            		   
            		   for (var c = 0; c < cells.length; c++){
            		   		// 기본필드 (green)
            		   		// Pallette 
            		   		// Negative #FF8888
            		   		// Critical #FABD64
							// Positive #ABE2AB
							// Neutral	#D3D7D9
							// Information #91c8f6
            		   		if (c > 3){
            		   			$("#" + cellID + "-col" + c.toString()).css("background-color", "#EFF4F9");	
            		   		}
            		   }
				    }
				    
				}
			},oResultTable);	
			// Filter 값
			var year = this.getView().byId("filterYear").getSelectedKeys();
			var rv = this.getView().byId("filterRoleLevel").getSelectedKeys();
			var persa = this.getView().byId("filterPersa").getSelectedKeys();
			var mjf = this.getView().byId("filterMJF").getSelectedKeys();
			
			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/TemplateTableService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					type: "GET",
					data: {
						// nodata : Data는 조회하지 않음
						// exptCalc : 계산 항목은 제외
						jsonParam: JSON.stringify({
							"mode":mode,
							"asmtYear":year,
							"level":1,
							"items":["IT00000001"],
							"persa":persa,
							"rv":rv,
							"mjf":mjf,
							"fSe":false,
							"fPast":false,
							"exptCalc":exptCalc,
							"nodata":nodata,
							"colspan":colspan
						})
					},
					success: function (results) {
						// 테이블 정의 및 데이터 생성
						
						if (mode === "result"){
								var oHeaderData = results.headerList;
								//Common.makeColumn(oResultTable, oHeaderData);
								
								var oHeaderModel = new sap.ui.model.json.JSONModel(results.headerList);
								oResultTable.setModel(oHeaderModel,"header");
								
								try{
									var oBodyModel = new sap.ui.model.json.JSONModel();
									var tblData = { data:[] };
									tblData.data = results.data;
									oBodyModel.setData(tblData);
									oResultTable.setModel(oBodyModel);
									oResultTable.bindRows("/data");
									oEmpCnt.setText(oBundle.getText("assessee")+": "+results.cnt.EMP_CNT+ ""+oBundle.getText("headCountUnit") 
													+ "(" + oBundle.getText("executive") + " " + results.cnt.EX_CNT + "" + oBundle.getText("headCountUnit") 
													+ ", " + oBundle.getText("teamleader") + " " + results.cnt.TL_CNT + "" + oBundle.getText("headCountUnit") + ")"
													);
								} catch (ex) {
									Common.errorHandling(ex , oController);
								} finally {
									oResultTable.setBusy(false);	
								}
						}
						
						else if (mode === "excel"){
							
							var fileName = "AssessmentResult_"+ year +".xls";
					        
					        var responseType = "data:application/vnd.ms-excel";
					        Common.downloadFile(results,fileName,responseType);    
					        oResultTable.setBusy(false);	
						}
						
					},
					error: function (e) {
						Common.errorHandling(e, oController);
						oResultTable.setBusy(false);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}

		}
	});

});