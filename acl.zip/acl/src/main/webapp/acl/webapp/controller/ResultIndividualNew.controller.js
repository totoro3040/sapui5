/*eslint-disable no-console, no-alert, sap-no-ui5base-prop, no-eval, no-undef */ 
sap.ui.define([
	"sap/ui/Device",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master",
	"com/doosan/acl/common/Formatter",
	"sap/ui/model/BindingMode",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
    "sap/viz/ui5/data/FlattenedDataset",
    "sap/viz/ui5/format/ChartFormatter",
    "sap/viz/ui5/api/env/Format",
	"sap/m/SearchField"
], function (Device, Controller, MessageBox, Filter, Common, Master, Formatter, BindingMode, JSONModel, FeedItem, FlattenedDataset, ChartFormatter, Format, SearchField) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.ResultIndividualNew", {

		onInit: function () {
			
			// 기준 로드
			//Master.getMasterList(this);
			
			// 항목 로드
			//Master.getItemList(this);

			// 회사 리스트 조회
			//Master.getUserAuthList(this);
			
			// 진단대상자 Model
			var oEmpModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oEmpModel,"emp");
			
			//this.getEmpList();
			
			//Format.numericFormatter(ChartFormatter.getInstance());
            //this.formatPattern = ChartFormatter.DefaultPattern;            // set explored app's demo model on this sample
            
			//var oContainerPage = this.getView().byId("sideContentContainer");
			//oContainerPage.setBusy(true);
			
            
            this.messageBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

		},
		
		onSearchEmp: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Ename", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = this.byId("empList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "emp");
		},
		
		onSearchEmpEnable: function (oEvent) {
			// 좌측 진단대상자 검색창 표시
			var oDynamicSideContents = this.getView().byId("DynamicSideContent");
			oDynamicSideContents.setShowSideContent(true,false);
		
		},
		onEmpSelectionChange: function (oEvent) {
			
			// 사원이 선택되었을 때
			var oList = oEvent.getSource();
    		var oContexts = oList.getSelectedContexts();
			
			// PersonId, 사번을 알아낸다.
			var vPernr, vPersonId, vYear;
			if (oContexts && oContexts.length > 0){
				var sSelectedEmp = oContexts[0].getObject();
	    		vPernr = sSelectedEmp.Pernr;	
	    		vPersonId = sSelectedEmp.PersonId;
	    		vYear = sSelectedEmp.AsmtYear;	
			}
    		
    		if (!vPernr) {
    			Common.iMessageBox("error","alertNoEmpSelected",this);
    			return;
    		}
    		
    		// 개인별 Report 출력 시작
    		this.updateIndividualReportNew(vYear, vPernr, vPersonId);
		},
		
		updateIndividualReportNew: function (vYear,vPernr,vPersonId) {
			/*
			* 개인별 보고서 조회
			*/
			
			// 대상자 검색 창은 숨김
			var oDynamicSideContents = this.getView().byId("DynamicSideContent");
			oDynamicSideContents.setShowSideContent(false,false);
			
			// 1. 기본정보 조회
			this.refreshBasicInfo(vYear,vPernr,vPersonId);
			
			// 1.  종합comment
			this.refreshOverallCmnt(vYear,vPernr);
			
			// 2. 역량진단
			this.refreshSummaryComp(vYear,vPernr);
			
			// 2. 역량진단 Detail
			this.refreshDetailComp(vYear,vPernr);
			
			// 5. 다면진단 요약 결과 조회
			this.refreshSummaryMultiDim(vYear,vPernr);
			
		},
		
		refreshBasicInfo: function (vYear,vPernr,vPersonId){
			var oController = this;
			
			var oContainerPage = this.getView().byId("sideContentContainer");
			oContainerPage.setBusy(true);
			
			// 1-2. 소속 및 신상 정보
			var sEmpServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/EmpService.xsjs";
			var sData = {
				type:"getEmpBasicInfo",
				year:vYear,
				pernr:vPernr
			};
			Common.commonAjaxCall(sEmpServicelUrl,"POST",sData,oController,this.setBasicInfo);
		},
		
		refreshOverallCmnt: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oContainerPage = this.getView().byId("sideContentContainer");
			oContainerPage.setBusy(true);
			
			/* 1. 역량진단 커맨트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			
			var sData = {
				type : "getOverallComment",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setOverallComment);
			
		},
			
		refreshSummaryComp: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oContainerPage = this.getView().byId("sideContentContainer");
			oContainerPage.setBusy(true);
			
			/* 1. 역량진단 커맨트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			
			var sData = {
				type : "getCompetencyResultComment",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setSummaryCompComment);
			
			/* 2. 역량진단 차트 */
			var sDataChart = {
				type : "getCompetencyResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataChart,oController,this.setSummaryCompChart);
		},	
		
		refreshDetailComp: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oContainerPage = this.getView().byId("sideContentContainer");
			oContainerPage.setBusy(true);
			
			/* 1. 역량진단 Detail 커맨트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			
			var sData = {
				type : "getCompetencyResultCommentDetail",
				year : vYear,
				pernr : vPernr
			};
			//Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setDetailCompComment);
			
			/* 2. 역량진단 Detail 차트 */
			var sDataChart = {
				type : "getCompetencyResultChartDetail",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataChart,oController,this.setDetailCompChart);
		},	
		
		
		refreshSummaryMultiDim: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oContainerPage = this.getView().byId("sideContentContainer");
			oContainerPage.setBusy(true);
			
			/* 1. 다면진단 차트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sDataChart = {
				type : "getMultiDimensionResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			
			// 본인 vs 부하
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataChart,oController,this.setSummaryMultiDimChartSelf);
			
			// 본인 부하 vs 그룹 부하
			var sDataMultiChart = {
				type : "getMultiDimensionResultoverall",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataMultiChart,oController,this.setSummaryMultiDimChartOverall);
			
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataMultiChart,oController,this.setSummaryMultiDimChartOthers);
			
			// 부하 기준 Bar Chart
			var sDataBarChart = {
				type : "getMultiDimensionResultPerItemSort",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataBarChart,oController,this.setSummaryMultiDimChartBarchart);
			
			
			/* 1. 다면진단 커맨트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			
			var sData = {
				type : "getMultiResultComment",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setSummaryMultiComment);
		},
		
	
	
		setBasicInfo: function (result, oController) {
			var oBasicInfoModel = new sap.ui.model.json.JSONModel();
			oBasicInfoModel.setData(result);
			oController.getView().setModel(oBasicInfoModel,"basic"); 
			
			// Busy indicator 해제
			var oContainerPage = oController.getView().byId("sideContentContainer");
			setTimeout(function() {
			 oContainerPage.setBusy(false);
			}, 1000);
		},
		
		setOverallComment: function (result, oController) {
			/*
			* 진단결과 요약 : 역량진단 커맨트
			*/
			
			var oOverallCmntModel = new sap.ui.model.json.JSONModel();
			oOverallCmntModel.setData(result);
			
			var oOverallAcBox = oController.getView().byId("OveallCommentAC");
			oOverallAcBox.setModel(oOverallCmntModel);
			var oOverallMultiBox = oController.getView().byId("OveallCommentMulti");
			oOverallMultiBox.setModel(oOverallCmntModel);
			
			var oKnockOutBox = oController.getView().byId("KnockOut");
			oKnockOutBox.setModel(oOverallCmntModel);
			
			var oSummaryMultiBox = oController.getView().byId("SummaryMulti");
			oSummaryMultiBox.setModel(oOverallCmntModel);
		},
		
		setSummaryCompComment: function (result, oController) {
			/*
			* 진단결과 요약 : 역량진단 커맨트
			*/
			
			var oCompetencyCmntModel = new sap.ui.model.json.JSONModel();
			oCompetencyCmntModel.setData(result);
			var oCompetencyCmntBox = oController.getView().byId("summaryCompComment");
			oCompetencyCmntBox.setModel(oCompetencyCmntModel);
		},
		
		setDetailCompComment: function (result, oController) {
			/*
			* 진단결과 요약 : 역량진단 Detail 커맨트
			*/
			/*
			var oCompetencyCmntModel = new sap.ui.model.json.JSONModel();
			oCompetencyCmntModel.setData(result);
			var oCompetencyCmntBox = oController.getView().byId("summaryCompComment");
			oCompetencyCmntBox.setModel(oCompetencyCmntModel);
			*/
		},
		
		setSummaryMultiComment: function (result, oController) {
			/*
			* 진단결과 요약 : 다면진단 커맨트
			*/
			
			var oMultiCmntModel = new sap.ui.model.json.JSONModel();
			oMultiCmntModel.setData(result);
				
			// AI ID 가 AI00000491 일떄 (부하직원주관식)
			var oMultiSummCmntBox = oController.getView().byId("summaryMultiComment");
			oMultiSummCmntBox.setModel(oMultiCmntModel);
			
			// 아닐떄 
			var oMultioOverallCmntBox = oController.getView().byId("overallMultiComment");
			oMultioOverallCmntBox.setModel(oMultiCmntModel);
			
		},
		
		//역량진단 차트
		setSummaryCompChart: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("competencyVizFrame");
			var oPopover = oController.getView().byId("competencyPopover");
			
			// 차트 설정
			var vSetting = {
				chartType :"combination",
				dimensions : [
					{ name : "ClassTx",
					value : "{ClassTx}"},
					{ name : "ItemTx",
					value : "{ItemTx}"}
					
				],
				measures : [{
					name : "본인",
					value : "{Result}"
					},
					{
					name : "진단그룹전체",
					value : "{ResultRv}"
					}
				],
				properties : {
                    dataShape: {
                        primaryAxis: ["line", "bar"]
                    },
                	categoryAxis: {
                		label:{
                			style:{
                				"rules":
	                        [{ "dataContext": {"본인": {"min": 3}},
	                                "properties": {
	                                    "color":"sapUiChartPaletteSemanticGood"
	                                }
	                            }
	                        ],
	                        "others":
		                        {
		                            "properties": {
		                                 "color": "sapUiChartPaletteSemanticBad"
		                            }
		                        }
                			}
                        },
                			//style:{color:"red"}	
                		
	                    title: {
	                        visible: false
	                        }
	                },
	                valueAxis: {
	                	visible:false,
						title: {
	                        visible: false
	                    },
						scale : {
		                  fixedRange : true,
		                  minValue : 0,
		                  maxValue : 4.5
						}
					},
					plotArea: {
						gridline:{
		                    	visible : false
		                },
						colorPalette : d3.scale.category20().range(),	
						dataLabel: {
                            visible: true
                        }
					}
				}
			};
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
		},
		// 상세 역량진단 차트
		setDetailCompChart: function (result, oController) {
			
			// data 구조
			// ClassList 대항목
			// ClassList > ItemList 역량군
			// ClassList > ItemList 역량
			var oList = result.data;
			
			// 차트 설정
			var vSetting = {
				chartType :"bar",
				dimensions : [	{ name : "ItemDetailTx",
					value : "{ItemDetailTx}"}
				],
				measures : [{
					name : "본인",
					value : "{Result}"
					},
					{
					name : "진단대상자전체",
					value : "{ResultRv}"
					}
				],
				properties : {
					plotArea: {
						gridline:{
	                    	visible : false
	                    },
						colorPalette : d3.scale.category20().range(),
						dataLabel: {
	                        formatString: oController.formatPattern.SHORTFLOAT_MFD2,
	                        visible: true
	                    }
					},
					legend: {
                        visible: true
                    },
                    legendGroup: {
                    	layout: {
                    		position : "top"
                    	}	
                    },
					categoryAxis: {
						title:{
							visible: false
						},
						layout:{
							width: "220px"
						}
					},
					
					valueAxis: {
						visible:false,
						title:{
							visible: false
						},
						scale : {
		                  fixedRange : true,
		                  minValue : 1,
		                  maxValue : 4.5
		                }
					}
				}
			};
			
			// 대항목 별로 카드 ID가 다르다
			var targetCardId = "";
			oController.getView().byId("thoughtVBox").destroyItems();
			oController.getView().byId("performancceVBox").destroyItems();
			oController.getView().byId("peopleVBox").destroyItems();
			oController.getView().byId("selfVBox").destroyItems();
			for (var c = 0; c < oList.length; c++){ // oList = 대항목
				var oClassData = result.data[c];
				
				switch (oClassData.Class){
					case "IT00000010": 
						targetCardId = "thoughtVBox";
						break;
					case "IT00000011": 
						targetCardId = "performancceVBox";
						break;
					case "IT00000012": 
						targetCardId = "peopleVBox";
						break;
					case "IT00000013": 
						targetCardId = "selfVBox";
						break;
				}
				
				for (var r = 0; r < oClassData.ItemList.length; r++){ // 
					var oData = oClassData.ItemList[r];
				
					// 중항목 별 제목
					var oTitleVBox = new sap.m.VBox();
					var oTitle = new sap.m.Title();
					oTitle.setText(oData.ItemTx);
					oTitle.setLevel("H3");
					oTitleVBox.addItem(oTitle);
					
					// 차트 자리
					var oChartVBox = new sap.m.VBox();
					var oChartGridData = new sap.ui.layout.GridData();
					oChartGridData.setIndentS(0);
					oChartGridData.setSpanS(12);
					oChartGridData.setIndentM(0);
					oChartGridData.setSpanM(6);
					oChartGridData.setIndentL(0);
					oChartGridData.setSpanL(6);
					oChartGridData.setIndentXL(0);
					oChartGridData.setSpanXL(6);
					//var oVizFrameM = new sap.viz.ui5.controls.VizFrame(oData.Item);
					var oVizFrameM = new sap.viz.ui5.controls.VizFrame();
					oChartVBox.setLayoutData(oChartGridData);
					oChartVBox.addItem(oVizFrameM);
					var oPopoverM = new sap.viz.ui5.controls.Popover();
					oChartVBox.addItem(oPopoverM);
					
					
					// 커맨트 자리
					var oCommentVBox = new sap.m.VBox();
					var oCommentGridData = new sap.ui.layout.GridData();
					oCommentGridData.setIndentS(0);
					oCommentGridData.setSpanS(12);
					oCommentGridData.setIndentM(0);
					oCommentGridData.setSpanM(6);
					oCommentGridData.setIndentL(0);
					oCommentGridData.setSpanL(6);
					oCommentGridData.setIndentXL(0);
					oCommentGridData.setSpanXL(6);
					oCommentVBox.setLayoutData(oCommentGridData);
					
					var oComment = new sap.m.Text();
					oComment.setText(oData.Cmnt);
					oCommentVBox.addItem(oComment);
					
					// Container 내부에 하나씩 추가
					var oWrapper = oController.getView().byId(targetCardId);
					
					var oVBox = new sap.m.VBox();
					var oGrid = new sap.ui.layout.Grid();
					oGrid.addContent(oChartVBox);
					oGrid.addContent(oCommentVBox);
					oVBox.addItem(oTitleVBox);
					oVBox.addItem(oGrid);
					oWrapper.addItem(oVBox);
					
					// 항목 개수만큼 VizFrame 높이를 정해준다. 문제 : 책임이행
					// To-do : 책임이행 중항목과 소항목 구분해야함(차트에서)
					oVizFrameM.setWidth("100%");
					oVizFrameM.setHeight(oData.ItemList.length*80 + "px");
					
					// 차트 Rendering
					Common.makeChart(vSetting, oData.ItemList, oVizFrameM, oPopoverM);
				}
				
			}
			
		},

		//다면진단 본인 vs 부하
		setSummaryMultiDimChartSelf: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("MultiDimSelfVizFrame");
			var oPopover = oController.getView().byId("MultiDimSelfPopover");
			
			// 차트 설정
			var vSetting = {
				chartType : "line",
				dimensions :  [
					{ name : "ClassTx",
					value : "{ClassTx}"},
					{ name : "ItemTx",
					value : "{ItemTx}"}
					
				],
				measures : [{
					name : "부하",
					value : "{ResultMem}"
					},
					{
					name : "본인",
					value : "{ResultSelf}"
					}
				],
				properties : {
					plotArea: {
						colorPalette : d3.scale.category20().range(),
						dataLabel: {
	                        formatString: oController.formatPattern.SHORTFLOAT_MFD2,
	                        visible: true
	                    },
	                    gridline:{
	                    	visible : false
	                    },
	                    referenceLine: {
                                line: {
                                    valueAxis: [{
                                        value: 6.5,
                                        visible: true,
                                        color: "red",
                                        label: {
                                            text: "M (6.5)",
                                            visible: true,
                                            background: "red"
                                        }
                                    },{
                                        value: 5.5,
                                        visible: true,
                                        color: "orange",
                                        size:"1",
                                        label: {
                                            text: "HC (5.5)",
                                            visible: true,
                                            background: "orange"
                                        }
                                    },{
                                        value: 4.5,
                                        visible: true,
                                        color: "skyblue",
                                        label: {
                                            text: "C (4.5)",
                                            visible: true,
                                            background: "skyblue"
                                        }
                                    },{
                                        value: 3.5,
                                        visible: true,
                                        color: "blue",
                                        label: {
                                            text: "DN (3.5)",
                                            visible: true,
                                            background: "blue"
                                        }
                                    }]
                                }
                            }
					},
					categoryAxis: {
						title:{
							visible: false
						}	
					},
					valueAxis: {
						visible:false,
						title:{
							visible: false
						},
	                    scale : {
		                  fixedRange : true,
		                  minValue : 3,
		                  maxValue : 7
		                }
					},
					legendGroup: {
						layout: {
							alignment: "leftTop",
							position: "right" // top, right, auto, bottom
						}
					}
				}
			};
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
		},
		
		//다면진단 본인부하 vs 그룹부하
		setSummaryMultiDimChartOthers: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("MultiDimOthersVizFrame");
			var oPopover = oController.getView().byId("MultiDimOthersPopover");
			
			// 차트 설정
			var vSetting = {
				chartType : "line",
				dimensions :  [
					{ name : "ClassTx",
					value : "{ClassTx}"},
					{ name : "ItemTx",
					value : "{ItemTx}"}
					
				],
				measures : [{
					name : "부하",
					value : "{Result}"
					},
					{
					name : "전사",
					value : "{ResultRv}"
					}
				],
				properties : {
					plotArea: {
						colorPalette : d3.scale.category20().range(),
						dataLabel: {
	                        formatString: oController.formatPattern.SHORTFLOAT_MFD2,
	                        visible: true
	                    },
						gridline:{
		                    	visible : false
		                },
		                referenceLine: {
	                                line: {
	                                    valueAxis: [{
	                                        value: 6.5,
	                                        visible: true,
	                                        color: "red",
	                                        label: {
	                                            text: "M (6.5)",
	                                            visible: true,
	                                            background: "red"
	                                        }
	                                    },{
	                                        value: 5.5,
	                                        visible: true,
	                                        color: "orange",
	                                        size:"1",
	                                        label: {
	                                            text: "HC (5.5)",
	                                            visible: true,
	                                            background: "orange"
	                                        }
	                                    },{
	                                        value: 4.5,
	                                        visible: true,
	                                        color: "skyblue",
	                                        label: {
	                                            text: "C (4.5)",
	                                            visible: true,
	                                            background: "skyblue"
	                                        }
	                                    },{
	                                        value: 3.5,
	                                        visible: true,
	                                        color: "blue",
	                                        label: {
	                                            text: "DN (3.5)",
	                                            visible: true,
	                                            background: "blue"
	                                        }
	                                    }]
	                                }
	                       }
					},
					categoryAxis: {
						title:{
							visible: false
						}	
					},
					valueAxis: {
						visible:false,
						title:{
								visible: false
						},
	                    scale : {
		                  fixedRange : true,
		                  minValue : 3,
		                  maxValue : 7
		                }
					},
					legendGroup: {
						layout: {
							alignment: "leftTop",
							position: "right" // top, right, auto, bottom
						}
					}
				}
			};
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
		},
		
		//다면진단 (본인)부하 vs 부하(그룹)
		setSummaryMultiDimChartOverall: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("MultiDimChartOverallVizFrame");
			var oPopover = oController.getView().byId("MultiDimChartOverallPopover");
			
			// 차트 설정
			var vSetting = {
				chartType :"combination",
				dimensions :  [
					{ name : "ClassTx",
					value : "{ClassTx}"},
					{ name : "ItemTx",
					value : "{ItemTx}"}
					
				],
				measures : [{
					name : "부하(본인)",
					value : "{Result}"
					},
					{
					name : "부하(그룹)",
					value : "{ResultRv}"
					}
				],
				properties : {
                    dataShape: {
                        primaryAxis: ["line", "bar"]
                    },
                    categoryAxis: {
						title:{
							visible: false
						}	
					},
					valueAxis: {
						visible : false,
							title:{
								visible: false
							},
							scale : {
			                  fixedRange : true,
			                  minValue : 3,
		                	  maxValue : 7
							}
						},
					plotArea: {
						gridline:{
	                    	visible : false
	                    },
						colorPalette : d3.scale.category20().range(),	
						dataLabel: {
                            visible: true
                        }
					}
				}
			};
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
		},
		
		//다면진단 부하기준 Barchart
		setSummaryMultiDimChartBarchart: function (result, oController) {
			
			var oList = result.data;
			var cnt=0;
			
			for (var c = 0; c < oList.length; c++){ 
				var oCntData = oList[c];
				if(oCntData.ResultMem < 4.5) { cnt = cnt + 1; }
			}
			
			var oWrapper = oController.getView().byId("overallMultiCnt");
			oController.getView().byId("overallMultiCnt").destroyItems();
			var oComment = new sap.m.Text();
			oComment.setText(oList.length + "개 역량 중 "+ cnt + "개의 역량이 절대적 기준에서 개선이 필요한 것으로 나타남");
			oWrapper.addItem(oComment);
			
			var oVizFrame = oController.getView().byId("MultiDimBarchartVizFrame");
			var oPopover = oController.getView().byId("MultiDimBarchartPopover");
		
			// 차트 설정
			var vSetting = {
				chartType : "bar",
				dimensions : [{
					name : "ItemTx",
					value : "{ItemTx}"}
				],
				measures : [{
					name : "부하",
					value : "{ResultMem}"
					}
				],
				properties : {
					plotArea: {
						gridline:{
	                    	visible : false
	                    },
						dataPointStyle: {
	                        "rules":
	                        [
	                            {
	                                "dataContext": {"부하": {"min": 4.5}},
	                                "properties": {
	                                    "color":"sapUiChartPaletteSemanticGood"
	                                }
	                            }
	                        ],
	                        "others":
		                        {
		                        	
		                            "properties": {
		                                 "color": "sapUiChartPaletteSemanticBad"
		                            }
		                        }
                        },
						colorPalette : d3.scale.category20().range(),
						dataLabel: {
	                        formatString: oController.formatPattern.SHORTFLOAT_MFD2,
	                        visible: true
	                    },
	                    referenceLine: {
		                    line: {
		                        valueAxis: [{
		                            value: 4.5,
		                            visible: true,
		                            color:"red",
		                            label: {
		                                text: "4.5미만" ,
		                                visible: true,
		                                background: "red"
		                            }
		                        }]
		                    }
		                }
					},
					legend: {
                        visible: false
                    },
					categoryAxis: {
						title:{
							visible: false
						}	
					},
					valueAxis: {
						visible : false,
						title:{
							visible: false
						}
					},
				}
			};
			
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
			
		},
		
		getEmpList: function(){
			/*
			* 사용자 권한에 해당하는 진단대상자를 조회한다. 
			*/
			var sEmpServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/EmpService.xsjs";
			var oController = this;
			var sData = {};
			Common.commonAjaxCall(sEmpServicelUrl,"GET",sData,oController,this.setEmpList);
		},
		
		setEmpList: function(result, oController){
			var empList = { data : result };
			var oEmpModel = oController.getView().getModel("emp");
			oEmpModel.setData(empList);
			
			var oContainerPage = oController.getView().byId("sideContentContainer");
			setTimeout(function() {
			  oContainerPage.setBusy(false);
			}, 1000);
		}

	});

});