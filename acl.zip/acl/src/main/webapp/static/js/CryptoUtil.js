document.write("<script type='text/javascript' src='/static/vendor/crypto/aes.js'><"+"/script>");
document.write("<script type='text/javascript' src='/static/vendor/crypto/seed.js'><"+"/script>");
document.write("<script type='text/javascript' src='/static/vendor/crypto/sha256.js'><"+"/script>");

var CryptUtil = {
	// 암호화 관련 함수
	crypto : {
		aes : {
			key : '1234567890'
			,encrypt: function(value) {
				return encodeURI(CryptoJS.AES.encrypt(value, this.key).toString());
			}
			, decrypt: function(value) {
				return decodeURI(CryptoJS.AES.decrypt(value, this.key).toString(CryptoJS.enc.Utf8));
			}
		},
		seed : {
			key : '1234567890'
			,encrypt: function(value) {
				return encodeURI(CryptoJS.SEED.encrypt(value, this.key).toString());
			}
			, decrypt: function(value) {
				return decodeURI(CryptoJS.SEED.decrypt(value, this.key).toString(CryptoJS.enc.Utf8));
			}
		},
		sha256 : {
			encrypt: function(value) {
				return CryptoJS.SHA256.encrypt(value).toString();
			}
		}
	}
}
