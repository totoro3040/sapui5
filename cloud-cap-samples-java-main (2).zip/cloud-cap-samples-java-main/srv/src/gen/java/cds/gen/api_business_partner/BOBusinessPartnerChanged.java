package cds.gen.api_business_partner;

import com.sap.cds.CdsData;
import com.sap.cds.Struct;
import com.sap.cds.ql.CdsName;
import java.lang.String;
import java.util.Collection;

/**
 * Add asynchronous eventing API
 */
@CdsName("API_BUSINESS_PARTNER.BO_BusinessPartner_Changed")
public interface BOBusinessPartnerChanged extends CdsData {
  String KEY = "KEY";

  @CdsName(KEY)
  Collection<Key> getKey();

  @CdsName(KEY)
  void setKey(Collection<Key> key);

  static BOBusinessPartnerChanged create() {
    return Struct.create(BOBusinessPartnerChanged.class);
  }

  interface Key extends CdsData {
    String BUSINESSPARTNER = "BUSINESSPARTNER";

    @CdsName(BUSINESSPARTNER)
    String getBusinesspartner();

    @CdsName(BUSINESSPARTNER)
    void setBusinesspartner(String businesspartner);

    static Key create() {
      return Struct.create(Key.class);
    }
  }
}
