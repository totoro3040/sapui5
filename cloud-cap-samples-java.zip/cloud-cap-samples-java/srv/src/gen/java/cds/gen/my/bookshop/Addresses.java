package cds.gen.my.bookshop;

import com.sap.cds.CdsData;
import com.sap.cds.Struct;
import com.sap.cds.ql.CdsName;
import java.lang.Boolean;
import java.lang.String;

@CdsName("my.bookshop.Addresses")
public interface Addresses extends CdsData {
  String ADDRESS_ID = "AddressID";

  String BUSINESS_PARTNER = "BusinessPartner";

  String COUNTRY = "Country";

  String CITY_NAME = "CityName";

  String POSTAL_CODE = "PostalCode";

  String STREET_NAME = "StreetName";

  String HOUSE_NUMBER = "HouseNumber";

  String TOMBSTONE = "tombstone";

  @CdsName(ADDRESS_ID)
  String getAddressID();

  @CdsName(ADDRESS_ID)
  void setAddressID(String addressID);

  @CdsName(BUSINESS_PARTNER)
  String getBusinessPartner();

  @CdsName(BUSINESS_PARTNER)
  void setBusinessPartner(String businessPartner);

  @CdsName(COUNTRY)
  String getCountry();

  @CdsName(COUNTRY)
  void setCountry(String country);

  @CdsName(CITY_NAME)
  String getCityName();

  @CdsName(CITY_NAME)
  void setCityName(String cityName);

  @CdsName(POSTAL_CODE)
  String getPostalCode();

  @CdsName(POSTAL_CODE)
  void setPostalCode(String postalCode);

  @CdsName(STREET_NAME)
  String getStreetName();

  @CdsName(STREET_NAME)
  void setStreetName(String streetName);

  @CdsName(HOUSE_NUMBER)
  String getHouseNumber();

  @CdsName(HOUSE_NUMBER)
  void setHouseNumber(String houseNumber);

  Boolean getTombstone();

  void setTombstone(Boolean tombstone);

  Addresses_ ref();

  static Addresses create() {
    return Struct.create(Addresses.class);
  }
}
