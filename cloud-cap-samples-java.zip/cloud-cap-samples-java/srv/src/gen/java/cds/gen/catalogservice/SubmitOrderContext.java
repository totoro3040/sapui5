package cds.gen.catalogservice;

import com.sap.cds.services.EventContext;
import com.sap.cds.services.EventName;
import java.lang.Integer;
import java.lang.String;

@EventName("submitOrder")
public interface SubmitOrderContext extends EventContext {
  String BOOK = "book";

  String AMOUNT = "amount";

  String CDS_NAME = "submitOrder";

  String getBook();

  void setBook(String book);

  Integer getAmount();

  void setAmount(Integer amount);

  void setResult(ReturnCatalogServiceSubmitOrder result);

  ReturnCatalogServiceSubmitOrder getResult();

  static SubmitOrderContext create() {
    return EventContext.create(SubmitOrderContext.class, null);
  }
}
