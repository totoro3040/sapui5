package cds.gen.api_business_partner;

import com.sap.cds.ql.CdsName;
import java.lang.Class;
import java.lang.String;

@CdsName("API_BUSINESS_PARTNER")
public interface ApiBusinessPartner_ {
  String CDS_NAME = "API_BUSINESS_PARTNER";

  Class<AAddressPhoneNumber_> A_ADDRESS_PHONE_NUMBER = AAddressPhoneNumber_.class;

  Class<ASupplierDunning_> A_SUPPLIER_DUNNING = ASupplierDunning_.class;

  Class<ACustomerSalesAreaTax_> A_CUSTOMER_SALES_AREA_TAX = ACustomerSalesAreaTax_.class;

  Class<AAddressHomePageURL_> A_ADDRESS_HOME_PAGE_URL = AAddressHomePageURL_.class;

  Class<ASupplierPartnerFunc_> A_SUPPLIER_PARTNER_FUNC = ASupplierPartnerFunc_.class;

  Class<ABusinessPartnerAddress_> A_BUSINESS_PARTNER_ADDRESS = ABusinessPartnerAddress_.class;

  Class<ABusinessPartnerRole_> A_BUSINESS_PARTNER_ROLE = ABusinessPartnerRole_.class;

  Class<ACustomerDunning_> A_CUSTOMER_DUNNING = ACustomerDunning_.class;

  Class<ASupplierCompany_> A_SUPPLIER_COMPANY = ASupplierCompany_.class;

  Class<ACustomer_> A_CUSTOMER = ACustomer_.class;

  Class<ASupplierPurchasingOrg_> A_SUPPLIER_PURCHASING_ORG = ASupplierPurchasingOrg_.class;

  Class<ABPContactToFuncAndDept_> A_BPCONTACT_TO_FUNC_AND_DEPT = ABPContactToFuncAndDept_.class;

  Class<ABuPaIdentification_> A_BU_PA_IDENTIFICATION = ABuPaIdentification_.class;

  Class<ASupplierWithHoldingTax_> A_SUPPLIER_WITH_HOLDING_TAX = ASupplierWithHoldingTax_.class;

  Class<ABuPaAddressUsage_> A_BU_PA_ADDRESS_USAGE = ABuPaAddressUsage_.class;

  Class<ABuPaIndustry_> A_BU_PA_INDUSTRY = ABuPaIndustry_.class;

  Class<ACustomerWithHoldingTax_> A_CUSTOMER_WITH_HOLDING_TAX = ACustomerWithHoldingTax_.class;

  Class<ASupplier_> A_SUPPLIER = ASupplier_.class;

  Class<ACustomerCompany_> A_CUSTOMER_COMPANY = ACustomerCompany_.class;

  Class<AAddressEmailAddress_> A_ADDRESS_EMAIL_ADDRESS = AAddressEmailAddress_.class;

  Class<AAddressFaxNumber_> A_ADDRESS_FAX_NUMBER = AAddressFaxNumber_.class;

  Class<ABPContactToAddress_> A_BPCONTACT_TO_ADDRESS = ABPContactToAddress_.class;

  Class<ACustSalesPartnerFunc_> A_CUST_SALES_PARTNER_FUNC = ACustSalesPartnerFunc_.class;

  Class<ACustomerSalesArea_> A_CUSTOMER_SALES_AREA = ACustomerSalesArea_.class;

  Class<Addresses_> ADDRESSES = Addresses_.class;

  Class<ABusinessPartnerTaxNumber_> A_BUSINESS_PARTNER_TAX_NUMBER = ABusinessPartnerTaxNumber_.class;

  Class<ABusinessPartnerBank_> A_BUSINESS_PARTNER_BANK = ABusinessPartnerBank_.class;

  Class<ABusinessPartner_> A_BUSINESS_PARTNER = ABusinessPartner_.class;

  Class<ABusinessPartnerContact_> A_BUSINESS_PARTNER_CONTACT = ABusinessPartnerContact_.class;
}
