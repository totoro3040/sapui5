package cds.gen.api_business_partner;

import com.sap.cds.ql.CdsName;
import com.sap.cds.ql.ElementRef;
import com.sap.cds.ql.StructuredType;
import java.lang.String;

@CdsName("API_BUSINESS_PARTNER.Addresses")
public interface Addresses_ extends StructuredType<Addresses_> {
  String CDS_NAME = "API_BUSINESS_PARTNER.Addresses";

  ElementRef<String> AddressID();

  ElementRef<String> BusinessPartner();

  ElementRef<String> Country();

  ElementRef<String> CityName();

  ElementRef<String> PostalCode();

  ElementRef<String> StreetName();

  ElementRef<String> HouseNumber();
}
