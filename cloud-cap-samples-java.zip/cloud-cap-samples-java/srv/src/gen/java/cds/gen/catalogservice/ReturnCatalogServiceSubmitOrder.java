package cds.gen.catalogservice;

import com.sap.cds.CdsData;
import com.sap.cds.Struct;
import com.sap.cds.ql.CdsName;
import java.lang.Integer;
import java.lang.String;

@CdsName("CatalogService.return_CatalogService_submitOrder")
public interface ReturnCatalogServiceSubmitOrder extends CdsData {
  String STOCK = "stock";

  Integer getStock();

  void setStock(Integer stock);

  static ReturnCatalogServiceSubmitOrder create() {
    return Struct.create(ReturnCatalogServiceSubmitOrder.class);
  }
}
