package cds.gen.api_business_partner;

import com.sap.cds.services.EventContext;
import com.sap.cds.services.EventName;
import java.lang.String;

@EventName("BO_BusinessPartner_Changed")
public interface BOBusinessPartnerChangedContext extends EventContext {
  String CDS_NAME = "BO_BusinessPartner_Changed";

  BOBusinessPartnerChanged getData();

  void setData(BOBusinessPartnerChanged event);

  static BOBusinessPartnerChangedContext create() {
    return EventContext.create(BOBusinessPartnerChangedContext.class, null);
  }
}
