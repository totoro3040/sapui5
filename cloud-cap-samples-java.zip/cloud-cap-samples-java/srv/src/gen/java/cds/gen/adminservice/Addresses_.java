package cds.gen.adminservice;

import com.sap.cds.ql.CdsName;
import com.sap.cds.ql.ElementRef;
import com.sap.cds.ql.StructuredType;
import java.lang.Boolean;
import java.lang.String;

@CdsName("AdminService.Addresses")
public interface Addresses_ extends StructuredType<Addresses_> {
  String CDS_NAME = "AdminService.Addresses";

  ElementRef<String> AddressID();

  ElementRef<String> BusinessPartner();

  ElementRef<String> Country();

  ElementRef<String> CityName();

  ElementRef<String> PostalCode();

  ElementRef<String> StreetName();

  ElementRef<String> HouseNumber();

  ElementRef<Boolean> tombstone();
}
