package com.example.demo.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

	@RequestMapping(value = "/aa")
	public void getNullData(HttpServletResponse response) throws IOException {
		System.out.println("aa");
		response.getWriter().print("aaaa");
	}

	@RequestMapping(value = "/index")
	public String index(HttpServletResponse response) throws IOException {
		System.out.println("index");
		return "index";
	}
	
	@GetMapping("/")
	public String index() {
		System.out.println("root");
		return "index";
	}
	
}
