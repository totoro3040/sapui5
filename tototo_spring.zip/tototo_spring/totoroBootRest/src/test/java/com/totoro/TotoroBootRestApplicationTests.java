package com.totoro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TotoroBootRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
