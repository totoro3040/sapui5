CREATE TABLE member_table (
 seq        INT NOT NULL AUTO_INCREMENT,
 mb_id     VARCHAR(20),
 mb_pw    VARCHAR(20),
 address   VARCHAR(50),
 mb_tell    VARCHAR(50),  
  PRIMARY KEY(seq)
) ENGINE=MYISAM CHARSET=utf8;

alter table member_table2 engine=InnoDB;

insert into member_table2(mb_id, mb_pw, address) values('aa', 'aaaa', '경기도');


		SELECT 
			 seq
			,mb_id AS mbId
			,mb_pw as mbPw
            ,address
		  FROM member_table2 
		ORDER BY seq DESC;


SET SQL_SAFE_UPDATES = 0;

CREATE TABLE member (
 NUM        INT,
 NAME     VARCHAR(20),
 TITLE    VARCHAR(20),
 CONTENT   VARCHAR(50),
 READ_COUNT   VARCHAR(50),
 WRITE_DATE   DATE,
  PRIMARY KEY(NUM)
) ENGINE=MYISAM CHARSET=utf8;


	SELECT NUM
	     , NAME
	     , TITLE
	     , CONTENT
	     , READ_COUNT
	     , WRITE_DATE 
	  FROM TB_BOARD 
	 ORDER BY NUM DESC;
	
show tables;


CREATE TABLE IF NOT EXISTS MEMBER ( 
	MBR_NO BIGINT NOT NULL AUTO_INCREMENT, 
    ID VARCHAR(200), 
    NAME VARCHAR(200), 
    PRIMARY KEY(MBR_NO) 
    /*AUTO_INCREMENT 컬럼 단일 PK */ ) ENGINE=MYISAM CHARSET=utf8 engine=InnoDB;





