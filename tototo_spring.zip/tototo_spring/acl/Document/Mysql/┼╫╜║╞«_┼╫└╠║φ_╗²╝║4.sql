select * from select * from authorities;

CREATE TABLE member (
 seq        INT NOT NULL AUTO_INCREMENT,
 id     	VARCHAR(20),
 pw    		VARCHAR(80),
 addr   	VARCHAR(100),
 tell    	VARCHAR(20),
 cont		TEXT,
 sex	CHAR(1),
 money	DOUBLE,
 birthday	CHAR(1),
 agree	CHAR(1),
 marriage CHAR(1),
 fid VARCHAR(20),
 regdt   	DATETIME,
  PRIMARY KEY(seq)
) ENGINE=MYISAM CHARSET=utf8;

select * from member;
/*drop table member; */

insert into member(id, pw, addr, tell, regdt) values('id01', 'pwd01', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id02', 'pwd02', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id03', 'pwd03', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id04', 'pwd04', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id05', 'pwd05', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id06', 'pwd06', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id07', 'pwd07', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id08', 'pwd08', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id09', 'pwd09', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id10', 'pwd10', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id11', 'pwd11', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id12', 'pwd12', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id13', 'pwd13', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id14', 'pwd14', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id15', 'pwd15', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id16', 'pwd16', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id17', 'pwd17', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id18', 'pwd18', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id19', 'pwd19', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id20', 'pwd20', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id21', 'pwd21', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id22', 'pwd22', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id23', 'pwd23', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id24', 'pwd24', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id25', 'pwd25', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id26', 'pwd26', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id27', 'pwd27', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id28', 'pwd28', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id29', 'pwd29', '서울', '0111112222', NOW());
insert into member(id, pw, addr, tell, regdt) values('id30', 'pwd30', '서울', '0111112222', NOW());


commit;


