show tables;

select * from user;

drop table user;

CREATE TABLE user (
 email     VARCHAR(255),
 name    VARCHAR(255),
 create_date   timestamp,
  PRIMARY KEY(email)
) ENGINE=MYISAM CHARSET=utf8;

desc user;

insert into User(email,create_date,name) values('totoro@paran.com', NOW(), '윤혁신');