DELIMITER $$
DROP FUNCTION IF EXISTS testdb.F_CODENAME;

CREATE FUNCTION testdb.F_CODENAME(find_code VARCHAR(10)) RETURNS varchar(100)
BEGIN
   DECLARE getname varchar(100);
   SET getname = null;

   SELECT CODE_NAME  INTO getname from testdb.COMMON_CODE where CODE=find_code;   
   
   RETURN getname;

END $$

DELIMITER ;