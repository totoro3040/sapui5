SET SQL_SAFE_UPDATES = 0;

select * from member_table;

select * from member_table2;

delete from member_table;
delete from member_table2;

update member_table
set mb_id = 'aa'
where mb_id = 'dd';

insert into member_table2(mb_id, mb_pw, address) values('aa', 'aaaa', '경기도');



