SET SQL_SAFE_UPDATES = 0;

select * from member_table;

select * from member_table2;

delete from member_table;
delete from member_table2;

update member_table
set mb_id = 'aa'
where mb_id = 'dd';

select * from user;

show tables;

select * from User u order by u.name;

desc User;

insert into User(email,create_date,name) values('totoro@paran.com', NOW(), '윤혁신');