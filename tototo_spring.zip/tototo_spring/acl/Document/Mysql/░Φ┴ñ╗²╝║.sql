show databases;

show tables;

select * from user;

create database testDB default character set utf8;

create user test_DB@'%' identified by '123456@';

grant all privileges on testDB.* to 'test_DB'@'%';

flush privileges; 

/* ------------------- */

create database totoroDB default character set utf8;

create user totoro@'%' identified by '4480328';

grant all privileges on totoroDB.* to 'totoro'@'%';

flush privileges; 


/* 
GRANT INSERT,UPDATE,INDEX,ALTER ON on testdb.* TO 'testuser'@'localhost'; 
grant all privileges on test_DB.* to test_DB@'%' identified by '123456@';

drop user '사용자ID'@localhost;    // 사용자 삭제
drop database DB명;       // 데이터베이스 삭제

mysql > GRANT ALL PRIVILEGES ON DB명.테이블 TO 계정아이디@host IDENTIFIED BY '비밀번호';

// 계정이 이미 존재 하는데 'identified by '비밀번호' 부분을 추가하면 비밀번호가 변경된다

mysql> GRANT ALL privileges ON DB명.* TO 계정아이디@locahost IDENTIFIED BY '비밀번호';
mysql> GRANT ALL privileges ON DB명.* TO 계정아이디@'%' IDENTIFIED BY '비밀번호';

mysql > grant all privileges on DB명.* to userid@'%' identified by '비밀번호' ;  //모든 원격지에서 접속 권한 추가 
host에 '200.100.%' 로 하면 IP주소가 200.100.X.X 로 시작되는 모든 IP에서 원격 접속을 허용한다는 의미
host에 '200.100.100.50' 으로 하면 IP주소가 200.100.100.50 인 곳에서만 원격 접속을 허용한다는 의미

mysql > grant all privileges on test.* to userid@localhost identified by '비밀번호';
// user 에게 test 데이터베이스 모든 테이블에 대한 권한 부여 

mysql> grant select, insert, update on test.* to user@localhost identified by '비밀번호';
// user 에게 test 데이터베이스 모든 테이블에 select, insert, update 권한 부여

mysql> grant select, insert, update on test.* to user@localhost;   -- 패스워드는 변경없이 권한만 부여하는 경우
// user 에게 test 데이터베이스 모든 테이블에 select, insert, update 권한 부여

mysql> grant all privileges on *.* to user@localhost identified by '비밀번호' with grant option;
// user 에게 모든 데이터베이스 모든 테이블에 권한 부여
// 전역 권한은 모두 광범위한 보안문제가 수반되므로 권한을 허용하는 경우 신중해야 함


mysql > flush privileges;     // 변경된 내용을 메모리에 반영(권한 적용)


*/



