select EMP.*,
   PER.GBDAT as BIRTH_DATE,
   '40' as AGE,
   DATE.BASE02 as DATE_OF_EMPLOYMENT
  from AC_ASSESSEE_EMP EMP
	  inner join AT_ACTION_MASTER MST on EMP.PERNR = MST.PERNR and current_date between mst.BEGDA and mst.ENDDA
 	  left join AT_PERSONAL_DATA PER on EMP.PERNR = PER.PERNR
 	  left join AT_BASE_DATE DATE on EMP.PERNR = DATE.PERNR and current_date between DATE.BEGDA and DATE.ENDDA 
   where  EMP.PERSA in (select AUTH_ID from AC_USER_AUTH  where user_id = 'aaa')
   
==============================   

select EMP.*,
   PER.GBDAT as BIRTH_DATE,
   '40' as AGE,
   DATE.BASE02 as DATE_OF_EMPLOYMENT,
   FN_GET_SERVICE_YEARS(DATE.BASE02,current_date,?) as YEARS_OF_SERVICE
  from AC_ASSESSEE_EMP EMP
	 inner join AT_ACTION_MASTER MST on EMP.PERNR = MST.PERNR and current_date between mst.BEGDA and mst.ENDDA
 	left join AT_PERSONAL_DATA PER on EMP.PERNR = PER.PERNR
 	left join AT_BASE_DATE DATE on EMP.PERNR = DATE.PERNR and current_date between DATE.BEGDA and DATE.ENDDA 
        	                    where  EMP.PERSA in (select AUTH_ID from AC_USER_AUTH
                         where user_id = 'aaa')
                         
=================

select EMP.*,
   (SELECT TO_CHAR(TO_NUMBER(MAX(PERSON_ID))) FROM  AT_PERNR_MASTER WHERE PERNR = EMP.PERNR) AS PERSON_ID,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'PERSA' AND LANG = '3' AND CODE = EMP.PERSA) AS PERSA_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'CNBBG' AND LANG = '3' AND PCODE1||'|'||CODE = EMP.BG) AS BG_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AC_CODE_CUSTOM WHERE TYPE = 'ROLE_LEVEL' AND LANG = '3' AND CODE = EMP.ROLE_LEVEL) AS ROLE_LEVEL_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'ZZCALTL' AND LANG = '3' AND CODE = MST.ZZCALTL) AS CALLING_TITLE_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'ZZMJF' AND LANG = '3' AND CODE = EMP.MJF) AS MJF_TEXT_KO,
   PER.GBDAT as BIRTH_DATE,
   '40' as AGE,
   DATE.BASE02 as DATE_OF_EMPLOYMENT,
   FN_GET_SERVICE_YEARS(DATE.BASE02,current_date,?) as YEARS_OF_SERVICE
  from AC_ASSESSEE_EMP EMP
	 inner join AT_ACTION_MASTER MST on EMP.PERNR = MST.PERNR and current_date between mst.BEGDA and mst.ENDDA
 	left join AT_PERSONAL_DATA PER on EMP.PERNR = PER.PERNR
 	left join AT_BASE_DATE DATE on EMP.PERNR = DATE.PERNR and current_date between DATE.BEGDA and DATE.ENDDA 
        	                    where  EMP.PERSA in (select AUTH_ID from AC_USER_AUTH
                         where user_id = 'aaa')
                         
=========================================================                         
AT_PERSONAL_DATA  PER.PERNR  PER.GBDAT

select EMP.*,
   (SELECT TO_CHAR(TO_NUMBER(MAX(PERSON_ID))) FROM  AT_PERNR_MASTER WHERE PERNR = EMP.PERNR) AS PERSON_ID,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'PERSA' AND LANG = '3' AND CODE = EMP.PERSA) AS PERSA_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'CNBBG' AND LANG = '3' AND PCODE1||'|'||CODE = EMP.BG) AS BG_TEXT_KO,
   (SELECT MAX(TEXT) FROM  DSGAC"."AC_CODE_CUSTOM WHERE TYPE = 'ROLE_LEVEL' AND LANG = '3' AND CODE = EMP.ROLE_LEVEL) AS ROLE_LEVEL_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'ZZCALTL' AND LANG = '3' AND CODE = MST.ZZCALTL) AS CALLING_TITLE_TEXT_KO,
   (SELECT MAX(TEXT) FROM  AT_CODE_MASTER WHERE TYPE = 'ZZMJF' AND LANG = '3' AND CODE = EMP.MJF) AS MJF_TEXT_KO,
   PER.GBDAT as BIRTH_DATE,
   FN_GET_AGE(PER.GBDAT,current_date) as AGE,
   DATE.BASE02 as DATE_OF_EMPLOYMENT,
   FN_GET_SERVICE_YEARS(DATE.BASE02,current_date,?) as YEARS_OF_SERVICE
  from AC_ASSESSEE_EMP EMP
	 inner join AT_ACTION_MASTER MST on EMP.PERNR = MST.PERNR and current_date between mst.BEGDA and mst.ENDDA
 	left join AT_PERSONAL_DATA PER on EMP.PERNR = PER.PERNR
 	left join AT_BASE_DATE DATE on EMP.PERNR = DATE.PERNR and current_date between DATE.BEGDA and DATE.ENDDA 
        	                    where  EMP.PERSA in (select AUTH_ID from AC_USER_AUTH
                         where user_id = 'aaa');
                         
                         