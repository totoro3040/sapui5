select ASMT_YEAR, PERNR, LV1_TEXT_KO, LV2_TEXT_KO, AI_RESULT
 from AT_ASSESSMENT_RESULT_CMNT
 where ASMT_YEAR = '2021'
     AND PERNR = '1000'
     AND LV1_ID = 'IT00000001'
     AND LV2_ID IS NULL
 order by lv1_id, LV1_TEXT_KO, lv2_text_ko, lv2_id

===========
insert into AT_ASSESSMENT_RESULT_CMNT(ASMT_YEAR, PERNR, LV1_TEXT_KO, LV2_TEXT_KO, AI_RESULT, LV1_ID, LV2_ID) value('2021', '1000', '��Ÿ1', '��Ÿ2', 'XXX', 'IT00000001', null);
