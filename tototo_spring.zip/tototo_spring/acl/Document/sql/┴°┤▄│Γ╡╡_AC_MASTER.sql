
CREATE TABLE AC_MASTER
(
	ASMT_YEAR            VARCHAR(20)  NOT NULL,
	ASMT_STATUS          VARCHAR(20) NULL,
	ASMT_CNT         INTEGER NULL,
	EX_CNT         INTEGER NULL,
	TL_CNT         INTEGER NULL
);

INSERT INTO AC_MASTER(ASMT_YEAR, ASMT_STATUS, ASMT_CNT, EX_CNT, TL_CNT) VALUES('2018', 'X', 10, 20, 30);
INSERT INTO AC_MASTER(ASMT_YEAR, ASMT_STATUS, ASMT_CNT, EX_CNT, TL_CNT) VALUES('2019', 'X', 10, 20, 30);
INSERT INTO AC_MASTER(ASMT_YEAR, ASMT_STATUS, ASMT_CNT, EX_CNT, TL_CNT) VALUES('2020', 'X', 10, 20, 30);
INSERT INTO AC_MASTER(ASMT_YEAR, ASMT_STATUS, ASMT_CNT, EX_CNT, TL_CNT) VALUES('2021', 'X', 10, 20, 30);


        		  /* ���� ��ȸ  */
        		  var asmtMstListSql = 'select mst.ASMT_YEAR, mst.ASMT_STATUS, '
        		                + ' (select to_char(count(*)) from "DSGAC"."AC_ASSESSEE_EMP" where ASMT_YEAR = mst.ASMT_YEAR) as ASMT_CNT, '
        		                + ' (select to_char(count(*)) from "DSGAC"."AC_ASSESSEE_EMP" where ASMT_YEAR = mst.ASMT_YEAR and ROLE_LEVEL = ?) as EX_CNT, '
        		                + ' (select to_char(count(*)) from "DSGAC"."AC_ASSESSEE_EMP" where ASMT_YEAR = mst.ASMT_YEAR and ROLE_LEVEL = ?) as TL_CNT '
        	                    + ' from "DSGAC"."AC_MASTER" mst'
        	                    + ' order by mst.ASMT_YEAR';
        	    
             	  var conn = $.hdb.getConnection();
             	  var result = conn.executeQuery(asmtMstListSql,"EX","TL");
             	  
             	  var curYear = "";
             	  if (result && result.length > 0){
             	      for (var al = 0; al < result.length; al++){
             	            
             	            asmtMstList.push({
             	                "status" : result[al].ASMT_STATUS,
             	                "year" : result[al].ASMT_YEAR,
             	                "cnt" : result[al].ASMT_CNT,
             	                "exCnt" : result[al].EX_CNT,
             	                "tlCnt" : result[al].TL_CNT
             	            });