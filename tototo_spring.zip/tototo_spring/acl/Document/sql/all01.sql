
CREATE TABLE AC_TEMPLATE_MASTER
(
	TEMPLATE_ID          VARCHAR(100) NULL,
	TEMPLATE_TEXT_KO     VARCHAR(100) NULL,
	TEMPLATE_DESC_KO     VARCHAR(100) NULL,
	MODE                 VARCHAR(100) NULL,
	RV                   VARCHAR(100) NULL,
	F_EXPT_CALC          VARCHAR(100) NULL,
	F_NODATA             VARCHAR(100) NULL,
	F_COLSPAN            VARCHAR(100) NULL,
	F_HIDDEN             VARCHAR(100) NULL,
	SEQ                  INTEGER NULL,
	ICON                 VARCHAR(100) NULL,
	INDICATOR            VARCHAR(100) NULL
);



CREATE TABLE AC_ASSESSMENT_RESULT
(
	ASMT_YEAR            VARCHAR(100) NOT NULL,
	PERNR                VARCHAR(100) NOT NULL,
	AI_ID                VARCHAR(100) NOT NULL,
	AI_SEQ               INTEGER NOT NULL,
	AI_RESULT            VARCHAR(100) NULL,
	AI_TYPE              VARCHAR(100) NULL,
	UPDATE_DT            VARCHAR(100) NULL
);

CREATE TABLE AC_ASSESSMENT_RESULT_CALC
(
	PERNR                VARCHAR(100) NOT NULL,
	AI_ID                VARCHAR(100) NOT NULL,
	LV1_ID               VARCHAR(100) NULL,
	LV2_ID               VARCHAR(100) NULL,
	LV3_ID               VARCHAR(100) NULL,
	LV4_ID               VARCHAR(100) NULL,
	LV5_ID               VARCHAR(100) NULL,
	F_RAW                VARCHAR(100) NULL,
	F_CALC               VARCHAR(100) NULL,
	CALC_METHOD          VARCHAR(100) NULL,
	F_LEVEL              INTEGER NULL,
	ASMT_YEAR            VARCHAR(100) NOT NULL
);

CREATE TABLE AC_ASSESSMENT_RESULT_COMMENT
(
	PERNR                VARCHAR(100) NOT NULL,
	AI_ID                VARCHAR(100) NOT NULL,
	LV1_ID               VARCHAR(100) NULL,
	LV2_ID               VARCHAR(100) NULL,
	LV3_ID               VARCHAR(100) NULL,
	LV4_ID               VARCHAR(100) NULL,
	LV5_ID               VARCHAR(100) NULL,
	F_LEVEL              VARCHAR(100) NULL,
	ASMT_YEAR            VARCHAR(100) NOT NULL,
	AI_RESULT            VARCHAR(100) NULL,
	AI_SEQ               INTEGER NULL,
	AI_TYPE              VARCHAR(100) NULL
);

CREATE TABLE AC_USER_AUTH
(
	USER_ID              VARCHAR(100) NOT NULL,
	AUTH_TYPE            VARCHAR(100) NULL,
	AUTH_ID              VARCHAR(100) NOT NULL,
	AUTH_SEQ             INTEGER NULL
);


CREATE TABLE AC_ASSESSEE_EMP
(
	ASMT_YEAR            VARCHAR(100) NOT NULL,
	BG                   VARCHAR(100) NULL,
	ENAME                VARCHAR(100) NULL,
	MJF                  VARCHAR(100) NULL,
	ORGEH                VARCHAR(100) NULL,
	PERNR                VARCHAR(100) NOT NULL,
	PERSA                VARCHAR(100) NULL,
	ROLE_LEVEL           VARCHAR(100) NULL
);



DROP TABLE AC_CODE_CUSTOM;
CREATE TABLE AC_CODE_CUSTOM
(
	TYPE                 CHAR(18) NOT NULL,
	CODE                 CHAR(18) NOT NULL,
	PCODE1               CHAR(18) NULL,
	LANG                 CHAR(18) NULL,
	AUTH_CODE_KEY1       CHAR(18) NULL,
	AUTH_CODE_KEY2       CHAR(18) NULL,
	TEXT                 CHAR(18) NULL,
	ACTIVE               CHAR(18) NULL
);


CREATE TABLE AC_ITEM_MASTER
(
	ITEM_ID              VARCHAR(100) NOT NULL,
	LV2_TEXT_KO          VARCHAR(100) NULL
);


DROP TABLE AT_ACTION_MASTER;
CREATE TABLE AT_ACTION_MASTER
(
	PERNR                VARCHAR(100) NULL,
	BEGDA                VARCHAR(100) NULL,
	ENDDA                VARCHAR(100) NULL,
	ZZCALTL              VARCHAR(100) NULL
);



CREATE TABLE AT_PERSONAL_DATA
(
	PERNR                VARCHAR(100) NULL,
	GBDAT                VARCHAR(100) NULL
);



CREATE TABLE AT_BASE_DATE
(
	PERSON_ID            VARCHAR(100) NULL,
	PERNR                VARCHAR(100) NULL,
	BEGDA                VARCHAR(100) NULL,
	ENDDA                VARCHAR(100) NULL,
	BASE01               VARCHAR(100) NULL,
	BASE02               VARCHAR(100) NULL,
	BASE03               VARCHAR(100) NULL,
	BASE04               VARCHAR(100) NULL,
	BASE05               VARCHAR(100) NULL
);


---------------- �ӽû��� ----------

CREATE TABLE AT_ASSESSMENT_RESULT_CALC ( 
ASMT_YEAR                   VARCHAR(100) NULL,
PERNR                   VARCHAR(100) NULL,
AI_RESULT                   VARCHAR(100) NULL,
AI_ID                   VARCHAR(100) NULL,
LV1_ID                   VARCHAR(100) NULL,
LV1_TEXT_KO                   VARCHAR(100) NULL,
LV2_ID                   VARCHAR(100) NULL,
LV2_TEXT_KO                   VARCHAR(100) NULL,
LV3_ID                   VARCHAR(100) NULL,
LV3_TEXT_KO                   VARCHAR(100) NULL,
LV4_ID                   VARCHAR(100) NULL,
LV4_TEXT_KO                   VARCHAR(100) NULL,
LV5_ID                   VARCHAR(100) NULL,
LV5_TEXT_KO                   VARCHAR(100) NULL,
F_SE                   VARCHAR(100) NULL,
F_CALC                   VARCHAR(100) NULL,
CALC_METHOD                   VARCHAR(100) NULL,
AI_TYPE                   VARCHAR(100) NULL,
AI_DEC_SIZE                   VARCHAR(100) NULL,
CODE_TYPE                   VARCHAR(100) NULL,
FUNC_CALL                   VARCHAR(100) NULL,
AI_SEQ                   VARCHAR(100) NULL,
F_NUM                   VARCHAR(100) NULL,
ITEM_TYPE                   VARCHAR(100) NULL,
F_LEVEL                   VARCHAR(100) NULL
 ) ;

CREATE TABLE AT_ASSESSMENT_RESULT_CMNT ( 
	ASMT_YEAR                  VARCHAR(100) NULL,
	PERNR                  VARCHAR(100) NULL,
	AI_RESULT                  VARCHAR(100) NULL,
	RES_SEQ                  VARCHAR(100) NULL,
	RES_TYPE                  VARCHAR(100) NULL,
	AI_ID                  VARCHAR(100) NULL,
	LV1_ID                  VARCHAR(100) NULL,
	LV1_TEXT_KO                  VARCHAR(100) NULL,
	LV2_ID                  VARCHAR(100) NULL,
	LV2_TEXT_KO                  VARCHAR(100) NULL,
	LV3_ID                  VARCHAR(100) NULL,
	LV3_TEXT_KO                  VARCHAR(100) NULL,
	LV4_ID                  VARCHAR(100) NULL,
	LV4_TEXT_KO                  VARCHAR(100) NULL,
	LV5_ID                  VARCHAR(100) NULL,
	LV5_TEXT_KO                  VARCHAR(100) NULL,
	F_SE                  VARCHAR(100) NULL,
	F_CALC                  VARCHAR(100) NULL,
	CALC_METHOD                  VARCHAR(100) NULL,
	AI_TYPE                  VARCHAR(100) NULL,
	AI_DEC_SIZE                  VARCHAR(100) NULL,
	CODE_TYPE                  VARCHAR(100) NULL,
	FUNC_CALL                  VARCHAR(100) NULL,
	AI_SEQ                  VARCHAR(100) NULL,
	F_NUM                  VARCHAR(100) NULL,
	ITEM_TYPE                 VARCHAR(100) NULL
	);

