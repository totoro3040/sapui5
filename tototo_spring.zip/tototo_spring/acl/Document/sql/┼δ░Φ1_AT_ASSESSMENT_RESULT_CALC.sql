SELECT 
    AC.ASMT_YEAR,
    AC.PERNR,
    AC.AC_SCORE,
    AC.AC_RANK,
    AC.AC_PERCENT,
    AC.MULTI_MEM_SCORE,
    AC.MULTI_MGR_SCORE,
    AC.MULTI_MEM_RANK,
    AC.MULTI_MEM_PERCENT,
    AC.KNOCKOUT,
    (SELECT  TEXT FROM AC_CODE_CUSTOM
        WHERE type = 'AC_GRADE' AND code = AC.AC_RANK) AS AC_RANK_TXT,
    (SELECT text
        FROM AC_CODE_CUSTOM
        WHERE type = 'AC_GRADE' AND code = AC.MULTI_MEM_RANK) AS MULTI_RANK_TXT,
    CAST(AC.MULTI_MEM_SCORE AS UNSIGNED) - CAST(AC.MULTI_MGR_SCORE AS UNSIGNED) AS MULTI_DIFF_SCORE
FROM
    (SELECT 
        ASMT_YEAR,
            PERNR,
            MAX(IF(AI_ID = 'AI00000144', AI_RESULT, '')) AC_SCORE,
            MAX(IF(AI_ID = 'AI00000459', AI_RESULT, '')) AC_RANK,
            MAX(IF(AI_ID = 'AI00000465', AI_RESULT, '')) AC_PERCENT,
            MAX(IF(AI_ID = 'AI00000234', AI_RESULT, '')) MULTI_MEM_SCORE,
            MAX(IF(AI_ID = 'AI00000295', AI_RESULT, '')) MULTI_MGR_SCORE,
            MAX(IF(AI_ID = 'AI00000466', AI_RESULT, '')) MULTI_MEM_RANK,
            MAX(IF(AI_ID = 'AI00000468', AI_RESULT, '')) MULTI_MEM_PERCENT,
            MAX(IF(AI_ID = 'AI00000339', AI_RESULT, '')) KNOCKOUT
    FROM
        AT_ASSESSMENT_RESULT_CALC
    WHERE
        ASMT_YEAR = '2021' AND PERNR = '1000'
    GROUP BY ASMT_YEAR , PERNR) AC
    
    
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000144', '90');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000459', 'MSF');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000465', '5');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000234', '50');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000295', '50');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000466', 'MSF');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000468', '10');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, AI_ID, AI_RESULT) value('2021', '1000', 'AI00000339', 'XXXX');

--�������� ���� �����ȸ
-- �������� ���׸� �����ȸ
-- selectCompetencyResultChartDetail, selectCompetencyResultChartDetail2, selectCompetencyResultChartDetail3
delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000001' AND LV2_ID != ''  AND LV3_ID != '' AND F_CALC = 'X' AND  F_SE != 'X';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000010', 'IT020101',  'IT02010101', 'IT0201010101', 'X', 'Y', 'Level1 1', 'Level2 1', 'Level3-1', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '1');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000010', 'IT020101',  'IT02010101', 'IT0201010102', 'X', 'Y', 'Level1 2', 'Level2 2', 'Level3-2', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '2');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000010', 'IT020101',  'IT02010102', 'IT0201010203', 'X', 'Y', 'Level1 3', 'Level2 3', 'Level3 3', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '3');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000010', 'IT020102',  'IT02010202', 'IT0201020204', 'X', 'Y', 'Level1 4', 'Level2 4', 'Level3 4', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '4');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000010', 'IT020102',  'IT02010203', 'IT0201020305', 'X', 'Y', 'Level1 5', 'Level2 5', 'Level3 5', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '5');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000010', 'IT020202',  'IT02020203', 'IT0202020306', 'X', 'Y', 'Level1 6', 'Level2 6', 'Level3 6', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '6');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000011', 'IT020203',  'IT02020304', 'IT0202030407', 'X', 'Y', 'Level1 7', 'Level2 7', 'Level3 7', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '7');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000011', 'IT020203',  'IT02020304', 'IT0202030408', 'X', 'Y', 'Level1 8', 'Level2 8', 'Level3 8', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '8');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000011', 'IT020203',  'IT02020305', 'IT0202030509', 'X', 'Y', 'Level1 9', 'Level2 9', 'Level3 9', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '9');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000011', 'IT020203',  'IT02020305', 'IT0202030510', 'X', 'Y', 'Level1 10', 'Level2 10', 'Level3 10', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '10');

-- selectCompetencyResultPerItem 
-- �������� �׷� ��ü ��հ����ȸ
delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000001' AND LV2_ID != '' AND LV3_ID = '' AND F_SE != 'X';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000015', '',  'IT02010101', 'IT0201010101', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result1');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000016', '',  'IT02010101', 'IT0201010102', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result2');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000017', '',  'IT02010102', 'IT0201010203', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result3');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000018', '',  'IT02010202', 'IT0201020204', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result4');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000019', '',  'IT02010203', 'IT0201020305', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result5');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000020', '',  'IT02020203', 'IT0202020306', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result6');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000021', '',  'IT02020304', 'IT0202030407', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result7');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000022', '',  'IT02020304', 'IT0202030408', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result8');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000023', '',  'IT02020305', 'IT0202030509', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result9');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000024', '',  'IT02020305', 'IT0202030510', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result10');

-- selectCompetencyResultPerItem2 �������� �����ȸ
-- ����:Result, ���ܱ׷���ü:ResultRv
delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000001' AND LV2_ID != '' AND LV3_ID != '' AND LV4_ID = '' AND LV5_ID = '' AND F_SE != 'X';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000015', 'IT00000115',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result1');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000016', 'IT00000116',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result2');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000017', 'IT00000117',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result3');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000018', 'IT00000118',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result4');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000019', 'IT00000119',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result5');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000020', 'IT00000120',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result6');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000021', 'IT00000121',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result7');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000022', 'IT00000122',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result8');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000023', 'IT00000123',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result9');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000001', 'IT00000024', 'IT00000124',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result10');



delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000000' AND LV2_ID = 'IT00000006' AND LV4_ID = '' AND LV5_ID = '';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020101',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020101',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020101',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020102',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020102',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020202',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020203',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020203',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020203',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT020203',  '', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');

delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000000' AND LV5_ID = '';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0201', 'IT020101',  'IT02010101', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0201', 'IT020101',  'IT02010101', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0201', 'IT020101',  'IT02010102', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0201', 'IT020102',  'IT02010202', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0201', 'IT020102',  'IT02010203', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0202', 'IT020202',  'IT02020203', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0202', 'IT020203',  'IT02020304', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0202', 'IT020203',  'IT02020304', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0202', 'IT020203',  'IT02020305', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT0202', 'IT020203',  'IT02020305', '', 'X', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', '12345');

-- �ٸ����� �׷� ���� ��ü ��հ����ȸ
-- selectMultiDimensionResultoverall , selectMultiDimensionResultPerItem
delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000000' AND LV2_ID = 'IT00000006' AND LV3_ID != '' AND LV4_ID = '' AND F_SE != 'X';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000011',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result1');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000012',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result2');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000013',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result3');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000014',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result4');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000015',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result5');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000016',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result6');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000017',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result7');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000018',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result8');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000019',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result9');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000020',  '', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result10');

-- �ٸ����� �����ȸ
-- selectMultiDimensionResultoverall2, selectMultiDimensionResultPerItem2(???)
select * from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000000' AND LV2_ID = 'IT00000006' AND LV3_ID != '' AND LV4_ID != '' AND LV5_ID = '' AND F_SE != 'X';
delete from AT_ASSESSMENT_RESULT_CALC where LV1_ID = 'IT00000000' AND LV2_ID = 'IT00000006' AND LV3_ID != '' AND LV4_ID != '' AND LV5_ID = '' AND F_SE != 'X';
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000011',  'IT00000111', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result1');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000012',  'IT00000112', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result2');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000013',  'IT00000113', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result3');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000014',  'IT00000114', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result4');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000015',  'IT00000115', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result5');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000016',  'IT00000116', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result6');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000017',  'IT00000117', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result7');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000018',  'IT00000118', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result8');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000019',  'IT00000119', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result9');
insert into AT_ASSESSMENT_RESULT_CALC(ASMT_YEAR, PERNR, LV1_ID, LV2_ID, LV3_ID, LV4_ID, LV5_ID, F_CALC, F_SE, LV1_TEXT_KO, LV2_TEXT_KO, LV3_TEXT_KO, LV4_TEXT_KO, LV5_TEXT_KO, AI_RESULT) value('2021', '1000', 'IT00000000', 'IT00000006', 'IT00000020',  'IT00000120', '', '', 'Y', 'Level1 �ؽ�Ʈ', 'Level2 �ؽ�Ʈ', 'Level3 �ؽ�Ʈ', 'Level4 �ؽ�Ʈ', 'Level5 �ؽ�Ʈ', 'Result10');

=========================

SELECT 
    ASMT_YEAR,
    PERNR,
    AC_SCORE,
    AC_RANK,
    AC_PERCENT,
    MULTI_MEM_SCORE,
    MULTI_MGR_SCORE,
    MULTI_MEM_RANK,
    MULTI_MEM_PERCENT,
    KNOCKOUT,
    (SELECT  text FROM AC_CODE_CUSTOM
        WHERE type = 'AC_GRADE' AND code = AC_RANK) AS AC_RANK_TXT,
    (SELECT text
        FROM AC_CODE_CUSTOM
        WHERE type = 'AC_GRADE' AND code = MULTI_MEM_RANK) AS MULTI_RANK_TXT,
    TO_DECIMAL(MULTI_MEM_SCORE) - TO_DECIMAL(MULTI_MGR_SCORE) AS MULTI_DIFF_SCORE
FROM
    (SELECT 
        ASMT_YEAR,
            PERNR,
            MAX(IF(AI_ID = 'AI00000144', AI_RESULT, '')) AC_SCORE,
            MAX(IF(AI_ID = 'AI00000459', AI_RESULT, '')) AC_RANK,
            MAX(IF(AI_ID = 'AI00000465', AI_RESULT, '')) AC_PERCENT,
            MAX(IF(AI_ID = 'AI00000234', AI_RESULT, '')) MULTI_MEM_SCORE,
            MAX(IF(AI_ID = 'AI00000295', AI_RESULT, '')) MULTI_MGR_SCORE,
            MAX(IF(AI_ID = 'AI00000466', AI_RESULT, '')) MULTI_MEM_RANK,
            MAX(IF(AI_ID = 'AI00000468', AI_RESULT, '')) MULTI_MEM_PERCENT,
            MAX(IF(AI_ID = 'AI00000339', AI_RESULT, '')) KNOCKOUT
    FROM
        AT_ASSESSMENT_RESULT_CALC
    WHERE
        ASMT_YEAR = '20210' AND PERNR = '1000'
    GROUP BY ASMT_YEAR , PERNR)