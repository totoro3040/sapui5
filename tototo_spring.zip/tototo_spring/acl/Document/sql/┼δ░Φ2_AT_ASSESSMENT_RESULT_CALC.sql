       	         /* �ٸ����� �׷� ���� ��ü ��հ����ȸ  */
select emp.ASMT_YEAR, emp.PERNR, 	emp.LV3_ID AS CLASS_ID, 	emp.LV3_TEXT_KO AS CLASS_TX, 	emp.AI_RESULT, 
 (select ROUND(AVG(AI_RESULT AS UNSIGNED),2) as AI_RESULT_COM from AT_ASSESSMENT_RESULT_CALC  
   where pernr in (select pernr from AC_ASSESSEE_EMP where role_level = (select role_level from AC_ASSESSEE_EMP where pernr = emp.pernr)) and ai_id = emp.AI_ID) AI_RESULT_RV 
 from AT_ASSESSMENT_RESULT_CALC emp 
 where emp.LV1_ID = 'IT00000000' 
     AND emp.LV2_ID = 'IT00000006' 
     AND emp.LV3_ID != '' 
     AND emp.LV4_ID = ''
     AND emp.F_SE != 'X' 
     AND emp.ASMT_YEAR = ? 
     AND emp.PERNR = ? 
 order by emp.lv2_id, emp.lv3_id ;
                                 
                    var resultAvg = conn.executeQuery(avgResultSql,vYear,vPernr);               
                                      
        		    /* �ٸ����� �����ȸ  */
select emp.ASMT_YEAR,emp.PERNR, emp.ai_id,emp.LV2_ID, emp.LV2_TEXT_KO, emp.LV3_ID AS CLASS_ID, emp.LV3_TEXT_KO AS CLASS_TX,  emp.LV4_ID AS ITEM_ID, emp.LV4_TEXT_KO as ITEM_TX,	emp.AI_RESULT, 
 (select ROUND(AVG(CAST(AI_RESULT AS UNSIGNED)),2) as AI_RESULT_COM from AT_ASSESSMENT_RESULT_CALC  
   where pernr in (select pernr from AC_ASSESSEE_EMP where role_level = (select role_level from AC_ASSESSEE_EMP where pernr = emp.pernr)) and ai_id = emp.AI_ID) AI_RESULT_RV 
 from AT_ASSESSMENT_RESULT_CALC emp 
 where emp.LV1_ID = 'IT00000000' 
     AND emp.LV2_ID = 'IT00000006' 
     AND emp.LV3_ID != '' 
     AND emp.LV4_ID != ''
     AND emp.LV5_ID = ''
     AND emp.F_SE != 'X' 
     AND emp.ASMT_YEAR = ? 
     AND emp.PERNR = ? 
 order by emp.lv3_id, emp.lv4_id ;
