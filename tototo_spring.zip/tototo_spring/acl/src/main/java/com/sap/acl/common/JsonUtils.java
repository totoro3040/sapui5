package com.sap.acl.common;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class JsonUtils {

	/**
	 * Map 데이터를 Json Text 형태로 변환한다.
	 * @param source {@link Map}
	 * @return Json 변환 Text
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonGenerationException 
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public static String convertMapToJsonText(Map source) throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		String dest = objectMapper.writeValueAsString(source);
		return dest;
	}
	
	/**
	 * List 데이터를 JsonText 형태로 변환한다.
	 * @param source {@link List}
	 * @return Json 변환 Text
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonGenerationException 
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public static String convertListToJsonText(List source) throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		String dest = objectMapper.writeValueAsString(source);
		return dest;
	}
	
	/**
	 * Json 형태의 문자열을 Map형태로 변환한다.
	 * @param jsonText Json형식의 문자열
	 * @return Json문자열을 변환한 Map 객체
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> convertJsonTextToMap(String jsonText) throws JsonParseException, JsonMappingException, IOException {
		String replaceStr = jsonText.replaceAll("&quot;", "\"");
		return convertJsonTextToGenericType(replaceStr, Map.class);
	}
	
	/**
	 * 
	 * @param jsonText
	 * @return
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static List<Map<String, Object>> convertJsonTextToList(String jsonText) throws JsonParseException, JsonMappingException, IOException {
		String replaceStr = jsonText.replaceAll("&quot;", "\"");
		return convertJsonTextToGenericType(replaceStr, List.class);
	}
	
	/**
	 * <pre>
	 * Json형태의 문자열을 GenericType의 형태로 변환한다.
	 * 지원하는 Generic 타입은 Map, List이다.
	 * </pre>
	 * @param jsonText
	 * @param clazz
	 * @return
	 * @throws IOException 
	 * @throws JsonMappingException
	 * @throws JsonParseException 
	 * @throws Exception
	 */
	public static <T>  T convertJsonTextToGenericType(String jsonText, Class<T> clazz) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		return (T)objectMapper.readValue(jsonText, clazz);
	}
		
	/************************메인***********************/
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("test", "!@#$%^&<>>>>");
		
		String jsonText = JsonUtils.convertMapToJsonText(map);
		
		String testStr = "{&quot;inSub01&quot;:[{&quot;dpstBnkNm&quot;:&quot;케이뱅크&quot;,&quot;dpstBnkAcctNbr&quot;:&quot;100186841001&quot;,&quot;acctTrnsfrAmt&quot;:12,&quot;dpstBnkCd&quot;:&quot;089&quot;},{&quot;dpstBnkNm&quot;:&quot;케이뱅크&quot;,&quot;dpstBnkAcctNbr&quot;:&quot;100186841001&quot;,&quot;acctTrnsfrAmt&quot;:12,&quot;dpstBnkCd&quot;:&quot;089&quot;}]}";
		map = JsonUtils.convertJsonTextToMap(testStr);
		Map<String, Object> testmap = new HashMap<String, Object>();
		testmap.put("stringO", "test1");
		testmap.put("IntegerO", 11);
		testmap.put("ListO", map.get("inSub01"));
	}
}
