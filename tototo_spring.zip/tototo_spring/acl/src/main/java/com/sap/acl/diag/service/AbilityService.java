package com.sap.acl.diag.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sap.acl.diag.dao.AbilityDao;

/**
 * @Class Name : ConferServiceImpl.java
 * @Description : Member Business Implement Class
 * @Modification Information 
 * 수정일 
 * 수정자 
 * 수정내용 
 * 2019.09.15 최초생성
 *
 * @author totoro
 * @since 2019.09.15
 * @version 1.0
 * @see
 *
 * 	Copyright (C) by ithink All right reserved.
 */

//@Service("billService")
@Service
public class AbilityService {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AbilityDao abilityDao;

	/**
	 * 목록 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	@Transactional(readOnly = true)
	public List<Map<String, Object>> selectAttemplatefieldList(Map<String,Object> params) throws Exception {
		return abilityDao.selectAttemplatefieldList(params); //목록을 가져온다.
	}

	/**
	 * 목록 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	@Transactional(readOnly = true)
	public List<Map<String, Object>> selectAsmtMasterList(Map<String,Object> params) throws Exception {
		return abilityDao.selectAsmtMasterList(params); //목록을 가져온다.
	}

	/**
	 * 목록 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	@Transactional(readOnly = true)
	public List<Map<String, Object>> selectItemList(Map<String,Object> params) throws Exception {
		return abilityDao.selectItemList(params); //목록을 가져온다.
	}

}
