package com.sap.acl.diag.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sap.acl.diag.dao.AsmtResultDao;

//import com.sap.acl.diag.dao.AbilityDao;

/**
 * @Class Name : ConferServiceImpl.java
 * @Description : Member Business Implement Class
 * @Modification Information 
 * 수정일 
 * 수정자 
 * 수정내용 
 * 2019.09.15 최초생성
 *
 * @author totoro
 * @since 2019.09.15
 * @version 1.0
 * @see
 *
 * 	Copyright (C) by ithink All right reserved.
 */

//@Service("billService")
@Service
public class AsmtResultService {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AsmtResultDao asmtResultDao;

	/**
	 * 종합 결과 조회
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getOverallComment(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		List<Map<String, Object>> returnList = new ArrayList<Map<String, Object>>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectOverallComment(params);

 	    if (resultList != null && resultList.size() > 0){
 	    	Map<String, Object> result = resultList.get(0);
	          
 	        String ac_rating_txt = "";
 	        if(MapUtils.getString(result, "AC_RANK", "").equals("MSF") || MapUtils.getString(result, "AC_RANK", "").equals("HC")){
 	            ac_rating_txt = "매우 우수";
 	        }else if(MapUtils.getString(result, "AC_RANK", "").equals("C")){
 	            ac_rating_txt = "우수";
 	        } else { // DN , UDN
 	            ac_rating_txt = "개발 필요";
 	        }
 	        
 	        String ac_comment="진단결과 " + MapUtils.getString(result, "AC_SCORE", "") +" 점으로 "+ac_rating_txt+ " 수준 ("+ MapUtils.getString(result, "AC_RANK_TXT", "")+", 전체 중 상위 "+MapUtils.getString(result, "AC_PERCENT", "")+ "%) 을 보임";
 	        
 	        String multi_rating_txt = ""; 
 	        if(MapUtils.getString(result, "MULTI_MEM_RANK", "").equals("MSF") || MapUtils.getString(result, "MULTI_MEM_RANK", "").equals("HC")){
 	            multi_rating_txt = "우수";
 	        }else if(MapUtils.getString(result, "MULTI_MEM_RANK", "").equals("C")){
 	            multi_rating_txt = "보통";
 	        } else { // DN , UDN
 	            multi_rating_txt = "개발 필요";
 	        }
 	        
 	        String multi_comment="부하 평가 결과 "+MapUtils.getString(result, "MULTI_MEM_SCORE", "") +" 점으로 "+ multi_rating_txt+" ("+MapUtils.getString(result, "MULTI_RANK_TXT", "") +", 전체 중 상위 "+MapUtils.getString(result, "MULTI_MEM_PERCENT", "")+ "%) 을 보임";
 	        
 	        String multi_sub_comment = ""; 
 	        if(MapUtils.getFloat(result, "MULTI_DIFF_SCORE") <= -0.9){
 	            multi_sub_comment = "- 부하들이 상사보다 매우 낮게 평가하고 있음";
 	        }else if(MapUtils.getFloat(result, "MULTI_DIFF_SCORE") <= -0.6 && MapUtils.getFloat(result, "MULTI_DIFF_SCORE") > -0.9){
 	            multi_sub_comment = "- 부하들이 상사보다 다소 낮게 평가하고 있음";
 	        } else if(MapUtils.getFloat(result, "MULTI_DIFF_SCORE") >= 0.6 && MapUtils.getFloat(result, "MULTI_DIFF_SCORE") < 0.9){
 	            multi_sub_comment = "- 부하들이 상사보다 다소 높게 평가하고 있음";
 	        } else if(MapUtils.getFloat(result, "MULTI_DIFF_SCORE") >= 0.9 ){
 	            multi_sub_comment = "- 부하들이 상사보다 매우 높게 평가하고 있음";
 	        } else { // DN , UDN
 	            multi_sub_comment = "";
 	        }
 	        
 	        
 			Map<String, Object> resultData = new HashMap<String, Object>();
 			resultData.put("AcCmnt", ac_comment);
 			resultData.put("MultiCmnt", multi_comment);
 			resultData.put("MultiSubCmnt", multi_sub_comment);
 			resultData.put("KnockOut", MapUtils.getString(result, "KNOCKOUT", ""));
 			
 			returnList.add(resultData);
 	             
	    }
	   
 	    returnData.put("data", returnList);
		
		return returnData;
	}

	/**
	 * 진단결과 요약 : 역량진단 커맨트
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getCompetencyResultComment(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectCompetencyResultComment(params);

 	    returnData.put("data", resultList);
		
		return returnData;
	}

	/**
	 * 역량진단 대항목 결과조회
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getCompetencyResultChartDetail(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectCompetencyResultChartDetail(params);
		List<Map<String, Object>> resultList2 = asmtResultDao.selectCompetencyResultChartDetail2(params);
		List<Map<String, Object>> resultList3 = asmtResultDao.selectCompetencyResultChartDetail3(params);
		
		List<Map<String, Object>> resultListSub = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> resultList2Sub = new ArrayList<Map<String, Object>>();
		//List<Map<String, Object>> resultList3Sub = new ArrayList<Map<String, Object>>();

		List<Map<String, Object>> returnList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> returnList2 = new ArrayList<Map<String, Object>>();

		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, Object> data2 = new HashMap<String, Object>();
		Map<String, Object> data3 = new HashMap<String, Object>();

		if (resultList != null && resultList.size() > 0){
 	    	for( int i = 0; i < resultList.size(); i++ ) {
 	    		data = resultList.get(i);
 	    		resultListSub = new ArrayList<Map<String, Object>>();
 	    		
 	    		if (resultList2 != null && resultList2.size() > 0){
 	    			for( int j = 0; j < resultList2.size(); j++ ) {
 	    	    		data2 = resultList2.get(j);
 	    	    		resultList2Sub = new ArrayList<Map<String, Object>>();

 	    	    		if (resultList3 != null && resultList3.size() > 0){
 	    	    			for( int k = 0; k < resultList3.size(); k++ ) {
 	    	    	    		data3 = resultList3.get(k);
 	    	    	    		//resultList3Sub = new ArrayList<Map<String, Object>>();
 	    	    	    		
 	    	    				if ( MapUtils.getString(data2, "Class", "").equals(MapUtils.getString(data3, "Class", "")) && MapUtils.getString(data2, "Item", "").equals(MapUtils.getString(data3, "Item", "")) ) {
 	    	    					resultList2Sub.add(data3);
 	    	    				}
 	    	    	    		
 	    	    			}
 	    	    		}
 	    	    		data2.put("ItemList", resultList2Sub);
 	    	    		//returnList2.add(data2);
 	    	    		
 	    	    		
 	    				if ( MapUtils.getString(data, "Class", "").equals(MapUtils.getString(data2, "Class", "")) ) {
 	    					resultListSub.add(data2);
 	    				}
 	    	    		
 	    			}
 	    		}
 	    		data.put("ItemList", resultListSub);
 	    		returnList.add(data);
 	    		
 	    		
 	    	}
 	    }
		
		//logger.debug("returnList : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(returnList));

 	    returnData.put("data", resultList);
		
		return returnData;
	}

	/**
	 * 역량진단 결과조회
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getCompetencyResultPerItem(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectCompetencyResultPerItem2(params);
		List<Map<String, Object>> resultList2 = asmtResultDao.selectCompetencyResultPerItem(params);
		
		List<Map<String, Object>> resultListSub = new ArrayList<Map<String, Object>>();

		List<Map<String, Object>> returnList = new ArrayList<Map<String, Object>>();

		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, Object> data2 = new HashMap<String, Object>();
		
		String resultAvgClassTX = "";

		if (resultList != null && resultList.size() > 0){
 	    	for( int i = 0; i < resultList.size(); i++ ) {
 	    		data = resultList.get(i);
 	    		
 	    		if (resultList2 != null && resultList2.size() > 0){
 	    			for( int j = 0; j < resultList2.size(); j++ ) {
 	    	    		data2 = resultList2.get(j);
 	    	    		resultAvgClassTX = "";

 	    				if ( MapUtils.getString(data, "ClassID", "").equals(MapUtils.getString(data2, "ClassID", "")) ) {
 	    					resultAvgClassTX = MapUtils.getString(data2, "CLASS_TX", "") + " " + MapUtils.getString(data2, "AI_RESULT", "") + " (그룹전체 " + MapUtils.getString(data2, "AI_RESULT_RV", "") + ")";
 	    					data.put("ClassTx", resultAvgClassTX);
 	    				}
 	    	    		
 	    			}
 	    		}
 	    		returnList.add(data);
 	    	}
 	    }
		
		//logger.debug("returnList : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(returnList));

 	    returnData.put("data", resultList);
		
		return returnData;
	}

	/**
	 * 역량진단 결과조회
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getMultiDimensionResultPerItem(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectMultiDimensionResultPerItem2(params);
		List<Map<String, Object>> resultList2 = asmtResultDao.selectMultiDimensionResultPerItem(params);
		
		List<Map<String, Object>> resultListSub = new ArrayList<Map<String, Object>>();

		List<Map<String, Object>> returnList = new ArrayList<Map<String, Object>>();

		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, Object> data2 = new HashMap<String, Object>();
		
		String resultAvgClassTX = "";

		if (resultList != null && resultList.size() > 0){
 	    	for( int i = 0; i < resultList.size(); i++ ) {
 	    		data = resultList.get(i);
 	    		
 	    		if (resultList2 != null && resultList2.size() > 0){
 	    			for( int j = 0; j < resultList2.size(); j++ ) {
 	    	    		data2 = resultList2.get(j);
 	    	    		resultAvgClassTX = "";

 	    				if ( MapUtils.getString(data, "CLASS_ID", "").equals(MapUtils.getString(data2, "CLASS_ID", "")) ) {
 	    					resultAvgClassTX = MapUtils.getString(data2, "CLASS_TX", "") + " " + MapUtils.getString(data2, "AI_RESULT", "") + " (그룹전체 " + MapUtils.getString(data2, "AI_RESULT_RV", "") + ")";
 	    					data.put("ClassTx", resultAvgClassTX);
 	    				}
 	    	    		
 	    			}
 	    		}
 	    		returnList.add(data);
 	    	}
 	    }
		
		logger.debug("returnList : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(returnList));

 	    returnData.put("data", resultList);
		
		return returnData;
	}	
	
	/**
	 * 다면진단 결과조회
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getMultiDimensionResultoverall(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectMultiDimensionResultoverall2(params);
		List<Map<String, Object>> resultList2 = asmtResultDao.selectMultiDimensionResultoverall(params);
		
		List<Map<String, Object>> returnList = new ArrayList<Map<String, Object>>();

		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, Object> data2 = new HashMap<String, Object>();
		
		String resultAvgClassTX = "";

		if (resultList != null && resultList.size() > 0){
 	    	for( int i = 0; i < resultList.size(); i++ ) {
 	    		data = resultList.get(i);
 	    		
 	    		if (resultList2 != null && resultList2.size() > 0){
 	    			for( int j = 0; j < resultList2.size(); j++ ) {
 	    	    		data2 = resultList2.get(j);
 	    	    		resultAvgClassTX = "";

 	    				if ( MapUtils.getString(data, "CLASS_ID", "").equals(MapUtils.getString(data2, "CLASS_ID", "")) ) {
 	    					resultAvgClassTX = MapUtils.getString(data2, "CLASS_TX", "") + " " + MapUtils.getString(data2, "AI_RESULT", "") + " (그룹전체 " + MapUtils.getString(data2, "AI_RESULT_RV", "") + ")";
 	    					data.put("ClassTx", resultAvgClassTX);
 	    				}
 	    	    		
 	    			}
 	    		}
 	    		returnList.add(data);
 	    	}
 	    }
		
		logger.debug("returnList : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(returnList));

 	    returnData.put("data", resultList);
		
		return returnData;
	}	
	
	/**
	 * 진단결과 요약 : 역량진단 커맨트
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getMultiDimensionResultPerItemSort(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectMultiDimensionResultPerItemSort(params);

 	    returnData.put("data", resultList);
		
		return returnData;
	}	
	
	/**
	 * 다면진단 종합 결과 조회
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	public Map<String, Object> getMultiResultComment(Map<String,Object> params) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		
		List<Map<String, Object>> resultList = asmtResultDao.selectMultiResultComment(params);

 	    returnData.put("data", resultList);
		
		return returnData;
	}		
}
