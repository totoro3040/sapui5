package com.sap.acl.diag.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.acl.common.PageMaker;
import com.sap.acl.diag.service.AbilityService;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
//@RequestMapping("/sample")
public class AbilityController {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AbilityService abilityService;	

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/doosan_hanaxs_odata/assessment-center/src/xsjs/TemplateTableService.xsjs")
//	@RequestMapping(value = "/doosan_hanaxs_odata/assessment-center/src/xsjs/ReportService.xsjs", method = {RequestMethod.POST})
	public @ResponseBody Map<String, Object> templateTableService(@RequestParam Map<String,Object> params) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		List<Map<String, Object>> contList = abilityService.selectAttemplatefieldList(params); //목록을 가져온다.

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("data", contList);
		
		return map;
	}

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtMstService.xsjs")
	public @ResponseBody List<Map<String, Object>> getAsmtMstService(@RequestParam Map<String,Object> params) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		List<Map<String, Object>> contList = abilityService.selectAsmtMasterList(params); //목록을 가져온다.
		
		return contList;
	}

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtItemService.xsjs", method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody List<Map<String, Object>> getAsmtItemService(@RequestParam Map<String,Object> params) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		List<Map<String, Object>> contList = abilityService.selectItemList(params); //목록을 가져온다.
		
		return contList;
	}



}
