package com.sap.acl.member.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sap.acl.member.dao.MemberDao;

/**
 * @Class Name : ConferServiceImpl.java
 * @Description : Member Business Implement Class
 * @Modification Information 
 * 수정일 
 * 수정자 
 * 수정내용 
 * 2019.09.15 최초생성
 *
 * @author totoro
 * @since 2019.09.15
 * @version 1.0
 * @see
 *
 * 	Copyright (C) by ithink All right reserved.
 */

//@Service("billService")
@Service
public class MemberService {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private MemberDao memberDao;

	/**
	 * count 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	//@Override
	@Transactional(readOnly = true)
	public int selectMemberCount(Map<String,Object> params) throws Exception {
		return memberDao.selectMemberCount(params); //목록 갯수를 가져온다.;		
	}
	
	/**
	 * 목록 가져오기
	 * 
	 * @return 목록
	 * @exception Exception
	 */
	@Transactional(readOnly = true)
	public List<Map<String, Object>> selectMemberList(Map<String,Object> params) throws Exception {
		params.put("pageStart", (MapUtils.getInteger(params, "pageIndex", 1) - 1) * MapUtils.getInteger(params, "perPageNum", 10));
		params.put("perPageNum", MapUtils.getInteger(params, "perPageNum", 10));
		
		return memberDao.selectMemberList(params); //목록을 가져온다.
	}

	/**
	 * 행정사무감사 상세 가져오기
	 * 
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 단건
	 * @exception Exception
	 */
	@Transactional(readOnly = true)
	public Map<String, Object> selectMemberDetail(Map<String,Object> params) throws Exception {
		return memberDao.selectMemberDetail(params);
	}

	/**
	 * 행정사무감사 등록
	 * 
	 * @param searchVO - 저장할 정보가 담긴 VO
	 * @exception Exception
	 */
	@Transactional
	public void insertMember(Map<String,Object> params) throws Exception {
		memberDao.insertMember(params);
	}

	/**
	 * 행정사무감사 수정
	 * 
	 * @param searchVO - 저장할 정보가 담긴 VO
	 * @exception Exception
	 */
	@Transactional
	public void updateMember(Map<String,Object> params) throws Exception {
		memberDao.updateMember(params);
	}

	/**
	 * 행정사무감사 삭제
	 * 
	 * @param searchVO - 저장할 정보가 담긴 VO
	 * @exception Exception
	 */
	@Transactional
	public void deleteMember(Map<String,Object> params) throws Exception {
		memberDao.deleteMember(params);
	}
}
