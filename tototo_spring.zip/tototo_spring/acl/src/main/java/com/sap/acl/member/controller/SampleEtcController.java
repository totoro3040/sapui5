package com.sap.acl.member.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.acl.common.PageMaker;
import com.sap.acl.member.model.UserData;
import com.sap.acl.member.service.BillService;
import com.sap.acl.member.vo.SeriesVO;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
@RequestMapping("/page")
public class SampleEtcController {
	private Logger logger = LoggerFactory.getLogger(SampleEtcController.class);

	@Autowired
	private BillService billService;	

	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/grpc_001")
	public String getNullData(UserData userData, ModelMap model) throws Exception {

		logger.info("===== data =====");
		
		model.put("view_type", "test");
		
		return "pc/cal/grpc_001";
	}

	/**
	 * 고객정보 목록조회 
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/data/{parentId}", method = {RequestMethod.GET, RequestMethod.POST})
	public String getPathVariableData(@PathVariable String parentId, UserData userData, ModelMap model) throws Exception {

		logger.info("===== /data/{parentId} ===== " + parentId);
		logger.info("===== /data/{parentId} ===== " + userData.toString());
		logger.info("rename project: {}", userData.getUserId());
		
		model.put("view_type", "test");
		
		return "sample/step" + parentId;
	}

	/**
	 * 고객정보 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajax", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public ModelMap getAjax(UserData userData, ModelMap model) throws Exception {

		logger.info("===== /ajax =====");
		
		model.put("view_type", "test");
		
		return model;
	}

	/**
	 * 페이징
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/paging")
	public String paging(@RequestParam Map<String,Object> params, ModelMap model) throws Exception {
		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		int totCnt = billService.selectMemberCount(params); //목록 갯수를 가져온다.
		List<Map<String, Object>> contList = billService.selectMemberList(params); //목록을 가져온다.
		
		PageMaker pageMaker = new PageMaker(
				MapUtils.getInteger(params, "pageIndex", 1),
				MapUtils.getInteger(params, "perPageNum", 10),
				totCnt);
		
		model.addAttribute("contList", contList);
		model.addAttribute("pageMaker", pageMaker);
		
		//model.put("view_type", "test");
		
		return "sample/paging";
	}
	
	/**
	 * 목록조회1
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/test01")
	public String dbData(UserData userData, ModelMap model) throws Exception {

		logger.info("===== test01 =====");
		
		List<SeriesVO> seriesList = billService.selectBillSerieslist(); //데이터를 가져온다.

		logger.debug("captcha : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(seriesList));

		model.addAttribute("contList", seriesList);
		
		//model.put("view_type", "test");
		
		return "sample/test01";
	}

	/**
	 * 목록조회2
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/test02")
	public String dbData2(UserData userData, ModelMap model) throws Exception {

		logger.info("===== test02 =====");
		
		List<Map<String, Object>> seriesList = billService.selectBillSerieslist2(); //데이터를 가져온다.

		logger.debug("captcha : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(seriesList));
		
		model.addAttribute("contList", seriesList);
		
		//model.put("view_type", "test");
		
		return "sample/test01";
	}

	/**
	 * 트랜잭션 테스트
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/saveTran1")
	public String saveTran1(UserData userData, ModelMap model) throws Exception {
		logger.info("===== tran1 =====");
		
		Map<String, Object> aa = new HashMap<String, Object>();
		aa.put("mb_id", "cc");
		aa.put("mb_pw", "ccc");
		aa.put("address", "충청도");
		
		billService.saveTran1(aa);
		return "sample/test01";
	}
	
	/**
	 * 트랜잭션 테스트
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/saveTran2")
	public String saveTran2(UserData userData, ModelMap model) throws Exception {
		logger.info("===== tran2 =====");
		
		billService.saveTran3();
		return "sample/test01";
	}
}
