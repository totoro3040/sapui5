package com.sap.acl.diag.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.acl.common.JsonUtils;
import com.sap.acl.diag.service.AsmtResultService;

/**
 * 부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author 윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see
 * 
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 *      </pre>
 */
@Controller
//@RequestMapping("/sample")
public class AsmtResultController {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AsmtResultService asmtResultService;

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs", method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody Map<String, Object> getAsmtItemService(@RequestParam("jsonParam") String jsonParam)
			throws Exception {

		logger.debug("params1 : {}", jsonParam);

		Map<String, Object> params = JsonUtils.convertJsonTextToMap(jsonParam);
		logger.debug("params2 : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		logger.debug("params3 : {}", MapUtils.getString(params, "type", ""));

		Map<String, Object> responseBody = new HashMap<String, Object>();

		switch (MapUtils.getString(params, "type", "")) {
//        case "updateFinalResult":
//            responseBody = updateFinalResult(request.$params);    
//            break;
//       case "getOverallResult":
//            responseBody = getOverallResult(request.$params);    
//            break;     
		case "getCompetencyResultComment":
			// 진단결과 요약 : 역량진단 커맨트
			responseBody = asmtResultService.getCompetencyResultComment(params);
			break;
       case "getMultiResultComment":     
            responseBody = asmtResultService.getMultiResultComment(params);    
            break;   
//       case "getConfigurationResultComment":
//            responseBody = getConfigurationResultComment(request.$params);    
//            break;
		case "getOverallComment":
			responseBody = asmtResultService.getOverallComment(params);
			break;
       case "getCompetencyResultPerItem":
            responseBody = asmtResultService.getCompetencyResultPerItem(params);    
            break;
       case "getCompetencyResultChartDetail":
    	   //역량진단 결과조회
            responseBody = asmtResultService.getCompetencyResultChartDetail(params);    
            break;     
//       case "getConfigurationResultPerItem":
//            responseBody = getConfigurationResultPerItem(request.$params);    
//            break;
       case "getMultiDimensionResultPerItem":
            responseBody = asmtResultService.getMultiDimensionResultPerItem(params);    
            break;
       case "getMultiDimensionResultoverall":
            responseBody = asmtResultService.getMultiDimensionResultoverall(params);    
            break; 
       case "getMultiDimensionResultPerItemSort":
            responseBody = asmtResultService.getMultiDimensionResultPerItemSort(params);    
            break;
//       case "getDerailerResultPerItem":
//            responseBody = getDerailerResultPerItem(request.$params);
//            break;
		default:
			// responseBody = upsertResult(request.$params);
			break;
		}

		return responseBody;
	}

}
