package com.sap.acl.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

	//@GetMapping("/")
	@RequestMapping({"/", ""})
	public String index() {
		System.out.println("root");
		return "index";
	}

	@RequestMapping("/index.do")
	public String openBoardWrite() throws Exception{
		System.out.println("index");
		return "index";
	}
	
	@GetMapping("/index2.do")
	public String index2() {
		System.out.println("root");
		return "index";
	}

	@RequestMapping("/index3.do")
	public String index23() throws Exception{
		System.out.println("index");
		return "index";
	}
	
}
