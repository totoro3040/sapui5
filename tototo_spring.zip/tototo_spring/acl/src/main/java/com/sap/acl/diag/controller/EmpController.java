package com.sap.acl.diag.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.acl.common.JsonUtils;
import com.sap.acl.common.PageMaker;
import com.sap.acl.diag.service.AbilityService;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
//@RequestMapping("/sample")
public class EmpController {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AbilityService abilityService;	

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/doosan_hanaxs_odata/assessment-center/src/xsjs/EmpService.xsjs", method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody List<Map<String, Object>> getAsmtItemService(@RequestParam("jsonParam") String jsonParam) throws Exception {

		logger.debug("params1 : {}", jsonParam);
		
		Map<String,Object> params = JsonUtils.convertJsonTextToMap(jsonParam);
		logger.debug("params2 : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		logger.debug("params3 : {}", MapUtils.getString(params, "type", ""));
		
		List<Map<String, Object>> contList = new ArrayList<Map<String, Object>>();

		if (MapUtils.getString(params, "type", "").equals("getEmpBasicInfo")) {
			
		} else {
			
		}		

		//사용자 권한에 해당하는 진단대상자를 조회한다. 
		Map<String, Object> tempData = new HashMap<String, Object>();
		tempData.put("PersaTextKo", "윤혁신1");
		tempData.put("Ename", "윤혁신2");
		tempData.put("CallingTitleTextKo", "윤혁신3");
		tempData.put("BgTextKo", "윤혁신4");
		tempData.put("Pernr", "1000");
		tempData.put("PersonId", "1000");
		tempData.put("AsmtYear", "2021");
		tempData.put("Age", "35");
		tempData.put("BirthDate", "20000101");
		tempData.put("YearsOfService", "10");
		tempData.put("OrgName", "무소속");
		
		contList.add(tempData);
		
		return contList;
	}



}
