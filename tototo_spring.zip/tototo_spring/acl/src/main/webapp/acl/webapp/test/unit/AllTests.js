sap.ui.define([
	"com/doosan/acl/test/unit/controller/AppMain.controller"
], function () {
	"use strict";
});