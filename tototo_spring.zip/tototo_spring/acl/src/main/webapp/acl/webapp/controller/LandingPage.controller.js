/*eslint-disable no-console, no-alert, sap-no-ui5base-prop, no-eval */ 
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Popover",
	"sap/m/Button",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Formatter"
], function (jQuery, Fragment, Controller, JSONModel, Popover, Button, Common,Formatter) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.LandingPage", {
		model : new sap.ui.model.json.JSONModel(),
		
		onInit: function () {
			
			/* Routing 정보 조회 */
			this.router = this.getOwnerComponent().getRouter();
			
			/* Menu 정보 조회 */  
			var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var data = {
				navigation: [
					/*
					{
					id: '__homeMenu',
					title: oBundle.getText("menuHome"),
					icon: 'sap-icon://home',
					expanded: false,
					key: 'AsmtCenter'
					},
					*/
					{
					id: '__basisManagement',
					title: oBundle.getText("menuBasis"),
					icon: 'sap-icon://key-user-settings',
					key: 'BasisMgmt',
					enabled: true,
					expanded: true,
					items: [
							{
							id: '__relationshipMatrix',
							title: oBundle.getText("menuRelationshipMatrix"),
							key: 'RelationshipMatrix',
							enabled: true
							}
						]
					},
					{
					id: '__basisManagement',
					title: oBundle.getText("menuItem"),
					icon: 'sap-icon://activity-items',
					key: 'ItemMgmt'
					},
					{
					id: '__uploadResult',
					title: oBundle.getText("menuUpload"),
					icon: 'sap-icon://upload-to-cloud',
					key: 'UploadingResult'
					},
					{
					id: '__resultList',
					title: oBundle.getText("menuResult"),
					icon: 'sap-icon://activity-individual',
					key: 'ResultList',
					enabled: true,
					expanded: true,
					items: [
							{
							id: '__resultListCompetency',
							title: oBundle.getText("menuResultCompetency"),
							key: 'ResultCompetency',
							enabled: true
							},
							{
							id: '__resultListMultiDimension',
							title: oBundle.getText("menuResultMultiDimension"),
							key: 'ResultMultiDimension',
							enabled: true
							},
							{
							id: '__resultListMultiDimCmnt',
							title: oBundle.getText("menuResultMultiDimCmnt"),
							key: 'ResultMultiDimCmnt',
							enabled: true
							}
						]
					},
					{
					id: '__reportCenter',
					title: oBundle.getText("menuReport"),
					icon: 'sap-icon://manager-insight',
					key: 'ReportCenter',
					enabled: true,
					expanded: true,
					items: [
							{
							id: '__resultListCompany',
							title: oBundle.getText("menuReportCompany"),
							key: 'ResultCompany',
							enabled: true
							},
							/*
							{
							id: '__resultListIndividual',
							title: oBundle.getText("menuReportIndividual"),
							key: 'ResultIndividual',
							enabled: true
							},
							*/
							{
							id: '__resultListIndividualNew',
							title: oBundle.getText("menuReportIndividualNew"),
							key: 'ResultIndividualNew',
							enabled: true
							},
							{
							id: '__resultListIndividualNew2',
							title: oBundle.getText("menuReportIndividualNew2"),
							key: 'ResultIndividualNew2',
							enabled: true
							}
							/*,
							{
							id: '__reportExport',
							title: oBundle.getText("menuReportExport"),
							key: 'ReportExport',
							enabled: true
							}
							*/
						]
					}
				],
				fixedNavigation: [
					//{
					//id: '__myReportMenu',
					//title: 'My Report',
					//key: 'ReportList',
					//icon: 'sap-icon://list'
					//}
				],
				headerItems: [
				{
					text: "View"
				}, {
					text: "Setting"
				}]
			};
		
			this.model.setData(data);
			this.getView().setModel(this.model);

			this._setToggleButtonTooltip(!sap.ui.Device.system.desktop);
			/* End Menu */
			
			/* Toolbar 세팅 */
			this.onInitLangButton();
			
			/* Session timeout 세팅 */
			this.initSessionTimer();
		},
		
		onGoHome: function(oEvent) {
			this.router.navTo("AsmtCenter");
		},
		
		onItemSelect : function(oEvent) {
			var item = oEvent.getParameter("item");
			this.router.navTo(item.getKey());
		},
		
		onSideNavButtonPress : function() {
			var viewId = this.getView().getId();
			var toolPage = sap.ui.getCore().byId(viewId + "--toolPage");
			var sideExpanded = toolPage.getSideExpanded();

			this._setToggleButtonTooltip(sideExpanded);
 
			toolPage.setSideExpanded(!toolPage.getSideExpanded());
		},
		
		onInitLangButton : function(){
			
			var vLang = Common.getLangXs();
			var oLangImage = this.getView().byId("changeLanguImage");
			var oLangLabel = this.getView().byId("changeLanguLabel");
			var oLanguLabel = this.getView().byId("languLabel");

			if (vLang === "3") {
				oLangImage.setSrc("./img/cc_flag/kr.svg");
				oLangLabel.setText("한국어 (KO)");
				oLanguLabel.setText("ko");
			} else {
				oLangImage.setSrc("./img/cc_flag/us.svg");
				oLangLabel.setText("English (US)");
				oLanguLabel.setText("en");
			}
		},
		
		onOpenLangPopover : function(oEvent){
			// 언어 리스트를 Model로 넣어준다.
			var langList = [
					{
						id: "ko",
						langu: "3",
						title: "한국어(KO)",
						icon:"./img/cc_flag/kr.svg"
					},
					{
						id: "en",
						langu: "E",
						title: "English (US)",
						icon:"./img/cc_flag/us.svg"
					}
				];
			
			var langModel = new sap.ui.model.json.JSONModel(langList);
			
			/*
			if (!this._oLangPopover) {
				this._oLangPopover = sap.ui.xmlfragment("com.doosan.acl.fragment.Popover.LanguList", this);
				this._oLangPopover.setModel(langModel);	
				this.getView().addDependent(this._oLangPopover);
			}

			this._oLangPopover.openBy(oEvent.getSource());	
			*/
		},
		
		onCloseLangPopover  : function(oEvent){
			
			if (this._oLangPopover) {
				this._oLangPopover.close();
			}
		},
		
		onChangeLangu : function(oEvent){
			/*
			* 각 언어 클릭 시 : Gloabl 변수 및 UI5 변수 업데이트
			*/
			var oContext = oEvent.getSource().getBindingContext();
			var vId = oContext.getProperty("id");
			var vLangu = oContext.getProperty("langu");
			
			
			Common.setLang(vId,vLangu);
			
			// Button refresh
			this.onInitLangButton();
			var vLangXs = Common.getLangXs();
				
			// 사용자 언어 변경
			var sSessionServicelUrl = "/doosan_hanaxs_odata/data-mart/src/xsjs/UserSessionInfo.xsjs";
			try{
				$.ajax({
					url: sSessionServicelUrl,
					type: "POST",
					data: {
						jsonParam: JSON.stringify({
							"type": "updateUserLanguage",
							"userLang": vLangXs
						})
					},
					success: function (results) {

					},
					error: function (e) {

					},
					complete: function(){

					}
				});	
			}catch (ex) {
				console.log(ex);
			}	
			this._oLangPopover.close();
		},
		
		initSessionTimer : function(){
			var sessionLimit = 15;
			var ltime = new Date();
  		    var loginTime = ltime.setMinutes(ltime.getMinutes() + sessionLimit);
  			//var login = loginTime;
  			this.login = loginTime;
  			var sessionTimerItem = this.getView().byId("sessionTimerItem");
  			var oController = this;
	  		this.x = setInterval(function() {
					var now = new Date().getTime();
					var timeLeft = oController.login - now;
					var minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
					var seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
					var timeLeftText = Formatter.leadingZeroPadding(minutes,2) + ":" + Formatter.leadingZeroPadding(seconds,2);
					if (timeLeft <= 0) {
						clearInterval(oController.x);
						Common.errorHandling({status:503}, oController);
					} else {
						sessionTimerItem.setText("00:" + timeLeftText);
					}
			}, 1000);
			
			jQuery( document ).ajaxComplete(function() {
			   var curTime = new Date();
  		       var newLoginTime = curTime.setMinutes(curTime.getMinutes() + sessionLimit);
			   oController.login = newLoginTime;
			});
		},
		
		_setToggleButtonTooltip : function(bLarge) {
			var toggleButton = this.byId('sideNavigationToggleButton');
			if (bLarge) {
				toggleButton.setTooltip('Large Size Navigation');
			} else {
				toggleButton.setTooltip('Small Size Navigation');
			}
		}
	});

});