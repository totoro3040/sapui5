/*global QUnit*/

sap.ui.define([
	"com/doosan/acl/controller/AppMain.controller"
], function (Controller) {
	"use strict";

	QUnit.module("AppMain Controller");

	QUnit.test("I should test the AppMain controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});