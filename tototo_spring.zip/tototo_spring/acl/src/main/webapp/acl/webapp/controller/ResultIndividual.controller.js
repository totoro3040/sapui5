/*eslint-disable no-console, no-alert, sap-no-ui5base-prop, no-eval, no-undef */ 
sap.ui.define([
	"sap/ui/Device",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master",
	"com/doosan/acl/common/Formatter",
	"sap/ui/model/BindingMode",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
    "sap/viz/ui5/data/FlattenedDataset",
    "sap/viz/ui5/format/ChartFormatter",
    "sap/viz/ui5/api/env/Format",
	"sap/m/SearchField"
], function (Device, Controller, MessageBox, Filter, Common, Master, Formatter, BindingMode, JSONModel, FeedItem, FlattenedDataset, ChartFormatter, Format, SearchField) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.ResultIndividual", {

		onInit: function () {
			
			// 기준 로드
			Master.getMasterList(this);
			
			// 항목 로드
			Master.getItemList(this);

			// 회사 리스트 조회
			Master.getUserAuthList(this);
			
			// 진단대상자 Model
			var oEmpModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oEmpModel,"emp");
			
			this.getEmpList();
			
			Format.numericFormatter(ChartFormatter.getInstance());
            this.formatPattern = ChartFormatter.DefaultPattern;            // set explored app's demo model on this sample
            
            
			// SFs oData metadata 로드
			// Busy Indicator 설정해준다.
			var oPage = this.getView().byId("dynamicPageId");
			oPage.setBusy(true);
			var sSfsUrl = "/doosan_sfs_odata"; // SucceeeFactors 운영
			var oModelSFs = new sap.ui.model.odata.ODataModel(sSfsUrl, true);
			
			oModelSFs.read("$metadata", {
				useBatch: true,
				success: function (oData, oResponse) {
					oPage.setBusy(false);
				},
				error: function (oError) {
					// Error Handling Here
					oPage.setBusy(false);
				}
			});
			
			
			this.messageBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

		},
		
		onSearchEmp: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Ename", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = this.byId("empList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "emp");
		},
		
		onSearchEmpEnable: function (oEvent) {
			// 좌측 진단대상자 검색창 표시
			var oDynamicSideContents = this.getView().byId("DynamicSideContent");
			oDynamicSideContents.setShowSideContent(true,false);
		},
		onEmpSelectionChange: function (oEvent) {
			// 사원이 선택되었을 때
			var oList = oEvent.getSource();
    		var oContexts = oList.getSelectedContexts();
			
			// PersonId, 사번을 알아낸다.
			var vPernr, vPersonId, vYear;
			if (oContexts && oContexts.length > 0){
				var sSelectedEmp = oContexts[0].getObject();
	    		vPernr = sSelectedEmp.Pernr;	
	    		vPersonId = sSelectedEmp.PersonId;
	    		vYear = sSelectedEmp.AsmtYear;	
			}
    		
    		if (!vPernr) {
    			Common.iMessageBox("error","alertNoEmpSelected",this);
    			return;
    		}
    		
    		// 개인별 Report 출력 시작
    		this.updateIndividualReport(vYear, vPernr, vPersonId);
		},
		
		onPDFexport: function(oEvent){
			var source = $("#UIComp_0")[0];
			
			source = $("#__component0---ResultIndividual--DynamicSideContent-MCGridCell");
			
			var oVizframe = this.getView().byId("competencyVizFrame");        // access chart UI element
			var sSVG = oVizframe.exportToSVGString({                  // UI5 predefined method
			  width: 800,
			  height: 600
			});
			
			html2canvas(source /*document.body*/ , {
				onrendered: function(canvas) {
					
					// 차트
					//canvg(canvas, sSVG);
					
	                // 캔버스를 이미지로 변환
	                var imgData = canvas.toDataURL('image/png');
	
	                var imgWidth = 210; // 이미지 가로 길이(mm) A4 기준
	                var pageHeight = imgWidth * 1.414;  // 출력 페이지 세로 길이 계산 A4 기준
	                var imgHeight = canvas.height * imgWidth / canvas.width;
	                var heightLeft = imgHeight;
	
	                var doc = new jsPDF('p', 'mm');
	                var position = 0;
	
	                // 첫 페이지 출력
	                doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
	                heightLeft -= pageHeight;
	
	                // 한 페이지 이상일 경우 루프 돌면서 출력
	                while (heightLeft >= 20) {
	                    position = heightLeft - imgHeight;
	                    doc.addPage();
	                    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
	                    heightLeft -= pageHeight;
	                }
	                
					doc.save("Chart.pdf");
				}

			});	
		},
		
		updateIndividualReport: function (vYear,vPernr,vPersonId) {
			/*
			* 개인별 보고서 조회
			*/
			
			// 대상자 검색 창은 숨김
			var oDynamicSideContents = this.getView().byId("DynamicSideContent");
			oDynamicSideContents.setShowSideContent(false,false);
			
			// 1. 기본정보 조회
			// 1-1. 사진 조회
			this.refreshBasicInfo(vYear,vPernr,vPersonId);
			
			// 2. 종합 결과 조회
			this.refreshOverall(vYear,vPernr);
			
			// 3. 역량진단 요약 결과 조회
			this.refreshSummaryComp(vYear,vPernr);
			
			// 4. 자질진단 요약 결과 조회
			this.refreshSummaryConfig(vYear,vPernr);
			
			// 5. 다면진단 요약 결과 조회
			this.refreshSummaryMultiDim(vYear,vPernr);
			
			// 6. Leadership Derailer 요약 결과 조회
			this.refreshSummaryDerailer(vYear,vPernr);
			
			// 7. 역량진단 결과 조회
			this.refreshCompetency(vYear,vPernr);
			
		},
		
		refreshBasicInfo: function (vYear,vPernr,vPersonId){
			var oController = this;
			
			var oPanel = this.getView().byId("basicInfoPanel");
			oPanel.setBusy(true);
			
			var sSfsUrl = "/doosan_sfs_odata"; // SucceeeFactors 운영
			var oModelSFs = new sap.ui.model.odata.ODataModel(sSfsUrl, true);
			
			var oPhoto = this.byId("empPhoto");
    		oPhoto.setSrc(""); 
			oModelSFs.read("/Photo(photoType=1,userId='" + vPersonId + "')", {
				success: function (oData, oResponse) {
					if (oData && oData.photo) {
						oPhoto.setSrc("data:image/bmp;base64," + oData.photo);
					}
				},
				error: function (oError) {
					// Error Handling Here
					
				}
			});
			
			// 1-2. 소속 및 신상 정보
			var sEmpServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/EmpService.xsjs";
			var sData = {
				type:"getEmpBasicInfo",
				year:vYear,
				pernr:vPernr
			};
			Common.commonAjaxCall(sEmpServicelUrl,"POST",sData,oController,this.setBasicInfo);
				
		},
		
		refreshOverall: function (vYear,vPernr) {
			/*
			* 종합 결과 업데이트
			*/
			var oController = this;
			
			var oPanel = this.getView().byId("overallPanel");
			oPanel.setBusy(true);
			
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sData = {
				type : "getOverallResult",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setOverallResult);
		},
		
		refreshSummaryComp: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oPanel = this.getView().byId("summaryCompPanel");
			oPanel.setBusy(true);
			
			/* 1. 역량진단 커맨트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sData = {
				type : "getCompetencyResultComment",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setSummaryCompComment);
			
			/* 2. 역량진단 차트 */
			var sDataChart = {
				type : "getCompetencyResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataChart,oController,this.setSummaryCompChart);
			
		},
		
		refreshSummaryConfig: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oPanel = this.getView().byId("summaryConfigPanel");
			oPanel.setBusy(true);
			
			/* 1. 자질진단 커맨트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sData = {
				type : "getConfigurationResultComment",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setSummaryConfigComment);
			
			/* 1. 자질진단 차트 */
			var sDataChart = {
				type : "getConfigurationResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataChart,oController,this.setSummaryConfigChart);
			
		},
		
		refreshSummaryMultiDim: function (vYear,vPernr) {
			/*
			* 요약 결과 업데이트
			*/
			var oController = this;
			
			var oPanel = this.getView().byId("summaryMultiDimPanel");
			oPanel.setBusy(true);
			
			/* 1. 다면진단 차트 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sDataChart = {
				type : "getMultiDimensionResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sDataChart,oController,this.setSummaryMultiDimChart);
			
		},
		
		refreshSummaryDerailer: function(vYear,vPernr){
			var oController = this;
			
			var oPanel = this.getView().byId("summaryDerailerPanel");
			oPanel.setBusy(true);
			
			/* 1. Derailer 테이블 */
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sData = {
				type : "getDerailerResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setLeadershipDerailer);
			
		},
		
		refreshCompetency: function (vYear,vPernr) {
			
			/*
			* 역량진단 결과 업데이트
			*/
			/*
			var oController = this;
			
			var oPanel = this.getView().byId("summaryPanel");
			oPanel.setBusy(true);
			
			var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
			var sData = {
				type : "getCompetencyResultPerItem",
				year : vYear,
				pernr : vPernr
			};
			Common.commonAjaxCall(sResultServicelUrl,"POST",sData,oController,this.setCompetencyResult);
			*/
		},
		
		setBasicInfo: function (result, oController) {
			var oBasicInfoModel = new sap.ui.model.json.JSONModel();
			oBasicInfoModel.setData(result);
			oController.getView().setModel(oBasicInfoModel,"basic");
			
			var oPanel = oController.getView().byId("basicInfoPanel");
			oPanel.setBusy(false);
			
		},
		
		setOverallResult: function (result, oController) {
			
			// Table Rendering
			var oOverallModel = new sap.ui.model.json.JSONModel();
			oOverallModel.setData(result);
			var oOverallTable = oController.getView().byId("overallTable");
			oOverallTable.setModel(oOverallModel);
			
			// Busy indicator 해제
			var oPanel = oController.getView().byId("overallPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
			
		},
		
		setSummaryCompComment: function (result, oController) {
			/*
			* 진단결과 요약 : 역량진단 커맨트
			*/
			
			var oCompetencyCmntModel = new sap.ui.model.json.JSONModel();
			oCompetencyCmntModel.setData(result);
			var oCompetencyCmntBox = oController.getView().byId("summaryCompComment");
			oCompetencyCmntBox.setModel(oCompetencyCmntModel);
			
		},
		
		setSummaryConfigComment: function (result, oController) {
			/*
			* 진단결과 요약 : 자질진단 커맨트
			*/
			
			var oConfigurationCmntModel = new sap.ui.model.json.JSONModel();
			oConfigurationCmntModel.setData(result);
			var oConfigurationCmntBox = oController.getView().byId("summaryConfigComment");
			oConfigurationCmntBox.setModel(oConfigurationCmntModel);
			
		},
		
		
		setSummaryCompChart: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("competencyVizFrame");
			var oPopover = oController.getView().byId("competencyPopover");
			
			// 차트 설정
			var vSetting = {
				chartType : "radar",
				dimensions : [{
					name : "ItemTx",
					value : "{ItemTx}"}
				],
				
				measures : [{
					name : "본인",
					value : "{Result}"
					},
					{
					name : "진단그룹전체",
					value : "{ResultRv}"
					}
				],
				
				properties : {
					plotArea: {
						colorPalette : d3.scale.category20().range(),	
						valueAxis: {
							scale : {
			                  fixedRange : true,
			                  minValue : 0,
			                  maxValue : 4.5
							}
						}
					},
					legendGroup: {
						layout: {
							alignment: "center",
							position: "top" // top, right, auto, bottom
						}
					}
				}
			};
			
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
			
			var oPanel = oController.getView().byId("summaryCompPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
			
		},
		
		setSummaryConfigChart: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("configurationVizFrame");
			var oPopover = oController.getView().byId("configurationPopover");
			
			// 차트 설정
			var vSetting = {
				chartType : "radar",
				dimensions : [{
					name : "ItemTx",
					value : "{ItemTx}"}
				],
				
				measures : [{
					name : "본인",
					value : "{Result}"
					},
					{
					name : "진단그룹전체",
					value : "{ResultRv}"
					}
				],
				
				properties : {
					plotArea: {
						colorPalette : d3.scale.category20().range(),	
						valueAxis: {
							scale : {
			                  fixedRange : true,
			                  minValue : 0,
			                  maxValue : 100
							}
						}
					},
					legendGroup: {
						layout: {
							alignment: "center",
							position: "top" // top, right, auto, bottom
						}
					}
				}
			};
			
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
			
			var oPanel = oController.getView().byId("summaryConfigPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
			
		},
		
		setSummaryMultiDimChart: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("multiDimensionVizFrame");
			var oPopover = oController.getView().byId("multiDimensionPopover");
			
			// 차트 설정
			var vSetting = {
				chartType : "line",
				dimensions : [{
					name : "ItemTx",
					value : "{ItemTx}"}
				],
				
				measures : [{
					name : "본인",
					value : "{ResultSelf}"
					},
					{
					name : "상사",
					value : "{ResultMgr}"
					},
					{
					name : "부하",
					value : "{ResultMem}"
					}
				],
				
				properties : {
					plotArea: {
						colorPalette : d3.scale.category20().range(),
						dataLabel: {
	                        formatString: oController.formatPattern.SHORTFLOAT_MFD2,
	                        visible: true
	                    }
					},
					categoryAxis: {
						title:{
							visible: false
						}	
					},
					valueAxis: {
						title:{
								visible: false
						},
	                    scale : {
		                  fixedRange : true,
		                  minValue : 3,
		                  maxValue : 7
		                }
					},
					legendGroup: {
						layout: {
							alignment: "leftTop",
							position: "right" // top, right, auto, bottom
						}
					}
				}
			};
			
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
			
			var oPanel = oController.getView().byId("summaryMultiDimPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
			
		},
		
		setLeadershipDerailer: function (result, oController) {
			/*
			* 진단결과 : Leadership Derailer
			*/
			var oLeadershipDerailerModel = new sap.ui.model.json.JSONModel();
			oLeadershipDerailerModel.setData(result);
			var oLeadershipDerailerTable = oController.getView().byId("derailerTable");
			oLeadershipDerailerTable.setModel(oLeadershipDerailerModel);
			oLeadershipDerailerTable.bindRows("/data");
			
			var oPanel = oController.getView().byId("summaryDerailerPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
			
		},
		
		setCompetencyResult: function (result, oController) {
			
			var oVizFrame = oController.getView().byId("competencyVizFrame");
			var oPopover = oController.getView().byId("competencyPopover");
			
			// 차트 설정
			var vSetting = {
				chartType : "radar"
			};
			
			// 차트 Rendering
			Common.makeChart(vSetting, result.data, oVizFrame, oPopover);
			
			// Table Rendering
			var oCompetencyItemModel = new sap.ui.model.json.JSONModel();
			oCompetencyItemModel.setData(result);
			var oCompetencyTable = oController.getView().byId("competancyItemTable");
			oCompetencyTable.setModel(oCompetencyItemModel);
			
			oCompetencyTable.setVisibleRowCount(result.data.length);
			
			var oPanel = oController.getView().byId("summaryPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
			
		},
		
		
		getEmpList: function(){
			/*
			* 사용자 권한에 해당하는 진단대상자를 조회한다. 
			*/
			var sEmpServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/EmpService.xsjs";
			var oController = this;
			var sData = {};
			Common.commonAjaxCall(sEmpServicelUrl,"GET",sData,oController,this.setEmpList);
		},
		
		setEmpList: function(result, oController){
			var empList = { data : result };
			var oEmpModel = oController.getView().getModel("emp");
			oEmpModel.setData(empList);
		}

	});

});