/*eslint-disable no-console, no-alert, sap-no-ui5base-prop, no-eval, sap-no-location-reload */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master"
], function (Controller,MessageBox,MessageToast,Common,Master) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.UploadingResult", {

		onInit: function () {
				/*
				* 차수 정보 및 항목정보 조회
				*/
				// 기준 로드
				Master.getMasterList(this);
				Master.getTemplateList(this);
				
				// 템플릿 테이블 구성
				//this.createTemplateTable("template","X","X","X");
				
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this.oRouter.getRoute("UploadingResult").attachPatternMatched(this.onObjectMatched, this);
				
		},
		
		onObjectMatched: function (oEvent) {
			// 기준 로드
			Master.getMasterList(this);
			
			// 템플릿 테이블 구성
			//this.createTemplateTable("template","X","X","X");
		},
		
		onActivate: function (oEvent) {
			//var oStep = oEvent.getSource();
			//var stepId = oStep.getId();
		},
		
		onDownloadTemplate: function (oEvent) {
			// Template Excel Downalod 시작
			var oList = this.getView().byId("uploadTemplateList");
			var oItem = oList.getSelectedItem();
			var oCtx = oItem.getBindingContext("template");
			var selectedTemplateId = oCtx.getProperty("TEMPLATE_ID");
			var selectedTemplateText = oCtx.getProperty("TEMPLATE_TEXT_KO");
			this.downloadTemplate(selectedTemplateId,selectedTemplateText);
		},
		
		onSelectItem: function (oEvent) {
			// 업로드 유형 선택 시 진행
			var oWizard = this.getView().byId("UploadDataWizard");
			var oNextStep = this.getView().byId("UploadFile");
			var oItem = oEvent.getSource();
			
			var oList = this.getView().byId("uploadTemplateList");
			oList.setSelectedItem(oItem,true);
			if (oWizard.getCurrentStep().indexOf("DownloadTemplate") >= 0) {
				oWizard.nextStep();
			}
			else {
				oWizard.goToStep(oNextStep,false);
			}
		},
		
		onExport : function (oEvent) {
			this.createTemplateTable("excel","","X","X");
		},
		
		onExportData : function (oEvent) {
			this.createTemplateTable("excel","","","X");
		},
		
		onTypeMissmatch: function (oEvent) {
			MessageBox.information("Only 'CSV UTF-8' File is available", {
				title: "Warning"
			});
		},
		onUploadClose: function (oEvent) { 
			try{
				this._oUploadDialog.close();
			} catch (e){
				Common.errorHandling(e, this);
			}
		},
		onUploadFile : function (oEvent) {
			
			// CSV 파일 선택 이후의 작업
			var oController = this;
			
			var file = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
			
			/* CSV 읽어서 처리한다  */
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.readAsText(file);

				reader.onload = function () {
					var fileString = reader.result; 
					
					var rows = fileString.split("\r\n"); // 일단 행으로만 잘라준다.
					
					/*
					* Header Line 찾기 (ID기준)
					*/
					var fData = false;
					var lv1Items = [];
					var header = [];
					var data = [];
					var cols = 0;
					var empCnt = 0;
					for (var r = 0; r < rows.length; r++){
						if (r === 0) { // 첫 행은 기본정보 및 진단 대항목
							lv1Items.push(rows[r].split(/,(?=(?:(?:[^'"]*(?:'|")){2})*[^'"]*$)/));
						}
						
						// PERNR이 있는 행을 헤더로 본다
						if (rows[r].indexOf("PERNR") >= 0) {
							header.push(rows[r].split(/,(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)/));
							fData = true;
							cols = header[0].length;
						} else if (fData){
							/*
								,               ','
								(?=             look ahead to see if there is:
								(?:             group, but do not capture (0 or more times):
								(?:             group, but do not capture (2 times):
								 [^"]*          any character except: '"' (0 or more times)
								 "              '"'
								){2}            end of grouping
								)*              end of grouping
								 [^"]*          any character except: '"' (0 or more times)
								$               before an optional \n, and the end of the string
								)               end of look-ahead
							*/
							//var dataRow = rows[r].split(/,(?=(?:(?:[^'"]*(?:'|")){2})*[^'"]*$)/);
							var dataRow = rows[r].split(/,(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)/);
							
							if (dataRow.length === cols){
								data.push(dataRow);	
							}
						}
					}
					
					var vUploadData = Common.convertRowsToObjArray(header[0],data);
					for (var vd = 0; vd < vUploadData.length; vd++){
						if (vd === vUploadData.length -1 || vUploadData[vd].PERNR != vUploadData[vd+1].PERNR){
							empCnt++;	
						}
					}
					
					// Upload Dialog 생성해준다.
				   	if (!oController._oUploadDialog) {
						oController._oUploadDialog = sap.ui.xmlfragment("com.doosan.acl.fragment.UploadPopup", oController);
			            oController.getView().addDependent(oController._oUploadDialog);
					} 
					
					var vData = { "data" : vUploadData, "header": header, "empCnt": empCnt};
					var oUploadModel = new sap.ui.model.json.JSONModel(vData);
					oController._oUploadDialog.setModel(oUploadModel,"upload");
					oController._oUploadDialog.open();

				};
			} else { // File이 없어!
				MessageBox.information("Please choose file", {
					title: "No file"
				});
			}
		},
		onUploadStart: function(oEvent){
			
			var oController = this; 
			var oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
			
			try{
				this._oUploadDialog.close();
				
				// Upload Progress Dialog 생성해준다.
			   	if (!this._oUploadProgressDialog) {
					this._oUploadProgressDialog = sap.ui.xmlfragment("com.doosan.acl.fragment.UploadProgressPopup", this);
		            this.getView().addDependent(this._oUploadProgressDialog);
				} 
				
				// 업로드 요청 데이터
				var oUploadModel = this._oUploadDialog.getModel("upload");
				var vUploadData = oUploadModel.getData();
				this._oUploadProgressDialog.open();
				
				var rowData = [];
				var totalRows = vUploadData.data.length;
				var oProgressBar =  sap.ui.getCore().byId("uploadIndicator");
				var oProgressText =  sap.ui.getCore().byId("uploadProgressText");
				var empCnt = 0;
				var callCnt = 0;
				var totalComplete = 0;
				setTimeout(function(){
					console.log("Ready!");
				},2000);
				
				for (var ud = 0; ud < totalRows; ud++){
					
					// 동일인에 대해서는 한 번에 변환해준다. 
					rowData.push(vUploadData.data[ud]);
					
					if (ud === totalRows - 1  || vUploadData.data[ud].PERNR != vUploadData.data[ud+1].PERNR ){
						
						// 업로드 형태로 변환
						var upData = Common.convertObjArrayToUploadForm(rowData);	
						// 데이터 저장 (Progress 표시를 위해 timeout 설정함)
						var clone = JSON.parse(JSON.stringify(upData));
						
						//oController.saveResultData(clone);	
						/*
						* 진단 결과를 저장한다.
						*/
						
							var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
							callCnt++;
							try{
								$.ajax({
									url: sResultServicelUrl,
									type: "POST",
									data: {
										jsonParam: JSON.stringify({
											"data":clone
										})
									},
									success: function (results) {
										
									},
									error: function (e) {
										
										Common.errorHandling(e, oController);
									},
									complete : function() {
								        // 진행상태 업그레이드
								        totalComplete++;
										var progress = parseInt(totalComplete / callCnt * 100, 10);
										/* Progress Bar 버전 
										oProgressBar.setPercentValue(progress);	
										oProgressBar.setDisplayValue(empCnt++ + " / " + callCnt + oBundle.getText("headCountUnit"));	
										*/
										/* Status Indicator 버전 */
										oProgressBar.setValue(progress);	
										oProgressText.setText(empCnt++ + " / " + callCnt + oBundle.getText("headCountUnit"));	
										
										// 완료 조건 : 전체 처리 완료
										if (totalComplete >= totalRows-1 || totalComplete === callCnt) {
											progress = 100;
											MessageBox.information(oBundle.getText("uploadComplete"), {
												title: "Success"
											});
											oController._oUploadProgressDialog.close();
											
											// 최종 결과 업데이트 (Procedure 실행)
											oController.onUploadCompleted();
											
											// 다음단계(Step3)로 넘어감
											var oWizard = oController.getView().byId("UploadDataWizard");
											oWizard.nextStep();
										}

								    }
								});	
							}catch (ex) {
								Common.errorHandling(ex , oController);
							}	
					
						
						// 초기화
						rowData = [];
					}
					
				}
				
			} catch (e){
				Common.errorHandling(e, this);
			}
		},
		onConfirmData: function(oEvent){
			// 
		},
		
		onUploadCompleted : function(){
				var oController = this;
				var sUpdateFinalResultUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
				try{
					$.ajax({
						url: sUpdateFinalResultUrl,
						type: "POST",
						data: {
							jsonParam: JSON.stringify({
								"type":"updateFinalResult"
							})
						},
						success: function (results) {
							
						},
						error: function (e) {
							Common.errorHandling(e, oController);
						}
					});	
				}catch (ex) {
					Common.errorHandling(ex , oController);
				}	
		},
		
		saveResultData: function (vUploadData){
			
			var oController = this;
			
			/*
			var oGlobalBusyDialog = new sap.m.BusyDialog();
			oGlobalBusyDialog.open();
			oGlobalBusyDialog.setBusyIndicatorDelay(3000);
			*/
			
			/*
			* 진단 결과를 저장한다.
			*/
			setTimeout(function(){
				var sResultServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtResultService.xsjs";
				try{
					$.ajax({
						url: sResultServicelUrl,
						type: "POST",
						data: {
							jsonParam: JSON.stringify({
								"data":vUploadData
							})
						},
						success: function (results) {
							// 업로드 결과 표시
							//oGlobalBusyDialog.close();
						},
						error: function (e) {
							Common.errorHandling(e, oController);
							//oGlobalBusyDialog.close();
						}
					});	
				}catch (ex) {
					Common.errorHandling(ex , oController);
					//oGlobalBusyDialog.close();
				}	
			},500);
		},
		onRvSelectionChange: function(oEvent){
			this.createTemplateTable("template","X","X","X");
		},
		createTemplateTable: function (mode,exptCalc,nodata,colspan,tableId,mapData,asmtYear) {
			var oController = this;
			var targetTableId = "uploadTemplateTable";
			if (tableId) {
				targetTableId = tableId;
			}
			var oTemplateTable = this.getView().byId(targetTableId);
			oTemplateTable.setBusy(true);
			
			var oMasterModel = this.getView().getModel("master");
			var vMasterData = oMasterModel.getData();
			
			if (!asmtYear){
				asmtYear = vMasterData.data.curYear;
			}
			
			// Role Level 정의
			var oRvFilter = this.getView().byId("uploadRoleLevel");
			var vRv = oRvFilter.getSelectedKey();
			
			if (!vRv) vRv = "TL";
			
			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/TemplateTableService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					type: "GET",
					data: {
						// nodata : Data는 조회하지 않음
						// exptCalc : 계산 항목은 제외
						jsonParam: JSON.stringify({
							"mode":mode,
							"asmtYear":asmtYear,
							"exptCalc":exptCalc,
							"nodata":nodata,
							"colspan":colspan,
							"rv":vRv
						})
					},
					success: function (results) {
						// 테이블 정의 및 데이터 생성
						
						if (mode === "template"){
								var oHeaderData = results.headerList;
						
								Common.makeColumn(oTemplateTable, oHeaderData);
								
								try{
									var oBodyModel = new sap.ui.model.json.JSONModel();
									var tblData = { data:[] };
									if (mapData){
										tblData.data = mapData;	
									} else {
										tblData.data = results.data;
									}
									oBodyModel.setData(tblData);
									oTemplateTable.setModel(oBodyModel);
									oTemplateTable.bindRows("/data");
									console.log(tblData);
								} catch (ex) {
									Common.errorHandling(ex , oController);
								} finally {
									oTemplateTable.setBusy(false);	
								}
						}
						
						else if (mode === "excel"){
							
							var fileName = "UploadTemplate.xls";
					        
					        var responseType = "data:application/vnd.ms-excel";
					        Common.downloadFile(results,fileName,responseType);    
					        oTemplateTable.setBusy(false);	
						}
						
					},
					error: function (e) {
						Common.errorHandling(e, oController);
						oTemplateTable.setBusy(false);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}

		},
		downloadTemplate: function (templateId,templateText) {
			var oController = this;
			
			var oGlobalBusyDialog = new sap.m.BusyDialog();
			oGlobalBusyDialog.open();
			oGlobalBusyDialog.setBusyIndicatorDelay(3000);

			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtTemplateService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					type: "POST",
					data: {
						jsonParam: JSON.stringify({
							"type":"downloadTemplate",
							"templateId":templateId
						})
					},
					success: function (results) {
						// 테이블 정의 및 데이터 생성
						//var fileName = "UploadTemplate.xls";
						var fileName = templateText+ "_" + new Date().toISOString().slice(0,18) + ".xls";
					        
				        var responseType = "data:application/vnd.ms-excel";
				        Common.downloadFile(results,fileName,responseType);    
				        oGlobalBusyDialog.close();
					},
					error: function (e) {
						Common.errorHandling(e, oController);
						oGlobalBusyDialog.close();
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
				oGlobalBusyDialog.close();
			}finally{
				
			}

		} // end of downloadTemplate


	});

});