/*eslint-disable no-console, no-alert, no-eval, no-location-reload */
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/odata/ODataModel",
	"jquery.sap.global",
	"sap/m/MessageToast",
	"sap/m/Button",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/export/Spreadsheet",
	"com/doosan/acl/common/Common"
], function (JSONModel, MessageBox, ODataModel, jQuery, MessageToast, Button, Fragment, Controller, Spreadsheet, Common) {
	"use strict";

	return {
		getMasterList: function(oController){
			
			// 기준모델
			var oMasterModel = new sap.ui.model.json.JSONModel();
			oController.getView().setModel(oMasterModel,"master");
				
			/*
			* Master 조회한다. 
			*/
			var sMasterServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtMstService.xsjs";
			try{
				$.ajax({
					url: sMasterServicelUrl,
					//type: "GET",
					data: {
						jsonParam: JSON.stringify({
							
						})
					},
					success: function (results) {
						// Master Model 등록
						//oMasterModel = oController.getView().getModel("master");
						var vMasterData = { data : [] };
						vMasterData.data = results;
						console.log(results);
						oMasterModel.setData(vMasterData);
					},
					error: function (e) {
						Common.errorHandling(e, oController);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}	
		},
		getItemTree: function(oController){
			
			// 항목모델
			var oItemModel = new sap.ui.model.json.JSONModel();
			oController.getView().setModel(oItemModel,"itemTree");
			
			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtItemService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					//type: "GET",
					data: {
						jsonParam: JSON.stringify({
							
						})
					},
					success: function (results) {
						// Master Model 등록
						//var oItemModel = oController.getView().getModel("item");
						var vItemData = { data : [] };
						vItemData.data = results;
						oItemModel.setData(vItemData);
					},
					error: function (e) {
						Common.errorHandling(e, oController);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}	
		},
		getItemList: function(oController){
			
			// 항목모델
			var oItemModel = new sap.ui.model.json.JSONModel();
			oController.getView().setModel(oItemModel,"item");
			
			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtItemService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					type: "POST",
					data: {
						jsonParam: JSON.stringify({
							type:"getItemList"
						})
					},
					success: function (results) {
						console.log(results);
						// Master Model 등록
						var vItemData = { data : [] };
						vItemData.data = results;
						oItemModel.setData(vItemData);
					},
					error: function (e) {
						Common.errorHandling(e, oController);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}	
		},
		getTemplateList: function(oController){
			
			// 항목모델
			var oTemplateModel = new sap.ui.model.json.JSONModel();
			oController.getView().setModel(oTemplateModel,"template");
			
			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/AsmtTemplateService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					type: "POST",
					data: {
						jsonParam: JSON.stringify({
							type:"getTemplateList"
						})
					},
					success: function (results) {
						// Master Model 등록
						var vTemplateData = { data : [] };
						vTemplateData.data = results;
						oTemplateModel.setData(vTemplateData);
					},
					error: function (e) {
						Common.errorHandling(e, oController);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}	
		},
		getUserAuthList: function(oController){
			
			// 기준모델
			var oAuthModel = new sap.ui.model.json.JSONModel();
			oController.getView().setModel(oAuthModel,"auth");
				
			/*
			* Master 조회한다. 
			*/
			var sMasterServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/CommonService.xsjs";
			try{
				$.ajax({
					url: sMasterServicelUrl,
					type: "POST",
					data: {
						jsonParam: JSON.stringify({
							"type":"getUserAuthList"
						})
					},
					success: function (results) {
						oAuthModel.setData(results);
					},
					error: function (e) {
						Common.errorHandling(e, oController);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}	
		}
	};
});