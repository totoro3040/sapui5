sap.ui.define([
	"sap/ui/Device",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"com/doosan/acl/common/Common",
	"com/doosan/acl/common/Master",
	"sap/ui/model/BindingMode",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
    "sap/viz/ui5/data/FlattenedDataset",
    "sap/viz/ui5/format/ChartFormatter",
    "sap/viz/ui5/api/env/Format"
], function (Device, Controller,MessageBox,Common,Master,BindingMode, JSONModel, FeedItem, FlattenedDataset, ChartFormatter,Format) {
	"use strict";

	return Controller.extend("com.doosan.acl.controller.ResultCompany", {

		oVizFrame : null,

		onInit : function (evt) {
	
			// 회사 리스트 조회
			Master.getUserAuthList(this);
			
			var oVizFrame = this.getView().byId("asmtVizFrame");
            
			// 1. 역량 Chart 설정
            Format.numericFormatter(ChartFormatter.getInstance());
            var formatPattern = ChartFormatter.DefaultPattern;            // set explored app's demo model on this sample
            
            oVizFrame.setVizProperties({
                plotArea: {
                    dataLabel: {
                        formatString: formatPattern.SHORTFLOAT_MFD2,
                        visible: true
                    },
                    dataShape: {
                        primaryAxis: ["line", "bar"]
                    },
                    colorPalette:["sapUiChartZeroAxisColor","sapUiChartPaletteQualitativeHue1","sapUiChartPaletteQualitativeHue2"]
                },
                valueAxis: {
                    label: {
                        formatString: formatPattern.SHORTFLOAT
                    },
                    title: {
                        visible: false
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    },
                    label: {
						linesOfWrap: 2,
						style: {
							fontSize: "12px"
						}
					},
					axisTick: {
						shortTickVisible: true
					},
					
					layout: {
						height : "auto"
					}
					
                },
                title: {
                    visible: false,
                    text:"역량군/역량별 평균 비교"
                }
            });
            
            // 결과 조회
			//this.getAssessmentResult("competencyReport");
			
			// 2. Derailer Chart 설정
			var oVizFrame2 = this.getView().byId("derailerVizFrame");
            
            oVizFrame2.setVizProperties({
                plotArea: {
                    dataLabel: {
                        formatString: formatPattern.STANDARDPERCENT_MFD2,
                        visible: true
                    },
                    //colorPalette:["#e0ebf4","#ccffcc","#ffffcc","#ffe5e5"]
                    colorPalette:["#b5daf8","#8fe88f","#faf379","#f5b4b4"]
                },
                valueAxis: {
                    label: {
                        formatString: formatPattern.STANDARDPERCENT_MFD2
                    },
                    title: {
                        visible: true,
                        text: "위험유형 별 인원(명)"
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    },
                    label: {
						linesOfWrap: 2,
						style: {fontSize: "14px"},
						parentStyle: {fontSize: "14px"},
						alignment:"center",
						position:"left"
					},
					axisTick: {
						shortTickVisible: true
					}
                },
                title: {
                    visible: false
                }
            });
            
			//this.getAssessmentResult("derailerReport");
			
			// 3. 다면진단 Chart 설정
			var oVizFrame3 = this.getView().byId("multiDimVizFrame");
            
            oVizFrame3.setVizProperties({
                plotArea: {
                    dataLabel: {
                        formatString: formatPattern.SHORTFLOAT_MFD2,
                        visible: true
                    }
                },
                valueAxis: {
                    label: {
                        formatString: formatPattern.SHORTFLOAT
                    },
                    scale : {
	                  fixedRange : true,
	                  minValue : 3,
	                  maxValue : 7
	                },
                    title: {
                        visible: false
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    },
                    label: {
						linesOfWrap: 2,
						style: {
							fontSize: "12px"
						}
					},
					axisTick: {
						shortTickVisible: true
					},
					layout: {
						height : "200px"
					}
                },
                title: {
                    visible: false
                }
            });
            
			this.messageBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },
        onSearch: function(oEvent) {
        	var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
        	var vPersa = this.getView().byId("filterAuth").getSelectedKey();
        	var vRv = this.getView().byId("filterRoleLevel").getSelectedKey();
        	
        	if (!vPersa || vPersa.length === 0){
        		MessageBox.information(oBundle.getText("noCompany"), {
					title: "Warning"
				});
        		return;
        	} else {
        		
        		this.updateCompanyReport(vPersa,vRv);
        		
				this.getAssessmentResult("competencyReport");
				this.getAssessmentResult("competencyReportTableBg");
				this.getAssessmentResult("competencyReportTableFunction");
				this.getAssessmentResult("multiDimensionReport");
				this.getAssessmentResult("derailerReport");
        	}
        },
        onAfterRendering : function(){
			
        },
        
        onAfterRenderingTable:function(oEvent) {
        	/*
        	* 하단 Total Row 처리
        	*/
        	if (oEvent.type !== "AfterRendering"){
				      this.onvscroll(oEvent);
		    }
		    var lastRow = this.getVisibleRowCount() - 1;   //number of rows on tab
		    
		    var rowId = this.getRows()[lastRow].getId();		   
            
			$("#" + rowId).css("background-color", "#EFF4F9");	
			$("#" + rowId).css("font-weight", "bold");
			$("#" + rowId + "-fixed").css("background-color", "#EFF4F9");	
			$("#" + rowId + "-fixed").css("font-weight", "bold");
			
			/*
        	* Cell 병합 처리 (첫 열만)
        	*/
        	Common.mergeTableCell(this,1);
        },
        
        onExportFunctionData:function(oEvent) {
        	this.getAssessmentResult("competencyReportFunctionExcel");
        },
        
        onExportBgData:function(oEvent) {
        	this.getAssessmentResult("competencyReportBgExcel");
        },
        
        updateCompanyReport: function(vPersa,vRv){
        	// 1. 기본정보 조회
			this.refreshBasicInfo(vPersa,vRv);
			
        },
        
        refreshBasicInfo: function (vPersa,vRv){
			var oController = this;
			
			var oPanel = this.getView().byId("basicPanel");
			oPanel.setBusy(true);
			
			// Panel Title 변경
			var vPersaTx = this.getView().byId("filterAuth").getSelectedItem().getText();
        	var vRvTx = vRv === "EX" ? this.messageBundle.getText("executive") : this.messageBundle.getText("teamleader");
        	
        	var oPanelTitle = this.getView().byId("basicPanelTitle");
        	oPanelTitle.setText(vPersaTx + " " + vRvTx);
			
			// 기본정보 (대상자 수)
			var sReportServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/ReportService.xsjs";
			var sData = {
				type:"getReportBasicInfo",
				persa:vPersa,
				rv:[vRv]
			};
			Common.commonAjaxCall(sReportServicelUrl,"POST",sData,oController,this.setBasicInfo);
				
		},
		
		setBasicInfo: function (result, oController) {
			var oBasicInfoModel = new sap.ui.model.json.JSONModel();
			oBasicInfoModel.setData(result.data);
			oController.getView().setModel(oBasicInfoModel,"basic");
			
			var oBasicInfoLabel = oController.getView().byId("basicPanelInfo");
			oBasicInfoLabel.setVisible(true);
			
			// Busy indicator 해제
			var oPanel = oController.getView().byId("basicPanel");
			setTimeout(function() {
			  oPanel.setBusy(false);
			}, 1000);
		},
        
        getAssessmentResult: function(vMode){
        	var oController = this;
        	
        	var oBasicPanelTitle = this.getView().byId("basicPanelTitle");
        	var oBasicPanelInfo = this.getView().byId("basicPanelInfo");
        	
        	var formatPattern = ChartFormatter.DefaultPattern;
        	
        	// 조건 Setting
        	var vPersa = this.getView().byId("filterAuth").getSelectedKey();
        	var vRv = this.getView().byId("filterRoleLevel").getSelectedKey();
        	
        	var items = ["IT00000001"];
        	var reportResult = {};
        	
			/*
			* 역량진달 결과를 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/ReportService.xsjs";
			try{
				
				if (vPersa) {
					$.ajax({
						url: sItemServicelUrl,
						type: "POST",
						data: {
							// nodata : Data는 조회하지 않음
							// exptCalc : 계산 항목은 제외
							jsonParam: JSON.stringify({
								"type":vMode,
								"items":items,
								"persa":vPersa,
								"rv": vRv
							})
						},
						success: function (results) {
							// 진단 결과를 차트에 반영
							var oVizFrame;
							var oPopOver; 
							var oChartModel = new JSONModel();
							
							switch(vMode){
								case "competencyReport": 
									oVizFrame = oController.getView().byId("asmtVizFrame");
									oPopOver = oController.getView().byId("asmtPopover");
									reportResult.data = results.data;
									oVizFrame.setModel(oChartModel);
									oChartModel.setData(reportResult);
									oPopOver.connect(oVizFrame.getVizUid());
						            oPopOver.setFormatString(formatPattern.SHORTFLOAT_MFD2);
						            
									var groupAvg = results.groupAvg;
				            
						            if (groupAvg){
						            	var oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
								        var msgGroupAvg = oBundle.getText("avgGroup");
						            	 oVizFrame.setVizProperties({
								                plotArea: {
								                    dataLabel: {
								                        formatString: formatPattern.SHORTFLOAT_MFD2,
								                        visible: true
								                    },
								                    dataShape: {
								                        primaryAxis: ["line", "bar"]
								                    },
								                    referenceLine: {
									                    line: {
									                        valueAxis: [{
									                            value: groupAvg,
									                            visible: true,
									                            label: {
									                                text: msgGroupAvg +"(" + groupAvg.toFixed(2) + ")" ,
									                                visible: true
									                            }
									                        }]
									                    }
									                }
								                }
						                });
						            }
						           			
									break;
								case "competencyReportTableBg":
									var oBgTable = oController.getView().byId("resultBgTable");
									Common.makeColumn(oBgTable, results.headerList);
									oBgTable.setModel(new sap.ui.model.json.JSONModel({ data:results.data }));
									oBgTable.setVisibleRowCount(results.data.length);
									oBgTable.bindRows("/data");
									// 데이터 Binding 이후의 Event 처리
									oBgTable.addDelegate({ onAfterRendering : oController.onAfterRenderingTable },oBgTable);	
									break;
								case "competencyReportTableFunction":
									var oFunctionTable = oController.getView().byId("resultFunctionTable");
									Common.makeColumn(oFunctionTable, results.headerList);
									oFunctionTable.setModel(new sap.ui.model.json.JSONModel({ data:results.data }));
									oFunctionTable.setVisibleRowCount(results.data.length);
									oFunctionTable.bindRows("/data");
									// 데이터 Binding 이후의 Event 처리
									oFunctionTable.addDelegate({ onAfterRendering : oController.onAfterRenderingTable },oFunctionTable);	
									break;
								case "competencyReportBgExcel":
									var fileName = "CompetencyResultPerBG.xls";
					                var responseType = "data:application/vnd.ms-excel";
							        Common.downloadFile(results,fileName,responseType);    
									break;	
								case "competencyReportFunctionExcel":
									var fileName = "CompetencyResultPerFunction.xls";
					                var responseType = "data:application/vnd.ms-excel";
							        Common.downloadFile(results,fileName,responseType);    
									break;
								case "multiDimensionReport": 
									oVizFrame = oController.getView().byId("multiDimVizFrame");
									oPopOver = oController.getView().byId("multiDimPopover");
									reportResult.data = results.data;
									oVizFrame.setModel(oChartModel);
									oChartModel.setData(reportResult);
									oPopOver.connect(oVizFrame.getVizUid());
						            oPopOver.setFormatString(formatPattern.SHORTFLOAT_MFD2);
									break;	
								case "derailerReport":
									oVizFrame = oController.getView().byId("derailerVizFrame");
									oPopOver = oController.getView().byId("derailerPopover");
									reportResult.data = results.data;
									oVizFrame.setModel(oChartModel);
									oChartModel.setData(reportResult);
									oPopOver.connect(oVizFrame.getVizUid());
						            oPopOver.setFormatString(formatPattern.STANDARDPERCENT_MFD2);
									break;
							}
							
						},
						error: function (e) {
							Common.errorHandling(e, oController);
						}
					});	
				}
				
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}
        },
        getPersonalResult:function() {
        	var oController = this;
			var targetTableId = "personalResultTable";
			var oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
			var mode = "result";
			var oResultTable = this.getView().byId(targetTableId);
			oResultTable.setBusy(true);
			var oEmpCnt = oController.getView().byId("resultEmpCnt");
			oEmpCnt.setText("");
			
			// Filter 값
			var year = this.getView().byId("filterYear").getSelectedKeys();
			var rv = this.getView().byId("filterRoleLevel").getSelectedKeys();
			var persa = this.getView().byId("filterPersa").getSelectedKey();
			/*
			* 진단항목을 조회한다. 
			*/
			var sItemServicelUrl = "/doosan_hanaxs_odata/assessment-center/src/xsjs/TemplateTableService.xsjs";
			try{
				$.ajax({
					url: sItemServicelUrl,
					type: "GET",
					data: {
						// nodata : Data는 조회하지 않음
						// exptCalc : 계산 항목은 제외
						jsonParam: JSON.stringify({
							"mode":mode,
							"year":persa,
							"persa":persa,
							"rv":rv,
						})
					},
					success: function (results) {
						// 테이블 정의 및 데이터 생성
						if (mode === "result"){
								var oHeaderData = results.headerList;
								Common.makeColumn(oResultTable, oHeaderData);
								
								
								try{
									var oBodyModel = new sap.ui.model.json.JSONModel();
									var tblData = { data:[] };
									tblData.data = results.data;
									oBodyModel.setData(tblData);
									oResultTable.setModel(oBodyModel);
									oResultTable.bindRows("/data");
									oEmpCnt.setText(oBundle.getText("assessee")+": "+results.cnt.EMP_CNT+ ""+oBundle.getText("headCountUnit") 
													+ "(" + oBundle.getText("executive") + " " + results.cnt.EX_CNT + "" + oBundle.getText("headCountUnit") 
													+ ", " + oBundle.getText("teamleader") + " " + results.cnt.TL_CNT + "" + oBundle.getText("headCountUnit") + ")"
													);
								} catch (ex) {
									Common.errorHandling(ex , oController);
								} finally {
									oResultTable.setBusy(false);	
								}
						}
						
						else if (mode === "excel"){
							
							var fileName = "AssessmentResult_"+ year +".xls";
					        
					        var responseType = "data:application/vnd.ms-excel";
					        Common.downloadFile(results,fileName,responseType);    
					        oResultTable.setBusy(false);	
						}
						
					},
					error: function (e) {
						Common.errorHandling(e, oController);
						oResultTable.setBusy(false);
					}
				});	
			}catch (ex) {
				Common.errorHandling(ex , oController);
			}
        }
	});

});