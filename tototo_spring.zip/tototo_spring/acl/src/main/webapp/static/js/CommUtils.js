/* 
 * @설 명 : 공통 스크립트.
 * @author totoro@paran.com
 */
var CommUtils = {};

/**
 * 페이지 네비게이션
 */
CommUtils.pagination = function(obj) {
	var pagingHtml = [];
	if (obj.prev) {
		pagingHtml.push('<li class="page-item"><a class="page-link" href="#" onClick="fnGetList(' + (obj.startPage - 1) + ')">Previous</a></li>');
	} else {
		pagingHtml.push('<li class="page-item disabled"><span class="page-link">Previous</span>');
	}
	for (var i = obj.startPage; i <= obj.endPage; i++) {
		if (obj.pageIndex == i) {
			pagingHtml.push('<li class="page-item active"><span class="page-link"> ' + i + ' <span class="sr-only">(current)</span></span></li>');
		} else {
			pagingHtml.push('<li class="page-item"><a class="page-link" href="#" onClick="fnGetList(' + i + ')">' + i + '</a></li>');
		}
	}
	if (obj.next && obj.endPage > 0) {
		pagingHtml.push('<li class="page-item"><a class="page-link" href="#" onClick="fnGetList(' + (obj.endPage + 1) + ')">Next</a></li>');
	} else {
		pagingHtml.push('<li class="page-item disabled"><span class="page-link">Next</span>');
	}
	return pagingHtml.join('\n');
};

/**
 * <pre>     * Ajax 호출 공통
 *
 * 필수) _URL - 전송 URL (String)
 * 필수) _PARAMETERS - 전송 파라미터 (object or String)
 * 필수) _CALLBACK - 콜백함수 (function)
 * 선택) _async - 동기화 여부 (boolean : 미지정시 true)
 * 선택) loading bar 실행 여부 - true/false
 * 선택) _errorMsg - 전송 실패시 메시지 (String)
 * </pre>
 */
CommUtils.callAjax = function(_URL, _PARAMETERS, _CALLBACK) {
	if (_URL != null) {

		var _async = arguments[3];
		if (_async == null) _async = true;
		
		var _loading = arguments[4];
		if (_loading == null) _loading = true;

		var _errorMsg = arguments[5];

		$.ajax({
			type: "POST",
			url: _URL,
			data: _PARAMETERS,
			async: _async,
            beforeSend: function (){
				if (_loading) {
            		$('body').loading('start');
				}
           	},
           	complete:function(){
 				if (_loading) {
          			$('body').loading('stop');
				}
            },
			success: function(rst) {
				_CALLBACK(rst);
			},
			error: function() {
				if (_errorMsg != null) {
					alert(_errorMsg);
				} else {
					alert("서버에 요청중 문제가 발생했습니다.\n관리자에게 문의하여 주십시오.");
				}
			}
		});
	} else {
		alert("올바른 요청이 아닙니다.");
		return false;
	}
};

/**
* form validate 체크
* @method fnValidate
*/
CommUtils.fnValidate = function(frmId) {
	
	var isCheck = true;
	//영문 대.소문자, 숫자 _,-만 입력 가능하고 4에서 20자리를 입력했는지 체크
	var userIdCheck = RegExp(/^[a-z]+[a-z0-9]{4,20}$/g);
	//패스워드 체크에서는 영문 대문자와 소문자, 숫자, 특수문자를 하나 이상 포함하여 4~20자가 되는지 검사
	//var passwdCheck = RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^*()\-_=+\\\|\[\]{};:\'",.<>\/?]).{4,20}$/);
	var passwdCheck = RegExp(/^.*(?=^.{8,15}$)(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/);
	//2~6글자의 한글만 입력하였는지 검사
	var nameCheck = RegExp(/^[가-힣]{2,6}$/);
	//한글과 영어, 숫자만 사용하였는지 검사
	var nickNameCheck = RegExp(/^[가-힣a-zA-Z0-9]{2,10}$/);
	//생년월일을 형식에 맞게 썻는지 검사 19또는 20으로 시작하여 0~9까지의 수개 2개까지 하여 년도 그 뒤에 0이면1~9 1이면 1~2(1월부터 12월까지기 때문에) 이런식으로 검사
	var birthdayCheck = RegExp(/^(19|20)[0-9]{2}(0[1-9]|1[1-2])(0[1-9]|[1-2][0-9]|3[0-1])$/);
	//phonNumberCheck : 01로 시작하여 그 다음은 0,1,7,9 중 하나와 매칭되는지 체크한뒤 7~8자리인지 검사
	var phonNumberCheck = RegExp(/^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/);
	//이메일 형식에 맞게 썻는지 검사 ex)aa01@aa.aa
	var emailCheck = RegExp(/^[A-Za-z0-9_\.\-]+@[A-Za-z0-9\-]+\.[A-Za-z0-9\-]+/);

	var message = {
		required : '필수 입력 사항입니다.',
		requiredCheck : '필수 선택 사항입니다.',
		minlength : '자 이상 입력해 주시기 바랍니다.',
		maxlength : '자 이하 입력해 주시기 바랍니다.',
		userid : '올바른 ID가 아닙니다.(4에서 20자리의 영문 대.소문자, 숫자, _, -만 입력 가능)',
		passwd : '올바른 비밀번호가 아닙니다.(4에서 20자리의 영문 대.소문자, 숫자, 특수문자를 하나 이상 포함)',
		username : '올바른 이름이 아닙니다.(2~6글자의 한글만 입력 가능)',
		nickname : '올바른 닉네임이 아닙니다.(한글과 영어, 숫자만 입력 가능)',
		birthday : '올바른 생년월일이 아닙니다.',
		phone : '올바른 전화번호가 아닙니다.',
		email : '올바른 이메일 형식이 아닙니다.',
		show: function(that, msg) {
			
			var _title = arguments[2];
			var titleMsg = "";
			if (_title == null) _title = false;
			
			if (_title) {
				if (that.is('[title]') && that.attr("title") != null && that.attr("title") != ""){
					titleMsg = that.attr("title") + " 은(는) ";
				}
			}
			
			isCheck = false;
			
/*			if (that.prop("type") == "text") {
				that.focus();
			} else if (that.prop("type") == "radio") {
				console.log($('input:radio[name=' + that.attr("name") + ']').is(':checked'));
				$('input:radio[name=' + that.attr("name") + ']').focus();
			} else if (that.prop("type") == "checkbox") {
			}
*/			
			that.focus();
			alert(titleMsg + msg);
			return false;
		}
	};
	
	//$("form#"+frmId+" input, form#"+frmId+" select").each(function(){
//	$("form#"+frmId+" input, form#"+frmId+" select').each(function(key, value) {
	$("#"+frmId).find('select,input,textarea').each(function(){
		//필수여부
		if ($(this).is('[required]')) {
			//console.log($(this).attr("id"));
			console.log($(this).prop("type"));
			
			if ($(this).prop("type") == "radio") {
				if (!($('input:radio[name=' + $(this).attr("name") + ']').is(':checked'))) {
					return message.show($(this), message.requiredCheck, true);
				}
			} else if ($(this).prop("type") == "checkbox") {
				if (!($('input:checked[name=' + $(this).attr("name") + ']').is(':checked'))) {
					return message.show($(this), message.requiredCheck, true);
				}
/*			} else if ($(this).prop("type") == "select-one") {
				console.log($(this).attr("id"));
				console.log($(this).val());
*/				
				
			} else {
				if ($(this).val() == null || $(this).val() == ""){
					return message.show($(this), message.required, true);
				}
			}
			
			
		}
		//min length
		if ($(this).is('[minlength]')) {
			if ($(this).val().length < Number($(this).attr("minlength"))) {
				return message.show($(this), $(this).attr("minlength") + message.minlength, true);
			}
		}
		//max length
		if ($(this).is('[maxlength]')) {
			if ($(this).val().length > Number($(this).attr("maxlength"))) {
				return message.show($(this), $(this).attr("maxlength") + message.maxlength, true);
			}
		}

		if ($(this).val() != null && $(this).val() != ""){
			//id 형식 확인
			if ($(this).is('[userid]')) {
				if(!userIdCheck.test($(this).val())) {
					return message.show($(this), message.userid);
				}
			}
			//패스워드 형식 확인
			if ($(this).is('[passwd]')) {
				if(!passwdCheck.test($(this).val())) {
					return message.show($(this), message.passwd);
				}
			}
			//이름 형식 확인
			if ($(this).is('[username]')) {
				if(!nameCheck.test($(this).val())) {
					return message.show($(this), message.username);
				}
			}
			//닉네임 형식 확인
			if ($(this).is('[nickname]')) {
				if(!nickNameCheck.test($(this).val())) {
					return message.show($(this), message.nickname);
				}
			}
			//생년월일 형식 확인
			if ($(this).is('[birthday]')) {
				if(!birthdayCheck.test($(this).val())) {
					return message.show($(this), message.birthday);
				}
			}
			//전화번호 형식 확인
			if ($(this).is('[phone]')) {
				if(!phonNumberCheck.test($(this).val())) {
					return message.show($(this), message.phone);
				}
			}
			//email 형식 확인
			if ($(this).is('[email]')) {
				if(!emailCheck.test($(this).val())) {
					return message.show($(this), message.email);
				}
			}
		}
		
	});

/*	$("form#"+frmId+" select").each(function(){
		//필수여부
		if ($(this).is('[required]')) {
			console.log($(this).attr("id"));
		}
	});*/

	return isCheck;
};

/**
* 전화번호 Format
*/
CommUtils.fnTelNumFormatter = function(value, kbn) {
	if (value != '' && ("" + value).length > 8) {
		var phoneNumber = ("" + value).replace(/\./g, '').replace(/-/g, '').replace(/[^0-9]/g, '');
		return phoneNumber.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/,"$1-$2-$3");
	} else {
		return value;
	}
};

/**
* 숫자 Format
*/
CommUtils.fnMoneyNumFormatter = function(value) {
	if (value != '' && ("" + value).length > 3) {
		var reg = /(^[+-]?\d+)(\d{3})/;
		var moneyNumber = ("" + value).replace(/,/g, '').replace(/[^\.0-9]/g, '');
		
		while (reg.test(moneyNumber)) {
			moneyNumber = moneyNumber.replace(reg, '$1' + ',' + '$2');
		}

		return moneyNumber;
	} else {
		return value;
	}
};

/**
* 달력 Format
*/
CommUtils.fnDateNumFormatter = function(value) {
	if (value != '' && ("" + value).length == 8) {
		var dateNumber = ("" + value).replace(/\./g, '').replace(/-/g, '').replace(/\//g, '').replace(/[^0-9]/g, '');
		return dateNumber.replace(/([0-9]{4})([0-9]{2})([0-9]{2})/,"$1-$2-$3");
	} else {
		return value;
	}
};

/**
* 주민번호 Format
*/
CommUtils.fnJuminNumFormatter = function(value) {
	if (value != '' && ("" + value).length == 13) {
		var juminNumber = ("" + value).replace(/[^0-9]/g, '');
		return juminNumber.replace(/([0-9]{6})([0-9]{7})/,"$1-$2");
	} else {
		return ("" + value).replace(/[^\-0-9]/g, '');
	}
};

/**
* 숫자로 변환
*/
CommUtils.fnChangeNumber = function(value) {
	if (value != '' && value != 'undefined') {
		var changeNumber = ("" + value).replace(/,/g, '').replace(/[^\.\+\-0-9]/g, '');
		return Number(changeNumber);
	} else {
		return 0;
	}
};

//날짜 유효성 체크
CommUtils.isValidDate = function(param){
    try
    {
        param = param.replace(/-/g,'');

        // 자리수가 맞지않을때
        if( isNaN(param) || param.length!=8 ) {
            return false;
        }
         
        var year = Number(param.substring(0, 4));
        var month = Number(param.substring(4, 6));
        var day = Number(param.substring(6, 8));

        //var dd = day / 0;
         
        if( month<1 || month>12 ) {
            return false;
        }
         
        var maxDaysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        var maxDay = maxDaysInMonth[month-1];
         
        // 윤년 체크
        if( month==2 && ( year%4==0 && year%100!=0 || year%400==0 ) ) {
            maxDay = 29;
        }
         
        if( day<=0 || day>maxDay ) {
            return false;
        }
        return true;

    } catch (err) {
        return false;
    }                       
};

//null check
CommUtils.chkNull = function(value){
	if (value == null || value == undefined || value == "undefined" || value.length == 0) {
		return false;
	} else {
		return true;
	}
};

//오늘날짜
CommUtils.getNowDate = function(){
    var now = new Date();
    var year= now.getFullYear();
    var mon = (now.getMonth()+1)>9 ? ''+(now.getMonth()+1) : '0'+(now.getMonth()+1);
    var day = now.getDate()>9 ? ''+now.getDate() : '0'+now.getDate();
            
    var toDay = year + '' + mon + '' + day;
    return toDay;
};

//나이
CommUtils.getAge = function(birthday){
  	var year=parseInt(new Date().getFullYear()); 
  	var ck=parseInt(birthday.substr(0,4)); 
  	var age=(year-ck)+1;
  	return age;
};

$(function(){
	//숫자만 입력가능하게 함
	$(document).on("keyup", "input:text[numberOnly]", function() {
		$(this).val( $(this).val().replace(/[^0-9]/gi,"") );
	});


});
	
