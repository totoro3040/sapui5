package com.mirae.life.espc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mirae.life.comm.ui.pagination.PageMaker;
import com.mirae.life.espc.service.MemberService;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
@RequestMapping("/sample")
public class MemberController {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private MemberService memberService;	

	/**
	 * index(페이징)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/list")
	public String paging(@RequestParam Map<String,Object> params, ModelMap model) throws Exception {
		
		logger.debug("params.searchKey : {}", MapUtils.getString(params, "searchKey"));
		
		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		int totCnt = memberService.selectMemberCount(params); //목록 갯수를 가져온다.
		List<Map<String, Object>> contList = memberService.selectMemberList(params); //목록을 가져온다.
		
		PageMaker pageMaker = new PageMaker(
				MapUtils.getInteger(params, "pageIndex", 1),
				MapUtils.getInteger(params, "perPageNum", 10),
				totCnt);
		
		model.addAttribute("params", params);
		model.addAttribute("contList", contList);
		model.addAttribute("pageMaker", pageMaker);
		
		//model.put("view_type", "test");
		
		return "sample/member/list";
	}

	
	/**
	 * index(ajax list 구현)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/ajaxList")
	public String list(@RequestParam Map<String,Object> params, ModelMap model) throws Exception {
		
		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		model.addAttribute("params", params);
		return "sample/member/ajaxList";
	}

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/listPrc", method = {RequestMethod.POST})
	//@ResponseBody
	public @ResponseBody Map<String, Object> listPrc(@RequestParam Map<String,Object> params) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		int totCnt = memberService.selectMemberCount(params); //목록 갯수를 가져온다.
		List<Map<String, Object>> contList = memberService.selectMemberList(params); //목록을 가져온다.

		//paging
		PageMaker pageMaker = new PageMaker(
				MapUtils.getInteger(params, "pageIndex", 1),
				MapUtils.getInteger(params, "perPageNum", 10),
				totCnt);
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("contList", contList);
		map.put("pageMaker", pageMaker);
		
		return map;
	}

	/**
	 * 목록조회 (AJAX 목록 조회 - spring5 이전 버전)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/listPrc2", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public ModelMap listPrc2(@RequestParam Map<String,Object> params, ModelMap model) throws Exception {

		logger.debug("/memberajax/listPrc");
		
		int totCnt = memberService.selectMemberCount(params); //목록 갯수를 가져온다.
		List<Map<String, Object>> contList = memberService.selectMemberList(params); //목록을 가져온다.

		//paging
		PageMaker pageMaker = new PageMaker(
				MapUtils.getInteger(params, "pageIndex", 1),
				MapUtils.getInteger(params, "perPageNum", 10),
				totCnt);
		
		model.put("contList", contList);
		model.put("pageMaker", pageMaker);
		
		return model;
	}

	/**
	 * 상세 조회 화면
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/view.do")
	public String getAuditView(@RequestParam Map<String,Object> params, ModelMap model) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		//logger.debug("JsonUtil.getJsonStringFromMap(params) : {}", JsonUtil.getJsonStringFromMap(params));
		//Map<String, Object> content = memberService.selectMemberDetail(params);
		//model.addAttribute("content", content);
		
		model.addAttribute("params", params);
		//model.addAttribute("searchKey", JsonUtil.getJsonStringFromMap(params));
		
		return "sample/member/view";
	}

	/**
	 *조회 (Ajax)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/viewPrc.do")
	public @ResponseBody Map<String, Object> viewPrc(@RequestParam Map<String,Object> params) throws Exception {

		return memberService.selectMemberDetail(params);
	}

	/**
	 * 저장
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/savePrc.do")
	//@ResponseBody
	public @ResponseBody String savePrc(@RequestParam Map<String,Object> params) throws Exception {
		
		memberService.insertMember(params);
		
		return "S";
	}

	/**
	 * 수정
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/changePrc.do")
	//@ResponseBody
	public @ResponseBody String changePrc(@RequestParam Map<String,Object> params) throws Exception {

		memberService.updateMember(params);
		
		return "S";
	}

	/**
	 * 삭제
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/member/removePrc.do")
	//@ResponseBody
	public @ResponseBody String removePrc(@RequestParam Map<String,Object> params) throws Exception {

		memberService.deleteMember(params);
		
		return "S";
	}
}
