package com.mirae.life.espc.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.mirae.life.espc.vo.SeriesVO;

//import egovframework.rte.psl.dataaccess.mapper.Mapper;

/**
 * 의안현황 데이터처리 매퍼 클래스
 *
 * @author  totoro
 * @since 2019.09.15
 * @version 1.0
 * @see <pre>
 *  == 개정이력(Modification Information) ==
 *
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   019.09.15        totoro          최초 생성
 *
 * </pre>
 */
//@Mapper
@Repository
public interface BillDao {

	int selectMemberCount(Map<String,Object> params) throws Exception;

	List<Map<String, Object>> selectMemberList(Map<String,Object> params) throws Exception;
	
	/**
	 * 의안현황 있는 회의의 전체 대 목록 가져오기
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	List<SeriesVO> selectBillSerieslist() throws Exception;


	/**
	 * 의안현황 있는 회의의 전체 대 목록 가져오기
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	List<Map<String, Object>> selectBillSerieslist2() throws Exception;

	/**
	 * 트랜잭션 테스트1
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	void insertMember1(Map<String, Object> param) throws Exception;
	
	/**
	 * 트랜잭션 테스트1
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	void insertMember2(Map<String, Object> param) throws Exception;

}
