package com.mirae.life.espc.model;

public class TdOdCalAgeStd {
	private String isprd;
	private String rvpd;
	private Long ntryAmt;
	
	public String getIsprd() {
		return isprd;
	}
	public void setIsprd(String isprd) {
		this.isprd = isprd;
	}
	public String getRvpd() {
		return rvpd;
	}
	public void setRvpd(String rvpd) {
		this.rvpd = rvpd;
	}
	public Long getNtryAmt() {
		return ntryAmt;
	}
	public void setNtryAmt(Long ntryAmt) {
		this.ntryAmt = ntryAmt;
	}
}

