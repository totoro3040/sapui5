package com.mirae.life.espc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

/**
 *  부서정보 CRUD 요청을 처리하는 Controller 클래스
 * 
 * @author  윤혁신
 * @since 2014.12.29
 * @version 1.0
 * @see 
 * <pre>
 *  == 개정이력(Modification Information) ==
 *   
 *          수정일          수정자           수정내용
 *  ----------------    ------------    ---------------------------
 *   2014.12.29        윤혁신          최초 생성
 * 
 * </pre>
 */
@Controller
@RequestMapping("/sample")
public class RestController {
	private Logger logger = LoggerFactory.getLogger(getClass());


	/**
	 * index(ajax list 구현)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/rest/ajaxList")
	public String list(@RequestParam Map<String,Object> params, ModelMap model) throws Exception {
		
		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
		model.addAttribute("params", params);
		return "sample/member/ajaxList";
	}

	/**
	 * 목록조회 (AJAX 목록 조회)
	 * 
	 * @param RequestParamMap
	 * @return org.springframework.ui.ModelMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/rest/listPrc", method = {RequestMethod.POST})
	//@ResponseBody
	public @ResponseBody MultiValueMap<String, String> listPrc(@RequestParam Map<String,Object> params) throws Exception {

		logger.debug("params : {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(params));
		
	    // RestTemplate 에 MessageConverter 세팅
	    List<HttpMessageConverter<?>> converters = new ArrayList<HttpMessageConverter<?>>();
	    converters.add(new FormHttpMessageConverter());
	    converters.add(new StringHttpMessageConverter());
	 
	    RestTemplate restTemplate = new RestTemplate();
	    restTemplate.setMessageConverters(converters);
	 
	    // parameter 세팅
	    MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
	    map.add("str", "thisistest");
	 
	    // REST API 호출
	    String result = restTemplate.postForObject("http://localhost:8082/restTest/", map, String.class);
	    System.out.println("------------------ TEST 결과 ------------------");
	    System.out.println(result);
		
		return map;
	}
}
