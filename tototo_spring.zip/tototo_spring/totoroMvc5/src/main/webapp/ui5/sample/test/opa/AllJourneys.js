sap.ui.define([
	"./startpage",
	"./reviews",
	"./backNavigation"
], function () {
});
