sap.ui.define([
		"./controller/Startpage.controller",
		"./controller/ProcessFlow.controller",
		"./controller/Reviews.controller"
	], function() {
});
