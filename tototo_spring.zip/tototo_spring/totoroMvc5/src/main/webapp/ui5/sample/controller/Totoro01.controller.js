sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat"
], function(Controller, JSONModel, DateFormat) {
	"use strict";

	return Controller.extend("sap.suite.ui.commons.demo.tutorial.controller.Totoro01", {
		onInit: function() {
			var that = this;
			
			this.oTimeline = this.byId("timeline");
			
			
          var aData = jQuery.ajax({
               type: "POST",
               contentType: "application/json",
               url: "/sample/member/listPrc.do",
               dataType: "json",
               data: jQuery.param({}) ,
               success: function (data, textStatus) {
                   	var oModel = new JSONModel();
					oModel.setData(data);
					console.log(oModel);
					that.getView().byId("table1").setModel(oModel);
               }

           });
			
		},

		addReview: function() {
			var oModel = this.getView().getModel("reviews"),
				oData = oModel.getData(),
				oTemplateEntry = oData.UserReviews[0];

			oTemplateEntry.template = false;
			oTemplateEntry.dateTime = new Date().toJSON().slice(0, 10).toString();

			// Add new template entry to the beginning
			oData.UserReviews.unshift({
				"user": "",
				"userPic": "",
				"rating": 10,
				"quote": "",
				"date": "now",
				"template": true
			});

			oModel.setData(oData);
		},

		formatDateTime: function(dateTime) {
			var oDateInstance = DateFormat.getDateInstance();
			return oDateInstance.format(oDateInstance.parse(dateTime));
		},

		onNavButtonPressed: function() {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("home");
		},

		onHorizontalSwitchChange: function(event) {
			if (event.getParameter("state")) {
				this.oTimeline.setAxisOrientation("Horizontal");
			} else {
				this.oTimeline.setAxisOrientation("Vertical");
			}
		}
	});
});
