/*eslint-disable no-console, no-alert, no-eval */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/thirdparty/jquery",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"./Formatter"
	//"com/kbstar/hr/ZHR_Totoro_01/model/utils/formatter"
], function (Controller, JSONModel, Device, jQuery, MessageToast, Fragment, Formatter) {
	"use strict";

	return Controller.extend("com.kbstar.hr.ZHR_Totoro_01.controller.M011", {

		//formatter : formatter,
		
		onInit: function () {
			var oModel = this.getJsonModel("com/kbstar/hr/ZHR_Totoro_01/model/User.json");
			this.getView().byId("table1").setModel(oModel);
			oModel = this.getJsonModel("com/kbstar/hr/ZHR_Totoro_01/model/In.json");
			this.getView().byId("table2").setModel(oModel);
			oModel = this.getJsonModel("com/kbstar/hr/ZHR_Totoro_01/model/sido.json");
			this.getView().byId("sido").setModel(oModel);
			
			//init
			var oModel1 = new JSONModel();
			oModel1.setData({detail: {
				text1 : "",
						text2 : "" ,
						text3 : "" ,
						text4 : "" ,
						text5 : "" ,
						text6 : "" ,
						text7 : "" ,
						text8 : "" ,
						visible: true
			}});
			this.getView().setModel(oModel1);
		},
		
		//json data를 가져온다.
		getJsonModel: function (vUrl) {
			var oData = jQuery.sap.sjax({
				url: sap.ui.require.toUrl(vUrl),
				dataType: "json"
			}).data;

			var oModel = new JSONModel();
			oModel.setData(oData);
			return oModel;
		},
		
		//시도 선택 시
		onSidoChange: function (oEvent) {
			
			var selKey = oEvent.getParameter("selectedItem").getKey();
			console.log("selKey : ", selKey);
			
			//init
			this.getView().getModel().setProperty("/detail/visible", false);
			
			// this.getView().byId("a01", "a02", "a03", "a04", "a05", "a06", "a07", "a08").setVisible(false);

			var oData = jQuery.sap.sjax({
				url: sap.ui.require.toUrl("com/kbstar/hr/ZHR_Totoro_01/model/gugun.json"),
				dataType: "json"
			}).data;

			var oNewData = {};
			var aTemp1 = [];
			for (var i = 0; i < oData.gugun.length; i++) {
				var oGugun = oData.gugun[i];
				if (oGugun.key === selKey) {
					aTemp1.push(oGugun);
				}
			}
			oNewData.gugun = aTemp1;

			var oNewModel = new JSONModel();
			oNewModel.setData(oNewData);

			this.getView().byId("gugun").setModel(oNewModel);
			this.getView().byId("gugun").setSelectedKey("");
			
			//this.getView().byId("a01", "a02", "a03").setText("");
			
			
	},

		//구군 선택 시
		onGugunChange: function (oEvent) {
			
			var selKey = oEvent.getParameter("selectedItem").getKey();
			console.log("selDetKey : ", selKey);
			
			var oData = jQuery.sap.sjax({
				url: sap.ui.require.toUrl("com/kbstar/hr/ZHR_Totoro_01/model/gugun.json"),
				dataType: "json"
			}).data;

			for (var i = 0; i < oData.gugun.length; i++) {
				var oGugun = oData.gugun[i];
				if (oGugun.detkey === selKey) {
					
					// var vData = {
					// 	text1 : oGugun.a01 ,
					// 	text2 : oGugun.a02 ,
					// 	text3 : oGugun.a03 ,
					// 	text4 : oGugun.a04 ,
					// 	text5 : oGugun.a05 ,
					// 	text6 : oGugun.a06 ,
					// 	text7 : oGugun.a07 ,
					// 	text8 : oGugun.a08 ,
					// 	visible: true
					// };
					
					this.getView().getModel().setProperty("/detail/text1", oGugun.a01);
					this.getView().getModel().setProperty("/detail/text2", oGugun.a02);
					this.getView().getModel().setProperty("/detail/text3", oGugun.a03);
					this.getView().getModel().setProperty("/detail/text4", oGugun.a04);
					this.getView().getModel().setProperty("/detail/text5", oGugun.a05);
					this.getView().getModel().setProperty("/detail/text6", oGugun.a06);
					this.getView().getModel().setProperty("/detail/text7", oGugun.a07);
					this.getView().getModel().setProperty("/detail/text8", oGugun.a08);
					this.getView().getModel().setProperty("/detail/visible", true);
					
					console.log("oGugun.detkey : ", oGugun.detkey);
					console.log("oGugun.a04 : ", oGugun.a04);
					
					// this.getView().byId("a01").setText(oGugun.a01 );
					// this.getView().byId("a02").setText(oGugun.a02);
					// this.getView().byId("a03").setText(oGugun.a03);
					// this.getView().byId("a04").setText(oGugun.a04);
					// this.getView().byId("a05").setText(oGugun.a05);
					// this.getView().byId("a06").setText(oGugun.a06);
					// this.getView().byId("a07").setText(oGugun.a07);
					// this.getView().byId("a08").setText(oGugun.a18);
				}
			}

	}


	});

});