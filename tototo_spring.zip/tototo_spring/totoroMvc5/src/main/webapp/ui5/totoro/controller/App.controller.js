sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (Controller, JSONModel, Device) {
	"use strict";

	return Controller.extend("com.kbstar.hr.ZHR_Totoro_01.controller.App", {
		onInit: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			
			this.oModel = new JSONModel();
			this.oModel.loadData(sap.ui.require.toUrl("com/kbstar/hr/ZHR_Totoro_01/model") + "/menu.json", null, false);
			this.getView().setModel(this.oModel);
			
		},
		
		onSelectItem: function(oEvent){
      		var oItem;
			oItem = oEvent.getParameter("item");
			//console.log("oItem", oItem);
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo(oItem.getKey(), {}, true);
    	},

		onSideNavButtonPress: function() {
			var oToolPage = this.byId("app");
			oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
		},

	});
});
