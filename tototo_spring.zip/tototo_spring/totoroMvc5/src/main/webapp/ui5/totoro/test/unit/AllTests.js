sap.ui.define([
	"com/kbstar/hr/ZHR_Totoro_01/test/unit/controller/App.controller"
], function () {
	"use strict";
});