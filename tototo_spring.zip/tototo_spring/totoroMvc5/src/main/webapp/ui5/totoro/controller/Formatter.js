sap.ui.define(function() {
	"use strict";

	var Formatter = {

		numberUnit: function (sValue) {
			return "";
		},
		/**
		 * Defines a value state based on the price
		 *
		 * @public
		 * @param {number} iPrice the price of a post
		 * @returns {string} sValue the state for the price
		 */
		priceState: function (iPrice) {
			if (iPrice < 50) {
				return "Success";
			} else if (iPrice >= 50 && iPrice < 250) {
				return "None";
			} else if (iPrice >= 250 && iPrice < 2000) {
				return "Warning";
			} else {
				return "Error";
			}
		},
		
		/**
		 * 날짜를 YYYY-MM-DD 형식으로 바꾼다.
		 */
		DateYmdFormater: function (fVal, var2) {
			
			console.log("fVal", fVal);
			console.log("var2", var2);
			
			if (fVal && fVal !== "" && fVal.length === 8) {
				return fVal.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
			} else if (fVal && fVal !== "" && fVal.length === 6) {
				return fVal.replace(/(\d{4})(\d{2})/g, '$1-$2');
			} else {
				return "";
			}
		},

		/**
		 * 계좌번호 형식을 바꾼다..
		 */
		AccountFormater: function (fVal) {
			if (fVal && fVal !== "" && fVal.length === 12) {
				return fVal.replace(/(\d{3})(\d{2})(\d{4})(\d{3})/g, '$1-$2-$3-$4');
			} else {
				return "";
			}
		}
	};

	return Formatter;

}, /* bExport= */ true);
