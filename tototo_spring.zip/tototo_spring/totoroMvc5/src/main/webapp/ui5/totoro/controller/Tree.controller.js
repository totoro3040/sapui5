sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.kbstar.hr.ZHR_Totoro_01.controller.Tree", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.kbstar.hr.ZHR_Totoro_01.view.Tree
		 */
		onInit: function () {

			var oModel = this.getJsonModel("com/kbstar/hr/ZHR_Totoro_01/model/Tree.json");
//			this.getView().byId("table1").setModel(oModel);
			this.getView().setModel(oModel);
			
		},
		
			//json data를 가져온다.
		getJsonModel: function (vUrl) {
			var oData = jQuery.sap.sjax({
				url: sap.ui.require.toUrl(vUrl),
				dataType: "json"
			}).data;

			var oModel = new JSONModel();
			oModel.setData(oData);
			return oModel;
		},

		onCollapseAll: function() {
			var oTreeTable = this.byId("TreeTableBasic");
			oTreeTable.collapseAll();
		},

		onCollapseSelection: function() {
			var oTreeTable = this.byId("TreeTableBasic");
			oTreeTable.collapse(oTreeTable.getSelectedIndices());
		},

		onExpandFirstLevel: function() {
			var oTreeTable = this.byId("TreeTableBasic");
			oTreeTable.expandToLevel(1);
		},

		onExpandSelection: function() {
			var oTreeTable = this.byId("TreeTableBasic");
			oTreeTable.expand(oTreeTable.getSelectedIndices());
		},
		
		onOpenNewWindow: function(oEvent){
			sap.m.URLHelper.redirect("http://www.google.co.kr", true);
		}


		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.kbstar.hr.ZHR_Totoro_01.view.Tree
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.kbstar.hr.ZHR_Totoro_01.view.Tree
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.kbstar.hr.ZHR_Totoro_01.view.Tree
		 */
		//	onExit: function() {
		//
		//	}

	});

});