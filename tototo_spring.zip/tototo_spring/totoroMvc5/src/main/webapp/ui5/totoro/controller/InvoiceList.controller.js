/*eslint-disable no-console, no-alert, no-eval */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/thirdparty/jquery",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment"
], function (Controller, JSONModel, Device, jQuery, MessageToast, Fragment) {
	"use strict";

	return Controller.extend("com.kbstar.hr.ZHR_Totoro_01.controller.InvoiceList", {

		onInit: function () {
			//this.getView().addStyleClass("sapUiSizeCompact");
			//var oModel = new JSONModel(sap.ui.require.toUrl("com/kbstar/hr/ZHR_Totoro_01/model/Invoices.json"));
			var oModel = this.getJsonModel("com/kbstar/hr/ZHR_Totoro_01/model/Invoices.json");

			//this.getView().setModel(oModel);
			this.getView().byId("table1").setModel(oModel);
			//this.getView().setModel(oModel, "invoicesPath");
		},

		//json data를 가져온다.
		getJsonModel: function (vUrl) {
			var oData = jQuery.sap.sjax({
				url: sap.ui.require.toUrl(vUrl),
				dataType: "json"
			}).data;

			var oModel = new JSONModel();
			oModel.setData(oData);
			return oModel;
		},

		/**
		 * table.Table의 Cell를 클릭시에 해당 Row의 정보를 수정할 수 있는 Panel에 정보를 설정하는 Method를 호출한다.
		 */
		onCellClick: function (oEvent) {

			// var oTable2 = this.getView().byId("table1");
			// var oModel2 = oTable2.getModel();
			// var aRows = oModel2.getData().data;

			// debugger;

			var oContext = oEvent.getParameters().rowBindingContext;
			var oTable = this.getView().byId("table1");
			var oModel = oTable.getModel();
			var vData = oModel.getProperty(oContext.sPath);
			var vHocAssoId = vData['hoc_asso_id'];
			console.log("vHocAssoId : ", vHocAssoId);

			var mgr_org_nm = vData['mgr_org_nm'];
			console.log("mgr_org_nm : ", mgr_org_nm);

			var oData = jQuery.sap.sjax({
				url: sap.ui.require.toUrl("com/kbstar/hr/ZHR_Totoro_01/model/Detail.json"),
				dataType: "json"
			}).data;

			var oNewData = {};
			var aTemp1 = [];
			for (var i = 0; i < oData.Detail.length; i++) {
				var oProduct = oData.Detail[i];
				if (oProduct.hoc_asso_id === vHocAssoId) {
					aTemp1.push(oProduct);
				}
			}
			oNewData.Detail = aTemp1;

			var oNewModel = new JSONModel();
			oNewModel.setData(oNewData);

			this.getView().byId("table2").setModel(oNewModel);

			//console.log("=========== oData : ", JSON.stringify(oData));
			//console.log("=========== oNewData : ", JSON.stringify(oNewData));

		},

		/**
		 * 날짜를 YYYY-MM-DD 형식으로 바꾼다.
		 */
		DateYmdFormater: function (fVal) {
			if (fVal && fVal !== "" && fVal.length === 8) {
				return fVal.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
			} else if (fVal && fVal !== "" && fVal.length === 6) {
				return fVal.replace(/(\d{4})(\d{2})/g, '$1-$2');
			} else {
				return "";
			}
		},

		/**
		 * 계좌번호 형식을 바꾼다..
		 */
		AccountFormater: function (fVal) {
			if (fVal && fVal !== "" && fVal.length === 12) {
				return fVal.replace(/(\d{3})(\d{2})(\d{4})(\d{3})/g, '$1-$2-$3-$4');
			} else {
				return "";
			}
		},

		handleDetailsPress: function (oEvent) {
			//MessageToast.show("Details for product with id " + this.getView().getModel().getProperty("chief_emp_no", oEvent.getSource().getBindingContext()));
			console.log("111");
		},
		
		onOpenDialog : function () {
			var oView = this.getView();

			console.log("1111");

			// create dialog lazily
			if (!this.byId("helloDialog")) {
				
				console.log("a");
				
				// load asynchronous XML fragment
				Fragment.load({
					id: oView.getId(),
					name: "com.kbstar.hr.ZHR_Totoro_01.view.HelloDialog"
				}).then(function (oDialog) {
					// connect dialog to the root view of this component (models, lifecycle)
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				console.log("b");
				this.byId("helloDialog").open();
			}
		}

	});

});