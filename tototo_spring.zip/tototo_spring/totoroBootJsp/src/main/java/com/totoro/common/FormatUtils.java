package com.totoro.common;

public class FormatUtils {

    /**
     * 문자열을 전화번호 형식으로 표시
     *
     * @param 	value 	{String}	기준문자열
     * @return 	{String}	전화번호 형식 
     */
    public static String getFormatTel(String value) {
        return getFormatTel(value, "-");
    }
    
    /**
     * 문자열을 전화번호 형식으로 표시+구분자
     *
     * @param 	value 	{String}	기준문자열
     * @param 	delim 	{String}	구분자
     * @return 	{String}	전화번호 형식 
     */
    public static String getFormatTel(String value, String delim) {
        String regEx = "(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})";
        String result = value;
        
        if (value != null && !value.equals("") && value.length() >= 9) {
       		result = value.replaceAll(regEx, "$1" + delim + "$2" + delim + "$3");
        }
        return result;
    }

    /**
     * 문자열을 날짜 형식으로 표시 (YYYY-MM-DD, YYYY-MM)
     *
     * @param 	pStrSrc	{String}	기준문자열
     * @return 	{String}	날짜 형식 
     */
    public static String getFormatDate(String value) {
    	return getFormatDate(value, "-");
    }  

    /**
     * 문자열을 날짜 형식으로 표시 (YYYY-MM-DD, YYYY-MM), 구분자
     *
     * @param 	pStrSrc	{String}	기준문자열
     * @return 	{String}	날짜 형식 
     */
    public static String getFormatDate(String value, String delim) {
    	String regEx = "([0-9]{4})([0-9]{2})([0-9]{2})";
    	String result = value;

    	if (value != null && !value.equals("")) {
    		if (value.length() == 8) {
    			result = value.replaceAll(regEx, "$1" + delim + "$2" + delim + "$3");
    		} else if (value.length() == 6) {
    			regEx = "([0-9]{4})([0-9]{2})";
    			result = value.replaceAll(regEx, "$1" + delim + "$2");
    		}
       		
        }
        return result;
   }  
    
//    public static void main(String[] args) {
//    	System.out.println(FormatUtils.getFormatTel("0111234567", "-"));
//    	System.out.println(FormatUtils.getFormatDate("201903", "-"));
//	}
}
