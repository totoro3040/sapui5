package com.totoro.common;

public class PageMaker {
    
    //private Criteria cri;

    private int totalCount; 		//총 게시글 수
    private int startPage; 			//화면에 보여질 첫번째 페이지 번호, 시작 페이지 번호
    private int endPage; 			//화면에 보여질 마지막 페이지 번호, 끝 페이지 번호
    private boolean prev; 			//이전 버튼 생성 여부
    private boolean next; 			//다음 버튼 생성 여부

    private int pageIndex = 1; 		//현재 페이지 번호
    private int perPageNum = 10; 	//한 페이지당 보여줄 게시글의 갯수
    private int displayPageNum = 5; //화면 하단에 보여지는 페이지 버튼의 수

	public PageMaker() {
	}
	//페이징 설정
	public PageMaker(int pageIndex, int perPageNum, int totalCount) {
		this.setPageIndex(pageIndex);
		this.setPerPageNum(perPageNum);
		this.setTotalCount(totalCount);
		this.calcData();
	}

    public int getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
        //calcData();
    }
    
    private void calcData() {
        
        endPage = (int) (Math.ceil(pageIndex / (double) displayPageNum) * displayPageNum);
 
        startPage = (endPage - displayPageNum) + 1;
        if(startPage <= 0) startPage = 1;
        
        int tempEndPage = (int) (Math.ceil(totalCount / (double) perPageNum));
        if (endPage > tempEndPage) {
        	endPage = tempEndPage;
        }
 
        prev = startPage == 1 ? false : true;
        next = endPage * perPageNum < totalCount ? true : false;
        
        if (endPage == 0) endPage = 1;
       
    }
    
	public int getStartPage() {
		return startPage;
	}
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public boolean isPrev() {
		return prev;
	}
	public void setPrev(boolean prev) {
		this.prev = prev;
	}
	public boolean isNext() {
		return next;
	}
	public void setNext(boolean next) {
		this.next = next;
	}
	public int getDisplayPageNum() {
		return displayPageNum;
	}
	public void setDisplayPageNum(int displayPageNum) {
		this.displayPageNum = displayPageNum;
	}
	public int getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}
	public int getPerPageNum() {
		return perPageNum;
	}
	public void setPerPageNum(int perPageNum) {
		this.perPageNum = perPageNum;
	}
 
}

