package com.totoro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TotoroBootJpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(TotoroBootJpa2Application.class, args);
	}

}
