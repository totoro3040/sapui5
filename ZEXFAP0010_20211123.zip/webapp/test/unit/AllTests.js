sap.ui.define([
	"lsp/ex/ZEXFAP0010/test/unit/controller/App.controller"
], function () {
	"use strict";
});