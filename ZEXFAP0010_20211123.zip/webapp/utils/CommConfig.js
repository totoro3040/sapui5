sap.ui.define([], function () {
	"use strict";

	return {
		_oViewData : {
				_config: {
					stdDate: "",
					endDate: "",
					timeCount: 1
				},
				_total: {
					count0101: 0,	// 미통관 현황
					count0201: 0,	// 미출하 현황
					count0301: 0,	// EDT대비
					count0401: 0,	// 선적지연 현황
					count0501: 0,	// B/L 미수신 현황 전체
					count0502: 0,	// B/L 미수신 현황
					count0601: 0,	// F.DEST 불일치 건수
					count0701: 0	//SD 불일치 건수
				},
				_chart: {
					data01: 0,	//1일이상
					data02: 0,	//5일이상
					data03: 0	//10일이상
				}
		}
	};
});