sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"lsp/ex/ZEXFAP0010/utils/CommConfig",
	"lsp/ex/ZEXFAP0010/utils/CommUtils"
], function (Controller, JSONModel, Filter, CommConfig, CommUtils) {
	"use strict";

	return Controller.extend("lsp.ex.ZEXFAP0010.controller.Mainview", {
		_iMinusHeight : 500,
		
		/**
		 * init
		 */
		onInit: function () {
			var oTotalData = $.extend(true, {}, CommConfig._oViewData);
			var oTotalModel = new JSONModel(oTotalData);
			this.getView().byId("totalCountLayout").setModel(oTotalModel);
			
			this.changeTableHeight(); //화면에 맞춰 테이블 높이 변경
			this.setInitData(); //Total 데이터 가져옴
		},

		/**
		 * Timer (5분이 지나면 reload)
		 */
		setTimer: function(that){
			var oTotalModel = that.getView().byId("totalCountLayout").getModel();
			var iTimeCount = oTotalModel.getProperty("/_config/timeCount");
			
			if (iTimeCount < 5) {
				iTimeCount = iTimeCount + 1;
				oTotalModel.setProperty("/_config/timeCount", iTimeCount);
			} else {
				iTimeCount = 1;
				oTotalModel.setProperty("/_config/timeCount", iTimeCount);
				
				var oSmartTable = that._getSmartTable();
				oSmartTable.rebindTable(); //데이터 리바인딩
				that.setInitData(); //Total 데이터 가져옴
			}
		},

		/**
		 * page init Total 데이터 가져옴 (링크 클릭시나 5분마다 실행함)
		 */
		setInitData: function(){
			var oTotalModel = this.getView().byId("totalCountLayout").getModel();
			
			// 현황합계 데이터 합계를 가져옴
			this.getPressTotalStatus("/_total/count0501", "", "", "Y",""); // B/L 미수신 현황 전체
			this.getPressTotalStatus("/_total/count0502", "blinforec", "shipconf", "Y", "NE"); // B/L 미수신 현황
			this.getPressTotalStatus("/_total/count0101", "ncc", "", "Y", "EQ"); // 미통관
			this.getPressTotalStatus("/_total/count0201", "ndeliv", "", "Y", "EQ"); // 미출하
			this.getPressTotalStatus("/_total/count0301", "etdcobd", "", "Y", "EQ"); // ETD대비 On Board data 현황
			this.getPressTotalStatus("/_total/count0401", "shipdelay", "", "Y", "EQ"); // 선적지연 현황
			this.getPressTotalStatus("/_total/count0601", "fdestcnt", "", "Y", "EQ"); // F.Dest 불일치 건수
			this.getPressTotalStatus("/_total/count0701", "sdmima", "", "Y", "EQ"); // F.Dest 불일치 건수
			
			//그래프
			this.getPressTotalStatus("/_chart/data01", "delay", "", "Y", "EQ"); // 1일이상
			this.getPressTotalStatus("/_chart/data02", "delay", "", "B", "EQ"); // 5일이상
			this.getPressTotalStatus("/_chart/data03", "delay", "", "R", "EQ"); // 10일이상
			
			//날짜 설정
			oTotalModel.setProperty("/_config/stdDate", CommUtils.dateFormatCm(CommUtils.addMonthDate(-3, 1)));
			oTotalModel.setProperty("/_config/endDate", CommUtils.dateFormatCm(CommUtils.nowDate()));
			
			//timer
			if (this._Interval) {
				clearInterval(this._Interval);
			}
			this._Interval = setInterval(this.setTimer, 60000, this); // 6분 간격으로 갱신

		},

		/**
		 * 현황합계 데이터를 가져옴
		 * @param Property명
		 * @param 필터1
		 * @param 필터2
		 * @param value
		 * @param EQ or NE
		 */
		getPressTotalStatus: function(sProperty, sType, sSubType, sValue, sCompare){
			
			var oTotalModel = this.getView().byId("totalCountLayout").getModel();
			
			var oFilters = [];
			if (sType && sType !== "") {
				oFilters.push(new Filter(sType, sCompare, sValue));
			}
			if (sSubType && sSubType !== "") {
				oFilters.push(new Filter(sSubType, sCompare, sValue));
			}

			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			oDataModel.read("/zexcva0110_ddl/$count", {
				filters: [new Filter(oFilters, true)],
			 	success: function(oData, response){
			 		if (oData && oData !== "") {
				 		oTotalModel.setProperty(sProperty, Number($.trim(oData)));
			 		}
			 	},
			 	error: function(oError){
			 		CommUtils.displayErrorMessage(oError, "toast");
			 	}
			});
		},

		/**
		 * 현황합계 클릭 Event
		 * @param 필터1
		 * @param 필터2
		 * @param value
		 * @param EQ or NE
		 */
		onChangeListData: function(oEvent, sType, sSubType, sValue, sCompare){ 

			this.setInitData(); //Total 데이터 가져옴

			var oSmartTable = this._getSmartTable();

			this.oTableSearchState = [];
			//var sQuery = oEvent.getSource().getProperty("selectedKey");
			
			var oType, oSubType;
			this.oPubFilters = [];
			if (sType && sType !== "" && sSubType && sSubType !== "") {
				oType = new Filter(sType, sCompare, sValue);
				oSubType = new Filter(sSubType, sCompare, sValue);
				this.oPubFilters = new sap.ui.model.Filter({filters:[oType, oSubType], and:true});
			} else {
				if (sType && sType !== "") {
					oType = new Filter(sType, sCompare, sValue);
					this.oPubFilters = new sap.ui.model.Filter({filters:[oType], and:true});
				} else if (sSubType && sSubType !== "") {
					oSubType = new Filter(sSubType, sCompare, sValue);
					this.oPubFilters = new sap.ui.model.Filter({filters:[oSubType], and:true});
				}
			}
			
			oSmartTable.rebindTable();
		},

		/**
		 * 목록에서 Link 클릭 시 새창으로 페이지 호출
		 */
		onPageLink: function(oEvent){ 
			var oControl = oEvent.getSource();
			
			var sSemObj = CommUtils._getCustomData(oControl.getCustomData(), "sSemObj");	//TCODE
			var sValue = CommUtils._getCustomData(oControl.getCustomData(), "sValue");		//값
			
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			var oHash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: sSemObj,
					action: "report"
				},
				params: {
					"TORID": sValue
				}
			})) || ""; // generate the Hash to display a Supplier

			var url = "/sap/bc/ui2/flp?sap-client=400&sap-language=KO" + oHash;
			//local일 경우
			if (location.host.indexOf("webide") !== -1) {
				url = "http://coms4apdv01.pantos.com:8000" + url; //개발서버 host
			}
			sap.m.URLHelper.redirect(url, true);

		},

		/**
		 * 데이터 리바인딩
		 */
		onBeforeRebindTable: function (oEvent) {

		    if (this.oPubFilters && this.oPubFilters.aFilters && this.oPubFilters.aFilters.length > 0) {
			    var oBinding = oEvent.getParameter("bindingParams");
		    	var oFilter = this.oPubFilters;
			    oBinding.filters.push(oFilter);
		    }
		},
		
		/**
		 * 데이터를 바인딩 후에 처리
		 */
		onDataReceived: function (oEvent) {
			// var oTotalModel2 = this.getView().getModel();
			// oTotalModel2.setProperty("/aa/bb", "11");
			
			//데이터 확인
		},

		/**
		 * 버튼 정렬 팝업 호출
		 */
		onSort: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Sort");
			}
		},

		/**
		 * 버튼 필터 팝업 호출
		 */
		onFilter: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Filter");
			}
		},

		/**
		 * 컬럼 셋팅 팝업 호출
		 */
		onColumns: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Columns");
			}
		},

		/**
		 * 테이블 정보를 가져온다.
		 * @return SmartTable
		 */
		_getSmartTable: function () {
			if (!this._oSmartTable) {
				this._oSmartTable = this.getView().byId("mainviewSmartTable");
			}
			return this._oSmartTable;
		},

		/**
		 * 엑셀 다운로드
		 */
		onBeforeExport: function (oEvent) {
			var mExcelSettings = oEvent.getParameter("exportSettings");
			
			// GW export
			if (mExcelSettings.url) {
				return;
			}
			// UI5 Client Export
			if (mExcelSettings.fileName !== "") {
				mExcelSettings.fileName = mExcelSettings.fileName; // example to modify fileName
			} else {
				mExcelSettings.fileName = "FB List";
			}

			// customization
			if (mExcelSettings.workbook && mExcelSettings.workbook.columns && mExcelSettings.workbook.columns.length > 0) {
				var oExcelData = mExcelSettings.workbook.columns;
				for(var i=0; i<oExcelData.length; i++) {
					oExcelData[i].width = oExcelData[i].width * 2;
				}
			}

			mExcelSettings.worker = false;
		},

		/**
		 * 화면에 맞춰 테이블 높이 변경
		 */
		changeTableHeight: function () {
			var that = this;
			
			//테이블 높이 지정
			var oTable = this.getView().byId("gridTableData");
			var iHet = window.innerHeight - this._iMinusHeight;
			var nHet = Math.floor( iHet / 33);
			if (oTable) {
				oTable.setVisibleRowCount(nHet);
			}
			
			sap.ui.Device.resize.attachHandler(function(oEvent) {
				var iHet1 = oEvent.height - that._iMinusHeight;
				var nHet1 = Math.floor( iHet1 / 33);
				if (oTable) {
					oTable.setVisibleRowCount(nHet1);
				}
			}, this.getView());
		}	

	});

});